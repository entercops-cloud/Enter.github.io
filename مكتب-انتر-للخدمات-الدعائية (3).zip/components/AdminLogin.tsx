import React, { useState, useEffect } from 'react';
import { Lock, User, Key, Eye, EyeOff, ShieldCheck, AlertCircle, X, ShieldAlert, Clock, RefreshCw } from 'lucide-react';
import { store } from '../services/store';

interface AdminLoginProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const AdminLogin: React.FC<AdminLoginProps> = ({ isOpen, onClose, onSuccess }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // Security Challenge (Anti-Bot Math verification)
  const [num1, setNum1] = useState(6);
  const [num2, setNum2] = useState(7);
  const [captchaAnswer, setCaptchaAnswer] = useState('');
  const [captchaError, setCaptchaError] = useState(false);

  // Lockout countdown state
  const [lockoutTimer, setLockoutTimer] = useState<number>(0);

  const refreshCaptcha = () => {
    setNum1(Math.floor(Math.random() * 8) + 2);
    setNum2(Math.floor(Math.random() * 8) + 2);
    setCaptchaAnswer('');
    setCaptchaError(false);
  };

  useEffect(() => {
    if (isOpen) {
      setUsername('');
      setPassword('');
      setError('');
      refreshCaptcha();
    }
  }, [isOpen]);

  // Lockout countdown tick
  useEffect(() => {
    if (lockoutTimer <= 0) return;
    const interval = setInterval(() => {
      setLockoutTimer((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, [lockoutTimer]);

  if (!isOpen) return null;

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (lockoutTimer > 0) return;

    // Validate Anti-bot challenge
    if (parseInt(captchaAnswer.trim(), 10) !== num1 + num2) {
      setCaptchaError(true);
      setError('إجابة التحقق الأمني غير صحيحة. يرجى إعادة المحاولة.');
      refreshCaptcha();
      return;
    }

    if (!username.trim() || !password) {
      setError('يرجى إدخال اسم المستخدم وكلمة المرور.');
      return;
    }

    setIsLoading(true);
    setError('');

    const res = await store.loginAdminServer(password, username);
    setIsLoading(false);

    if (res.success) {
      setError('');
      onSuccess();
    } else {
      if (res.locked && res.remainingSeconds) {
        setLockoutTimer(res.remainingSeconds);
      }
      setError(res.error || 'اسم المستخدم أو كلمة المرور غير صحيحة.');
      refreshCaptcha();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md" dir="rtl">
      <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl border border-gray-100 overflow-hidden animate-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-brand-dark p-6 text-white text-center relative border-b border-brand-yellow/20">
          <button
            onClick={onClose}
            className="absolute top-4 left-4 text-white/60 hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors"
            aria-label="إغلاق"
          >
            <X size={20} />
          </button>
          
          <div className="w-14 h-14 rounded-2xl bg-brand-yellow/10 border border-brand-yellow/30 mx-auto flex items-center justify-center mb-3">
            <Lock size={26} className="text-brand-yellow" />
          </div>
          
          <h2 className="text-xl font-black text-white">بوابة الإدارة المحمية</h2>
          <p className="text-[11px] text-gray-300 mt-1 flex items-center justify-center gap-1">
            <ShieldAlert size={13} className="text-brand-yellow" />
            <span>نظام تسجيل دخول مشفر ومخصص للموظفين المصرح لهم فقط</span>
          </p>
        </div>

        {/* Form Body */}
        <div className="p-6 sm:p-7 space-y-4">
          {error && (
            <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-xs flex items-start gap-2">
              <AlertCircle size={16} className="shrink-0 mt-0.5" />
              <div className="flex-grow">
                <span className="font-semibold block">{error}</span>
                {lockoutTimer > 0 && (
                  <span className="text-[11px] text-red-600 block mt-1 flex items-center gap-1 font-mono">
                    <Clock size={12} /> متبقي للفتح: {Math.floor(lockoutTimer / 60)} دقيقة و {lockoutTimer % 60} ثانية
                  </span>
                )}
              </div>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-3.5">
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">اسم المستخدم المصرح</label>
              <div className="relative">
                <input
                  type="text"
                  required
                  autoFocus
                  disabled={lockoutTimer > 0 || isLoading}
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-3 pr-10 py-2.5 rounded-xl border border-gray-200 text-sm focus:border-brand-purple focus:ring-2 focus:ring-brand-purple/10 outline-none text-gray-800 disabled:bg-gray-100"
                  placeholder="أدخل اسم المستخدم"
                />
                <User size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">كلمة المرور المشفرة</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  required
                  disabled={lockoutTimer > 0 || isLoading}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 rounded-xl border border-gray-200 text-sm focus:border-brand-purple focus:ring-2 focus:ring-brand-purple/10 outline-none text-gray-800 disabled:bg-gray-100"
                  placeholder="••••••••"
                />
                <Key size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <button
                  type="button"
                  tabIndex={-1}
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                >
                  {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Anti-Bot Security Challenge */}
            <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 text-xs space-y-2">
              <div className="flex items-center justify-between text-gray-700 font-bold">
                <span className="flex items-center gap-1.5 text-brand-dark">
                  <span>التحقق الأمني: ما حاصل جمع</span>
                  <span className="font-mono bg-white px-2 py-0.5 rounded border border-gray-300 text-brand-purple text-sm">
                    {num1} + {num2}
                  </span>
                  <span>؟</span>
                </span>
                <button
                  type="button"
                  onClick={refreshCaptcha}
                  className="text-gray-400 hover:text-brand-purple p-1"
                  title="تغيير المسألة"
                >
                  <RefreshCw size={13} />
                </button>
              </div>
              <input
                type="number"
                required
                disabled={lockoutTimer > 0 || isLoading}
                value={captchaAnswer}
                onChange={(e) => {
                  setCaptchaAnswer(e.target.value);
                  setCaptchaError(false);
                }}
                placeholder="أدخل الناتج الرياضي هنا"
                className={`w-full p-2 text-xs border rounded-lg outline-none bg-white font-mono ${
                  captchaError ? 'border-red-400 focus:ring-red-200' : 'border-gray-300 focus:border-brand-purple'
                }`}
              />
            </div>

            <button
              type="submit"
              disabled={lockoutTimer > 0 || isLoading}
              className="w-full bg-brand-purple hover:bg-[#4d2377] text-white py-3 rounded-xl font-bold text-sm shadow-md transition-all active:scale-95 flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed mt-2"
            >
              {isLoading ? (
                <span>جاري التحقق الأمني...</span>
              ) : (
                <>
                  <ShieldCheck size={18} />
                  <span>التحقق والدخول للنظام</span>
                </>
              )}
            </button>
          </form>

          {/* Quick Credential Helper for Administrators */}
          <div className="p-2.5 rounded-xl bg-purple-50 border border-purple-100 flex items-center justify-between text-[11px] text-brand-purple">
            <div>
              <span className="font-bold block">بيانات الدخول الأساسية:</span>
              <span className="text-gray-600 font-mono text-[11px]">admin / admin123</span>
            </div>
            <button
              type="button"
              onClick={() => {
                setUsername('admin');
                setPassword('admin123');
                setCaptchaAnswer(String(num1 + num2));
              }}
              className="px-2.5 py-1 bg-white hover:bg-brand-purple hover:text-white rounded-lg text-brand-purple border border-purple-200 text-[11px] font-bold shadow-2xs transition-colors cursor-pointer"
            >
              تعبئة سريعة
            </button>
          </div>

          {/* Security Notice */}
          <div className="pt-1 text-center text-[10px] text-gray-400 border-t border-gray-100 leading-relaxed">
            محمية بنظام تشفير الخوادم ومكافحة التخمين الآلي. تقبل اسم المستخدم admin أو بريد المؤسسة.
          </div>

        </div>

      </div>
    </div>
  );
};

export default AdminLogin;
