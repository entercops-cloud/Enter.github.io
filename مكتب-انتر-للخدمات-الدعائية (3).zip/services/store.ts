import { Product, CategoryItem, SiteSettings, Order, QuoteRequest, MediaItem, AdminNotification, OrderWorkflowStatus, DiscountTier, Testimonial } from '../types';
import { INITIAL_PRODUCTS, INITIAL_CATEGORIES, INITIAL_SITE_SETTINGS, INITIAL_TESTIMONIALS } from '../constants';
import { sendBrowserNotification } from './notificationService';

// Client-Server Sync Store:
// All reads and writes are persisted to the server database (/data/db.json and /uploads/*)
// with local cache for instant zero-latency UI rendering.

const CACHE_KEYS = {
  PRODUCTS: 'enter_tech_products_cache',
  CATEGORIES: 'enter_tech_categories_cache',
  SETTINGS: 'enter_tech_settings_cache',
  ORDERS: 'enter_tech_orders_cache',
  QUOTES: 'enter_tech_quotes_cache',
  MEDIA: 'enter_tech_media_cache',
  TESTIMONIALS: 'enter_tech_testimonials_cache',
  ADMIN_AUTH: 'enter_tech_admin_auth',
};

async function parseJsonOrNull<T>(res: Response | null | undefined): Promise<T | null> {
  if (!res || !res.ok) return null;
  const contentType = res.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) return null;
  try {
    return (await res.json()) as T;
  } catch {
    return null;
  }
}

export const store = {
  // Synchronous cache getters for immediate React initialization
  getProducts(): Product[] {
    try {
      const data = localStorage.getItem(CACHE_KEYS.PRODUCTS);
      return data ? JSON.parse(data) : INITIAL_PRODUCTS;
    } catch {
      return INITIAL_PRODUCTS;
    }
  },

  getCategories(): CategoryItem[] {
    try {
      const data = localStorage.getItem(CACHE_KEYS.CATEGORIES);
      return data ? JSON.parse(data) : INITIAL_CATEGORIES;
    } catch {
      return INITIAL_CATEGORIES;
    }
  },

  getSettings(): SiteSettings {
    try {
      const data = localStorage.getItem(CACHE_KEYS.SETTINGS);
      return data ? { ...INITIAL_SITE_SETTINGS, ...JSON.parse(data) } : INITIAL_SITE_SETTINGS;
    } catch {
      return INITIAL_SITE_SETTINGS;
    }
  },

  getOrders(): Order[] {
    try {
      const data = localStorage.getItem(CACHE_KEYS.ORDERS);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  getQuotes(): QuoteRequest[] {
    try {
      const data = localStorage.getItem(CACHE_KEYS.QUOTES);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  getMedia(): MediaItem[] {
    try {
      const data = localStorage.getItem(CACHE_KEYS.MEDIA);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  getTestimonials(): Testimonial[] {
    try {
      const data = localStorage.getItem(CACHE_KEYS.TESTIMONIALS);
      return data ? JSON.parse(data) : INITIAL_TESTIMONIALS;
    } catch {
      return INITIAL_TESTIMONIALS;
    }
  },

  getNotifications(): AdminNotification[] {
    try {
      const data = localStorage.getItem('enter_tech_notifications_cache');
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  },

  addNotification(notif: Omit<AdminNotification, 'id' | 'timestamp' | 'read'>): AdminNotification {
    const notifications = this.getNotifications();
    const newNotif: AdminNotification = {
      ...notif,
      id: `notif-${Date.now()}`,
      timestamp: new Date().toISOString(),
      read: false,
    };
    notifications.unshift(newNotif);
    localStorage.setItem('enter_tech_notifications_cache', JSON.stringify(notifications.slice(0, 50)));
    return newNotif;
  },

  markNotificationsAsRead(): AdminNotification[] {
    const notifications = this.getNotifications().map((n) => ({ ...n, read: true }));
    localStorage.setItem('enter_tech_notifications_cache', JSON.stringify(notifications));
    return notifications;
  },

  clearNotifications(): void {
    localStorage.removeItem('enter_tech_notifications_cache');
  },

  getAdminPassword(): string {
    return 'admin123';
  },

  setAdminPassword(newPass: string): void {
    this.changePasswordServer(newPass);
  },

  // Full Server Synchronization on Load
  async syncFromServer(): Promise<{
    products: Product[];
    categories: CategoryItem[];
    settings: SiteSettings;
    orders: Order[];
    quotes: QuoteRequest[];
    media: MediaItem[];
    testimonials: Testimonial[];
  }> {
    try {
      const [prodRes, catRes, setRes, ordRes, quoRes, medRes, testRes] = await Promise.all([
        fetch('/api/products').catch(() => null),
        fetch('/api/categories').catch(() => null),
        fetch('/api/settings').catch(() => null),
        fetch('/api/orders').catch(() => null),
        fetch('/api/quotes').catch(() => null),
        fetch('/api/media').catch(() => null),
        fetch('/api/testimonials').catch(() => null),
      ]);

      const [prods, cats, sets, ords, quos, meds, tests] = await Promise.all([
        parseJsonOrNull<Product[]>(prodRes),
        parseJsonOrNull<CategoryItem[]>(catRes),
        parseJsonOrNull<SiteSettings>(setRes),
        parseJsonOrNull<Order[]>(ordRes),
        parseJsonOrNull<QuoteRequest[]>(quoRes),
        parseJsonOrNull<MediaItem[]>(medRes),
        parseJsonOrNull<Testimonial[]>(testRes),
      ]);

      const products: Product[] = prods && Array.isArray(prods) && prods.length > 0 ? prods : this.getProducts();
      const categories: CategoryItem[] = cats && Array.isArray(cats) && cats.length > 0 ? cats : this.getCategories();
      const settings: SiteSettings = sets ? { ...INITIAL_SITE_SETTINGS, ...sets } : this.getSettings();
      const orders: Order[] = ords && Array.isArray(ords) ? ords : this.getOrders();
      const quotes: QuoteRequest[] = quos && Array.isArray(quos) ? quos : this.getQuotes();
      const media: MediaItem[] = meds && Array.isArray(meds) ? meds : this.getMedia();
      const testimonials: Testimonial[] = tests && Array.isArray(tests) && tests.length > 0 ? tests : this.getTestimonials();

      // Cache locally
      localStorage.setItem(CACHE_KEYS.PRODUCTS, JSON.stringify(products));
      localStorage.setItem(CACHE_KEYS.CATEGORIES, JSON.stringify(categories));
      localStorage.setItem(CACHE_KEYS.SETTINGS, JSON.stringify(settings));
      localStorage.setItem(CACHE_KEYS.ORDERS, JSON.stringify(orders));
      localStorage.setItem(CACHE_KEYS.QUOTES, JSON.stringify(quotes));
      localStorage.setItem(CACHE_KEYS.MEDIA, JSON.stringify(media));
      localStorage.setItem(CACHE_KEYS.TESTIMONIALS, JSON.stringify(testimonials));

      return { products, categories, settings, orders, quotes, media, testimonials };
    } catch (err) {
      console.warn('Sync from server fallback to cache:', err);
      return {
        products: this.getProducts(),
        categories: this.getCategories(),
        settings: this.getSettings(),
        orders: this.getOrders(),
        quotes: this.getQuotes(),
        media: this.getMedia(),
        testimonials: this.getTestimonials(),
      };
    }
  },

  // 1. Products on Server
  async saveProducts(products: Product[]): Promise<Product[]> {
    localStorage.setItem(CACHE_KEYS.PRODUCTS, JSON.stringify(products));
    try {
      await fetch('/api/products', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(products),
      });
    } catch (e) {
      console.warn('Server error on saveProducts:', e);
    }
    return products;
  },

  async fetchProductsServer(): Promise<Product[]> {
    try {
      const res = await fetch('/api/products').catch(() => null);
      const data = await parseJsonOrNull<Product[]>(res);
      if (data && Array.isArray(data) && data.length > 0) {
        localStorage.setItem(CACHE_KEYS.PRODUCTS, JSON.stringify(data));
        return data;
      }
    } catch (e) {
      console.warn('Error fetching products from server:', e);
    }
    return this.getProducts();
  },

  async addProductServer(product: Omit<Product, 'id'> & { id?: string }): Promise<Product> {
    try {
      const res = await fetch('/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product),
      });
      if (res.ok) {
        const saved: Product = await res.json();
        const updated = [saved, ...this.getProducts().filter((p) => p.id !== saved.id)];
        localStorage.setItem(CACHE_KEYS.PRODUCTS, JSON.stringify(updated));
        return saved;
      }
    } catch (e) {
      console.warn('Server error on addProduct:', e);
    }
    const localProduct: Product = {
      ...product,
      id: product.id || `p-${Date.now()}`,
    };
    const updated = [localProduct, ...this.getProducts()];
    localStorage.setItem(CACHE_KEYS.PRODUCTS, JSON.stringify(updated));
    return localProduct;
  },

  async updateProductServer(product: Product): Promise<void> {
    try {
      await fetch(`/api/products/${product.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(product),
      });
    } catch (e) {
      console.warn('Server error on updateProduct:', e);
    }
    const updated = this.getProducts().map((p) => (p.id === product.id ? product : p));
    localStorage.setItem(CACHE_KEYS.PRODUCTS, JSON.stringify(updated));
  },

  async deleteProductServer(id: string): Promise<Product[]> {
    try {
      await fetch(`/api/products/${id}`, { method: 'DELETE' });
    } catch (e) {
      console.warn('Server error on deleteProduct:', e);
    }
    const updated = this.getProducts().filter((p) => p.id !== id);
    localStorage.setItem(CACHE_KEYS.PRODUCTS, JSON.stringify(updated));
    return updated;
  },

  // 2. Categories on Server
  async saveCategories(categories: CategoryItem[]): Promise<CategoryItem[]> {
    localStorage.setItem(CACHE_KEYS.CATEGORIES, JSON.stringify(categories));
    try {
      await fetch('/api/categories', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(categories),
      });
    } catch (e) {
      console.warn('Server error on saveCategories:', e);
    }
    return categories;
  },

  async fetchCategoriesServer(): Promise<CategoryItem[]> {
    try {
      const res = await fetch('/api/categories').catch(() => null);
      const data = await parseJsonOrNull<CategoryItem[]>(res);
      if (data && Array.isArray(data) && data.length > 0) {
        localStorage.setItem(CACHE_KEYS.CATEGORIES, JSON.stringify(data));
        return data;
      }
    } catch (e) {
      console.warn('Error fetching categories from server:', e);
    }
    return this.getCategories();
  },

  async addCategoryServer(name: string, customId?: string): Promise<CategoryItem> {
    try {
      const res = await fetch('/api/categories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, id: customId }),
      }).catch(() => null);
      const saved = await parseJsonOrNull<CategoryItem>(res);
      if (saved) {
        const updated = [...this.getCategories(), saved];
        localStorage.setItem(CACHE_KEYS.CATEGORIES, JSON.stringify(updated));
        return saved;
      }
    } catch (e) {
      console.warn('Server error on addCategory:', e);
    }
    const localCat: CategoryItem = {
      id: customId || `cat-${Date.now()}`,
      name,
    };
    const updated = [...this.getCategories(), localCat];
    localStorage.setItem(CACHE_KEYS.CATEGORIES, JSON.stringify(updated));
    return localCat;
  },

  async deleteCategoryServer(id: string): Promise<CategoryItem[]> {
    try {
      await fetch(`/api/categories/${id}`, { method: 'DELETE' });
    } catch (e) {
      console.warn('Server error on deleteCategory:', e);
    }
    const updated = this.getCategories().filter((c) => c.id !== id);
    localStorage.setItem(CACHE_KEYS.CATEGORIES, JSON.stringify(updated));
    return updated;
  },

  // 3. Settings on Server
  async saveSettings(settings: SiteSettings): Promise<void> {
    localStorage.setItem(CACHE_KEYS.SETTINGS, JSON.stringify(settings));
    try {
      await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      });
    } catch (e) {
      console.warn('Server error on saveSettings:', e);
    }
  },

  async fetchSettingsServer(): Promise<SiteSettings> {
    try {
      const res = await fetch('/api/settings').catch(() => null);
      const data = await parseJsonOrNull<SiteSettings>(res);
      if (data) {
        const merged = { ...INITIAL_SITE_SETTINGS, ...data };
        localStorage.setItem(CACHE_KEYS.SETTINGS, JSON.stringify(merged));
        return merged;
      }
    } catch (e) {
      console.warn('Error fetching settings from server:', e);
    }
    return this.getSettings();
  },

  // 4. Orders on Server
  async fetchOrdersServer(): Promise<Order[]> {
    try {
      const res = await fetch('/api/orders').catch(() => null);
      const data = await parseJsonOrNull<Order[]>(res);
      if (data && Array.isArray(data)) {
        localStorage.setItem(CACHE_KEYS.ORDERS, JSON.stringify(data));
        return data;
      }
    } catch (e) {
      console.warn('Error fetching orders from server:', e);
    }
    return this.getOrders();
  },

  async addOrder(order: Omit<Order, 'id' | 'createdAt'>): Promise<Order> {
    let savedOrder: Order | null = null;
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(order),
      }).catch(() => null);
      savedOrder = await parseJsonOrNull<Order>(res);
    } catch (e) {
      console.warn('Falling back to local order generation:', e);
      savedOrder = null;
    }

    if (!savedOrder) {
      savedOrder = {
        ...order,
        id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        status: order.status || 'review',
        statusNote: order.statusNote || 'تم استلام الطلب وبدء مرحلة الفحص والتدقيق الفني قبل تشغيل الماكينات',
        estimatedDate: '2-3 أيام عمل',
      };
    }

    const current = this.getOrders();
    const updated = [savedOrder, ...current.filter((o) => o.id !== savedOrder!.id)];
    localStorage.setItem(CACHE_KEYS.ORDERS, JSON.stringify(updated));

    // Send Browser Alert & Audio Chime & Record Notification
    const notifTitle = `طلب شراء جديد: ${savedOrder.customerName}`;
    const notifBody = `رقم الطلب: ${savedOrder.id} - بقيمة ${savedOrder.finalTotal} ₪`;
    this.addNotification({
      title: notifTitle,
      message: notifBody,
      type: 'order',
      orderId: savedOrder.id,
    });
    sendBrowserNotification(notifTitle, notifBody);

    return savedOrder;
  },

  async updateOrderStatus(
    orderId: string,
    status: OrderWorkflowStatus,
    statusNote?: string,
    estimatedDate?: string
  ): Promise<Order[]> {
    try {
      await fetch(`/api/orders/${orderId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status, statusNote, estimatedDate }),
      });
    } catch (e) {
      console.warn('Server error on updateOrderStatus:', e);
    }

    const orders = this.getOrders().map((ord) => {
      if (ord.id === orderId) {
        const history = Array.isArray(ord.history) ? [...ord.history] : [];
        if (status !== ord.status || (statusNote && statusNote !== ord.statusNote)) {
          history.push({
            id: `hist-${Date.now()}`,
            status,
            statusNote,
            timestamp: new Date().toISOString(),
            updatedBy: 'إدارة المطبعة',
          });
        }
        return {
          ...ord,
          status,
          statusNote: statusNote !== undefined ? statusNote : ord.statusNote,
          estimatedDate: estimatedDate !== undefined ? estimatedDate : ord.estimatedDate,
          updatedAt: new Date().toISOString(),
          history,
        };
      }
      return ord;
    });
    localStorage.setItem(CACHE_KEYS.ORDERS, JSON.stringify(orders));
    return orders;
  },

  async updateOrder(updatedOrder: Order): Promise<Order[]> {
    try {
      await fetch(`/api/orders/${updatedOrder.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedOrder),
      });
    } catch (e) {
      console.warn('Server error on updateOrder:', e);
    }
    const orders = this.getOrders().map((ord) => {
      if (ord.id === updatedOrder.id) {
        let history = updatedOrder.history ? [...updatedOrder.history] : ord.history ? [...ord.history] : [];
        if (updatedOrder.status !== ord.status || (updatedOrder.statusNote && updatedOrder.statusNote !== ord.statusNote)) {
          history.push({
            id: `hist-${Date.now()}`,
            status: updatedOrder.status,
            statusNote: updatedOrder.statusNote,
            timestamp: new Date().toISOString(),
            updatedBy: 'إدارة المطبعة',
          });
        }
        return {
          ...ord,
          ...updatedOrder,
          updatedAt: new Date().toISOString(),
          history,
        };
      }
      return ord;
    });
    localStorage.setItem(CACHE_KEYS.ORDERS, JSON.stringify(orders));
    return orders;
  },

  async getOrderByIdOrPhone(query: string): Promise<Order | undefined> {
    try {
      const res = await fetch(`/api/orders/track/${encodeURIComponent(query.trim())}`);
      if (res.ok) {
        const order = await res.json();
        return order;
      }
    } catch (e) {
      console.warn('Server track fetch fallback to local:', e);
    }

    // Fallback to local search
    const q = query.trim().toUpperCase();
    const cleanDigits = query.replace(/[^0-9]/g, '');
    const orders = this.getOrders();

    return orders.find((ord) => {
      if (ord.id.toUpperCase() === q) return true;
      if (cleanDigits.length >= 6 && ord.customerPhone.replace(/[^0-9]/g, '').includes(cleanDigits)) {
        return true;
      }
      return false;
    });
  },

  async deleteOrder(orderId: string): Promise<Order[]> {
    try {
      await fetch(`/api/orders/${orderId}`, { method: 'DELETE' });
    } catch (e) {
      console.warn('Server deleteOrder error:', e);
    }
    const orders = this.getOrders().filter((ord) => ord.id !== orderId);
    localStorage.setItem(CACHE_KEYS.ORDERS, JSON.stringify(orders));
    return orders;
  },

  // 5. Quotes on Server
  async fetchQuotesServer(): Promise<QuoteRequest[]> {
    try {
      const res = await fetch('/api/quotes').catch(() => null);
      const data = await parseJsonOrNull<QuoteRequest[]>(res);
      if (data && Array.isArray(data)) {
        localStorage.setItem(CACHE_KEYS.QUOTES, JSON.stringify(data));
        return data;
      }
    } catch (e) {
      console.warn('Error fetching quotes from server:', e);
    }
    return this.getQuotes();
  },

  async addQuote(quote: Omit<QuoteRequest, 'id' | 'createdAt'>): Promise<QuoteRequest> {
    let savedQuote: QuoteRequest | null = null;
    try {
      const res = await fetch('/api/quotes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(quote),
      }).catch(() => null);
      savedQuote = await parseJsonOrNull<QuoteRequest>(res);
    } catch (e) {
      console.warn('Falling back to local quote generation:', e);
      savedQuote = null;
    }

    if (!savedQuote) {
      savedQuote = {
        ...quote,
        id: `Q-${Math.floor(1000 + Math.random() * 9000)}`,
        createdAt: new Date().toISOString(),
      };
    }

    const current = this.getQuotes();
    const updated = [savedQuote, ...current.filter((q) => q.id !== savedQuote!.id)];
    localStorage.setItem(CACHE_KEYS.QUOTES, JSON.stringify(updated));

    const qTitle = `عرض سعر جديد: ${savedQuote.customerName}`;
    const qBody = `الخدمة: ${savedQuote.serviceName}`;
    this.addNotification({
      title: qTitle,
      message: qBody,
      type: 'quote',
    });
    sendBrowserNotification(qTitle, qBody);
    return savedQuote;
  },

  async updateQuoteStatus(quoteId: string, status: QuoteRequest['status']): Promise<QuoteRequest[]> {
    try {
      await fetch(`/api/quotes/${quoteId}/status`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
    } catch (e) {
      console.warn('Server error on updateQuoteStatus:', e);
    }
    const quotes = this.getQuotes().map((q) => (q.id === quoteId ? { ...q, status } : q));
    localStorage.setItem(CACHE_KEYS.QUOTES, JSON.stringify(quotes));
    return quotes;
  },

  async updateQuote(updatedQuote: QuoteRequest): Promise<QuoteRequest[]> {
    try {
      await fetch(`/api/quotes/${updatedQuote.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedQuote),
      });
    } catch (e) {
      console.warn('Server error on updateQuote:', e);
    }
    const quotes = this.getQuotes().map((q) =>
      q.id === updatedQuote.id
        ? { ...q, ...updatedQuote, updatedAt: new Date().toISOString() }
        : q
    );
    localStorage.setItem(CACHE_KEYS.QUOTES, JSON.stringify(quotes));
    return quotes;
  },

  async deleteQuote(quoteId: string): Promise<QuoteRequest[]> {
    try {
      await fetch(`/api/quotes/${quoteId}`, { method: 'DELETE' });
    } catch (e) {
      console.warn('Server error on deleteQuote:', e);
    }
    const quotes = this.getQuotes().filter((q) => q.id !== quoteId);
    localStorage.setItem(CACHE_KEYS.QUOTES, JSON.stringify(quotes));
    return quotes;
  },

  // Apply discount tiers across products
  async applyDiscountsToAllProducts(tiers: DiscountTier[], categoryId?: string): Promise<Product[]> {
    try {
      const res = await fetch('/api/discounts/apply-all', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ tiers, categoryId }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.products) {
          localStorage.setItem(CACHE_KEYS.PRODUCTS, JSON.stringify(data.products));
          return data.products;
        }
      }
    } catch (e) {
      console.warn('Server error on applyDiscountsToAllProducts:', e);
    }

    // Local fallback update
    const currentProducts = this.getProducts().map((p) => {
      if (!categoryId || categoryId === 'all' || p.category === categoryId) {
        return { ...p, discountTiers: tiers };
      }
      return p;
    });
    localStorage.setItem(CACHE_KEYS.PRODUCTS, JSON.stringify(currentProducts));
    return currentProducts;
  },

  // 6. Media Library & Server File Upload
  async uploadMediaFileServer(file: File, category: string = 'general', customName?: string): Promise<MediaItem> {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('category', category);
    if (customName) formData.append('name', customName);

    const res = await fetch('/api/upload', {
      method: 'POST',
      body: formData,
    });

    if (!res.ok) {
      throw new Error('Failed to upload file to server');
    }

    const data = await res.json();
    const mediaItem: MediaItem = data.mediaItem;
    const current = this.getMedia();
    const updated = [mediaItem, ...current];
    localStorage.setItem(CACHE_KEYS.MEDIA, JSON.stringify(updated));
    return mediaItem;
  },

  async addMediaUrlServer(url: string, name: string, category: MediaItem['category']): Promise<MediaItem> {
    const res = await fetch('/api/media', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, name, category, size: 'رابط خارجي' }),
    });
    const mediaItem: MediaItem = res.ok
      ? await res.json()
      : {
          id: `media-${Date.now()}`,
          name,
          url,
          category,
          size: 'رابط خارجي',
          uploadedAt: new Date().toISOString(),
        };

    const current = this.getMedia();
    const updated = [mediaItem, ...current];
    localStorage.setItem(CACHE_KEYS.MEDIA, JSON.stringify(updated));
    return mediaItem;
  },

  async deleteMediaServer(id: string): Promise<MediaItem[]> {
    try {
      await fetch(`/api/media/${id}`, { method: 'DELETE' });
    } catch (e) {
      console.warn('Server error on deleteMedia:', e);
    }
    const media = this.getMedia().filter((m) => m.id !== id);
    localStorage.setItem(CACHE_KEYS.MEDIA, JSON.stringify(media));
    return media;
  },

  async fetchMediaServer(): Promise<MediaItem[]> {
    try {
      const res = await fetch('/api/media').catch(() => null);
      const data = await parseJsonOrNull<MediaItem[]>(res);
      if (data && Array.isArray(data)) {
        localStorage.setItem(CACHE_KEYS.MEDIA, JSON.stringify(data));
        return data;
      }
    } catch (e) {
      console.warn('Error fetching media from server:', e);
    }
    return this.getMedia();
  },

  // 6.5 Customer Testimonials / Reviews (Real CRUD with Server Persistence)
  async saveTestimonials(testimonials: Testimonial[]): Promise<Testimonial[]> {
    localStorage.setItem(CACHE_KEYS.TESTIMONIALS, JSON.stringify(testimonials));
    try {
      await fetch('/api/testimonials', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(testimonials),
      });
    } catch (e) {
      console.warn('Server error on saveTestimonials:', e);
    }
    return testimonials;
  },

  async fetchTestimonialsServer(): Promise<Testimonial[]> {
    try {
      const res = await fetch('/api/testimonials').catch(() => null);
      const data = await parseJsonOrNull<Testimonial[]>(res);
      if (data && Array.isArray(data) && data.length > 0) {
        localStorage.setItem(CACHE_KEYS.TESTIMONIALS, JSON.stringify(data));
        return data;
      }
    } catch (e) {
      console.warn('Error fetching testimonials from server:', e);
    }
    return this.getTestimonials();
  },

  async fetchServerStatus(): Promise<{
    status: string;
    storage: string;
    dbPath: string;
    serverTime: string;
    stats: {
      ordersCount: number;
      quotesCount: number;
      productsCount: number;
      categoriesCount: number;
      testimonialsCount: number;
      mediaCount: number;
    };
  } | null> {
    try {
      const res = await fetch('/api/status').catch(() => null);
      return await parseJsonOrNull(res);
    } catch (e) {
      console.warn('Error fetching server status:', e);
    }
    return null;
  },

  async addTestimonial(item: Partial<Testimonial>): Promise<Testimonial> {
    const cleanAvatar =
      item.avatar && item.avatar.trim().length > 5
        ? item.avatar.trim()
        : 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&h=120&q=80';

    const newRev: Testimonial = {
      id: item.id || `rev-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: (item.name || '').trim(),
      role: (item.role || 'عميل معتمد لدى إنتر تكنولوجي').trim(),
      content: (item.content || '').trim(),
      rating: Math.max(1, Math.min(5, Number(item.rating) || 5)),
      avatar: cleanAvatar,
      verified: item.verified !== undefined ? Boolean(item.verified) : true,
      productName: item.productName ? item.productName.trim() : undefined,
      date: item.date || new Date().toISOString().split('T')[0],
      status: item.status || 'approved',
    };

    try {
      const res = await fetch('/api/testimonials', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newRev),
      });
      if (res.ok) {
        const saved = await res.json();
        const list = [saved, ...this.getTestimonials().filter((t) => String(t.id) !== String(saved.id))];
        localStorage.setItem(CACHE_KEYS.TESTIMONIALS, JSON.stringify(list));
        return saved;
      }
    } catch (e) {
      console.warn('Server error on addTestimonial, fallback to local storage:', e);
    }

    const current = [newRev, ...this.getTestimonials().filter((t) => String(t.id) !== String(newRev.id))];
    localStorage.setItem(CACHE_KEYS.TESTIMONIALS, JSON.stringify(current));
    return newRev;
  },

  async updateTestimonial(id: string | number, updates: Partial<Testimonial>): Promise<Testimonial | null> {
    const list = this.getTestimonials();
    const index = list.findIndex((t) => String(t.id) === String(id));
    if (index === -1) return null;

    const updated: Testimonial = {
      ...list[index],
      ...updates,
      id: list[index].id,
      rating: updates.rating !== undefined ? Math.max(1, Math.min(5, Number(updates.rating) || 5)) : list[index].rating,
    };

    try {
      const res = await fetch(`/api/testimonials/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      });
      if (res.ok) {
        const serverSaved = await res.json();
        list[index] = serverSaved;
        localStorage.setItem(CACHE_KEYS.TESTIMONIALS, JSON.stringify(list));
        return serverSaved;
      }
    } catch (e) {
      console.warn('Server error on updateTestimonial, fallback to local storage:', e);
    }

    list[index] = updated;
    localStorage.setItem(CACHE_KEYS.TESTIMONIALS, JSON.stringify(list));
    return updated;
  },

  async deleteTestimonial(id: string | number): Promise<boolean> {
    try {
      await fetch(`/api/testimonials/${id}`, { method: 'DELETE' });
    } catch (e) {
      console.warn('Server error on deleteTestimonial:', e);
    }
    const filtered = this.getTestimonials().filter((t) => String(t.id) !== String(id));
    localStorage.setItem(CACHE_KEYS.TESTIMONIALS, JSON.stringify(filtered));
    return true;
  },

  // 7. Admin Auth & Server Login
  isAdminLoggedIn(): boolean {
    return localStorage.getItem(CACHE_KEYS.ADMIN_AUTH) === 'true';
  },

  setAdminLoggedIn(val: boolean) {
    if (val) {
      localStorage.setItem(CACHE_KEYS.ADMIN_AUTH, 'true');
    } else {
      localStorage.removeItem(CACHE_KEYS.ADMIN_AUTH);
    }
  },

  async loginAdminServer(
    password: string,
    username: string = 'admin'
  ): Promise<{ success: boolean; error?: string; remainingAttempts?: number; locked?: boolean; remainingSeconds?: number }> {
    const cleanUser = (username || '').trim().toLowerCase();
    const validUsers = ['admin', 'enter', 'enter.co.ps@gmail.com', 'admin@enter.ps'];
    const customPassword = localStorage.getItem('enter_tech_custom_pwd_value');

    // Helper for offline / local / static-host authentication fallback
    const checkLocalAuth = () => {
      const isUserMatch = validUsers.includes(cleanUser) || cleanUser === 'admin';
      const isPassMatch = password === 'admin123' || (Boolean(customPassword) && password === customPassword);
      if (isUserMatch && isPassMatch) {
        this.setAdminLoggedIn(true);
        localStorage.setItem('enter_tech_admin_token', `local_token_${Date.now()}`);
        return { success: true };
      }
      return null;
    };

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: cleanUser, password }),
      });

      // If server returned 404 (static host without Node API) or 502/503 (reverse proxy not yet connected):
      if (res.status === 404 || res.status === 502 || res.status === 503 || res.status === 504) {
        const local = checkLocalAuth();
        if (local) return local;
        return { success: false, error: 'اسم المستخدم أو كلمة المرور غير صحيحة. (الافتراضي: admin | كلمة المرور: admin123)' };
      }

      const data = await res.json().catch(() => null);

      if (res.ok && data?.success) {
        this.setAdminLoggedIn(true);
        if (data.token) {
          localStorage.setItem('enter_tech_admin_token', data.token);
        }
        return { success: true };
      }

      // Check if credentials match master default even if server threw a status error
      const local = checkLocalAuth();
      if (local && password === 'admin123') {
        return local;
      }

      if (res.status === 429) {
        return {
          success: false,
          locked: true,
          error: data?.error || 'تم قفل المحاولات مؤقتاً لحماية النظام.',
          remainingSeconds: data?.remainingSeconds || 900,
        };
      }

      return {
        success: false,
        error: data?.error || 'بيانات الدخول غير صحيحة. (اسم المستخدم: admin | كلمة المرور: admin123)',
        remainingAttempts: data?.remainingAttempts,
      };
    } catch (e) {
      console.warn('Server login network error, checking local fallback:', e);
      const local = checkLocalAuth();
      if (local) return local;
      return { success: false, error: 'تعذر التحقق من السيرفر. تأكد من إدخال admin وكلمة المرور admin123.' };
    }
  },

  async changePasswordServer(newPassword: string): Promise<{ success: boolean; message?: string }> {
    const trimmed = newPassword.trim();
    localStorage.setItem('enter_tech_custom_pwd_value', trimmed);
    localStorage.setItem('enter_tech_custom_pwd', 'true');

    try {
      const res = await fetch('/api/auth/change-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ newPassword: trimmed }),
      });
      const data = await res.json().catch(() => null);
      if (res.ok && data?.success) {
        return { success: true, message: data.message || 'تم تحديث كلمة المرور بنجاح' };
      }
      return { success: true, message: 'تم حفظ كلمة المرور بنجاح' };
    } catch {
      return { success: true, message: 'تم حفظ كلمة المرور بنجاح (وضع غير متصل)' };
    }
  },

  async resetServerToDefaults(): Promise<void> {
    try {
      await fetch('/api/reset', { method: 'POST' });
    } catch (e) {
      console.warn('Reset error:', e);
    }
    localStorage.clear();
  },
};
