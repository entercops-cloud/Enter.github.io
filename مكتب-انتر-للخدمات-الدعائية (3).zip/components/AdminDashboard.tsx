import React, { useState, useEffect } from 'react';
import {
  Product,
  CategoryItem,
  SiteSettings,
  Order,
  OrderItem,
  QuoteRequest,
  MediaItem,
  AdminNotification,
  OrderWorkflowStatus,
  DiscountTier,
  Testimonial,
} from '../types';
import { store } from '../services/store';
import { DEFAULT_DISCOUNT_TIERS } from '../constants';
import {
  requestBrowserNotificationPermission,
  hasBrowserNotificationPermission,
  sendBrowserNotification,
  playNotificationSound,
} from '../services/notificationService';
import {
  LayoutDashboard,
  Package,
  Layers,
  Palette,
  ShoppingBag,
  FileText,
  KeyRound,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  ExternalLink,
  MessageCircle,
  Save,
  RefreshCw,
  Database,
  Server,
  HardDrive,
  RotateCcw,
  Search,
  Sparkles,
  TrendingUp,
  TrendingDown,
  Percent,
  ShieldCheck,
  Calculator,
  Sliders,
  Tag,
  Eye,
  Image as ImageIcon,
  DollarSign,
  Phone,
  LogOut,
  Bell,
  BellRing,
  Upload,
  Copy,
  Clock,
  Printer,
  PackageCheck,
  CheckCircle2,
  AlertCircle,
  Filter,
  Star,
  CheckCircle,
  MessageSquare,
} from 'lucide-react';

interface AdminDashboardProps {
  isOpen: boolean;
  onClose: () => void;
  onLogout: () => void;
  products: Product[];
  categories: CategoryItem[];
  settings: SiteSettings;
  testimonials?: Testimonial[];
  onUpdateProducts: (newProducts: Product[]) => void;
  onUpdateCategories: (newCats: CategoryItem[]) => void;
  onUpdateSettings: (newSettings: SiteSettings) => void;
  onUpdateTestimonials?: (newTestimonials: Testimonial[]) => void;
}

type TabType =
  | 'overview'
  | 'products'
  | 'categories'
  | 'media'
  | 'design'
  | 'orders'
  | 'quotes'
  | 'discounts'
  | 'testimonials'
  | 'security';

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  isOpen,
  onClose,
  onLogout,
  products,
  categories,
  settings,
  testimonials,
  onUpdateProducts,
  onUpdateCategories,
  onUpdateSettings,
  onUpdateTestimonials,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('overview');

  // Orders and quotes state
  const [orders, setOrders] = useState<Order[]>(() => store.getOrders());
  const [quotes, setQuotes] = useState<QuoteRequest[]>(() => store.getQuotes());
  const [mediaList, setMediaList] = useState<MediaItem[]>(() => store.getMedia());
  const [notifications, setNotifications] = useState<AdminNotification[]>(() => store.getNotifications());

  // Browser notification permission state
  const [hasNotifPermission, setHasNotifPermission] = useState<boolean>(() => hasBrowserNotificationPermission());
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Product form state
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [productForm, setProductForm] = useState<Partial<Product>>({
    name: '',
    category: 'business-cards',
    price: 100,
    unitPrice: 1,
    minQuantity: 100,
    description: '',
    image: '',
    discountTiers: [
      { minQuantity: 250, discountPercentage: 5, label: 'خصم 5%' },
      { minQuantity: 500, discountPercentage: 10, label: 'خصم 10%' },
      { minQuantity: 1000, discountPercentage: 15, label: 'خصم 15%' },
    ],
  });

  // Media Library state
  const [mediaCategoryFilter, setMediaCategoryFilter] = useState<string>('all');
  const [newMediaName, setNewMediaName] = useState('');
  const [newMediaCategory, setNewMediaCategory] = useState<MediaItem['category']>('products');
  const [newMediaUrl, setNewMediaUrl] = useState('');
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [mediaActionMessage, setMediaActionMessage] = useState('');

  // Category form state
  const [newCategoryName, setNewCategoryName] = useState('');
  const [newCategoryId, setNewCategoryId] = useState('');

  // Design / Settings local state
  const [designForm, setDesignForm] = useState<SiteSettings>({ ...settings });
  const [designSuccessMsg, setDesignSuccessMsg] = useState('');

  // Password state & security
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [passwordMsg, setPasswordMsg] = useState('');
  const [passwordError, setPasswordError] = useState('');

  // Filter products in admin
  const [productSearch, setProductSearch] = useState('');

  // Tiered Discounts Management state
  const [discountTiers, setDiscountTiers] = useState<DiscountTier[]>(() => {
    return products[0]?.discountTiers && products[0].discountTiers.length > 0
      ? products[0].discountTiers
      : DEFAULT_DISCOUNT_TIERS;
  });
  const [selectedDiscountCategory, setSelectedDiscountCategory] = useState<string>('all');
  const [discountActionMsg, setDiscountActionMsg] = useState<string>('');
  const [isTierModalOpen, setIsTierModalOpen] = useState(false);
  const [editingTierIndex, setEditingTierIndex] = useState<number | null>(null);
  const [tierForm, setTierForm] = useState<DiscountTier>({ minQuantity: 250, discountPercentage: 10, label: '' });

  // Live Discount Simulator state
  const [simBasePrice, setSimBasePrice] = useState<number>(100);
  const [simQuantity, setSimQuantity] = useState<number>(500);

  // Quotes management & editing state
  const [editingQuote, setEditingQuote] = useState<QuoteRequest | null>(null);
  const [isQuoteModalOpen, setIsQuoteModalOpen] = useState(false);
  const [quoteForm, setQuoteForm] = useState<Partial<QuoteRequest>>({});
  const [quoteSearch, setQuoteSearch] = useState('');
  const [quoteStatusFilter, setQuoteStatusFilter] = useState<string>('all');
  const [quoteActionMsg, setQuoteActionMsg] = useState('');

  // Orders viewing and editing state
  const [viewingOrder, setViewingOrder] = useState<Order | null>(null);
  const [isViewOrderModalOpen, setIsViewOrderModalOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState<Order | null>(null);
  const [isEditOrderModalOpen, setIsEditOrderModalOpen] = useState(false);
  const [editOrderForm, setEditOrderForm] = useState<Partial<Order>>({});
  const [orderActionMsg, setOrderActionMsg] = useState('');
  const [orderSearch, setOrderSearch] = useState('');
  const [orderFilterStatus, setOrderFilterStatus] = useState<string>('all');
  const [selectedNewProductId, setSelectedNewProductId] = useState<string>('');

  // Export PDF / Printable document state
  const [pdfExportOrder, setPdfExportOrder] = useState<Order | null>(null);
  const [isExportPdfModalOpen, setIsExportPdfModalOpen] = useState(false);
  const [exportDocType, setExportDocType] = useState<'invoice' | 'packing_slip'>('invoice');

  // Customer Testimonials / Reviews management state
  const [testimonialsList, setTestimonialsList] = useState<Testimonial[]>(() => testimonials || store.getTestimonials());
  const [testimonialSearch, setTestimonialSearch] = useState('');
  const [testimonialRatingFilter, setTestimonialRatingFilter] = useState<string>('all');
  const [testimonialStatusFilter, setTestimonialStatusFilter] = useState<string>('all');
  const [isTestimonialModalOpen, setIsTestimonialModalOpen] = useState(false);
  const [editingTestimonial, setEditingTestimonial] = useState<Testimonial | null>(null);
  const [testimonialActionMsg, setTestimonialActionMsg] = useState('');
  const [deletingTestimonialId, setDeletingTestimonialId] = useState<string | number | null>(null);

  const [testimonialForm, setTestimonialForm] = useState<Partial<Testimonial>>({
    name: '',
    role: '',
    content: '',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&h=120&q=80',
    verified: true,
    productName: '',
    status: 'approved',
  });

  useEffect(() => {
    if (testimonials) {
      setTestimonialsList(testimonials);
    }
  }, [testimonials]);

  // Sync notifications on mount and window event
  useEffect(() => {
    const handleOrderEvent = () => {
      setOrders(store.getOrders());
      setQuotes(store.getQuotes());
      setNotifications(store.getNotifications());
    };
    window.addEventListener('app_new_order_notification', handleOrderEvent);
    return () => window.removeEventListener('app_new_order_notification', handleOrderEvent);
  }, []);

  useEffect(() => {
    setDesignForm({ ...settings });
  }, [settings]);

  // Server live sync state
  const [isSyncingServer, setIsSyncingServer] = useState(false);
  const [serverSyncTime, setServerSyncTime] = useState<string>(() => new Date().toLocaleTimeString('ar-EG'));
  const [serverDbInfo, setServerDbInfo] = useState<{
    status: string;
    storage: string;
    dbPath: string;
    serverTime: string;
    stats: any;
  } | null>(null);

  const refreshAllFromServer = async (silent: boolean = false) => {
    if (!silent) setIsSyncingServer(true);
    try {
      const fresh = await store.syncFromServer();
      setOrders(fresh.orders);
      setQuotes(fresh.quotes);
      setMediaList(fresh.media);
      if (fresh.testimonials) setTestimonialsList(fresh.testimonials);
      onUpdateProducts(fresh.products);
      onUpdateCategories(fresh.categories);
      onUpdateSettings(fresh.settings);
      if (onUpdateTestimonials && fresh.testimonials) {
        onUpdateTestimonials(fresh.testimonials);
      }
      const statusInfo = await store.fetchServerStatus();
      if (statusInfo) {
        setServerDbInfo(statusInfo);
      }
      setServerSyncTime(new Date().toLocaleTimeString('ar-EG'));
    } catch (err) {
      console.warn('Failed to refresh from server:', err);
    } finally {
      if (!silent) setIsSyncingServer(false);
    }
  };

  // Immediate sync when opening the dashboard + live background sync every 15s
  useEffect(() => {
    if (isOpen) {
      refreshAllFromServer();
      const interval = setInterval(() => {
        refreshAllFromServer(true);
      }, 15000);
      return () => clearInterval(interval);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  // Notification Permission Request
  const handleEnableNotifications = async () => {
    const granted = await requestBrowserNotificationPermission();
    setHasNotifPermission(granted);
    if (granted) {
      sendBrowserNotification(
        'تم تفعيل إشعارات المتصفح بنجاح! 🔔',
        'ستتلقى إشعاراً فورياً مع رنين صوتي عند وصول أي طلب جديد من العملاء.'
      );
    }
  };

  const handleTestNotification = () => {
    playNotificationSound();
    sendBrowserNotification(
      'تنبيه تجريبي: طلب جديد ORD-999',
      'عميل جديد طلب 500 كرت شخصي فاخر بقيمة 350 ₪.'
    );
  };

  // Media Upload File Reader (Uploads directly to Server Disk /uploads/*)
  const handleMediaFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setMediaActionMessage('جاري رفع الصورة إلى السيرفر وتخزينها...');
      await store.uploadMediaFileServer(file, newMediaCategory, newMediaName.trim() || undefined);
      setMediaList(store.getMedia());
      setIsUploadModalOpen(false);
      setNewMediaName('');
      setNewMediaUrl('');
      setMediaActionMessage('تم رفع وحفظ الصورة على السيرفر بنجاح!');
      setTimeout(() => setMediaActionMessage(''), 3000);
    } catch (err) {
      console.error(err);
      setMediaActionMessage('حدث خطأ أثناء رفع الصورة إلى السيرفر.');
    }
  };

  const handleAddMediaUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMediaUrl.trim()) return;

    await store.addMediaUrlServer(newMediaUrl.trim(), newMediaName.trim() || 'صورة مخصصة', newMediaCategory);
    setMediaList(store.getMedia());
    setIsUploadModalOpen(false);
    setNewMediaName('');
    setNewMediaUrl('');
    setMediaActionMessage('تمت إضافة رابط الصورة إلى سيرفر المكتبة بنجاح!');
    setTimeout(() => setMediaActionMessage(''), 3000);
  };

  const handleDeleteMedia = async (id: string) => {
    if (window.confirm('هل تريد حذف هذه الصورة من السيرفر؟')) {
      const updated = await store.deleteMediaServer(id);
      setMediaList(updated);
    }
  };

  const handleSetAsSiteLogo = (url: string) => {
    const updatedSettings = { ...settings, logoUrl: url };
    onUpdateSettings(updatedSettings);
    store.saveSettings(updatedSettings);
    setDesignForm(updatedSettings);
    setMediaActionMessage('تم تعيين هذه الصورة كشعار رسمي للموقع بنجاح!');
    setTimeout(() => setMediaActionMessage(''), 3000);
  };

  const handleCopyMediaUrl = (url: string, id: string) => {
    navigator.clipboard.writeText(url);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Handlers for products
  const handleOpenAddProduct = () => {
    setEditingProduct(null);
    setProductForm({
      name: '',
      category: categories[1]?.id || 'business-cards',
      price: 100,
      unitPrice: 1,
      minQuantity: 100,
      description: '',
      image: mediaList[0]?.url || '/src/assets/images/print_business_cards_1791613344923.jpg',
      discountTiers: [
        { minQuantity: 250, discountPercentage: 5, label: 'خصم 5%' },
        { minQuantity: 500, discountPercentage: 10, label: 'خصم 10%' },
        { minQuantity: 1000, discountPercentage: 15, label: 'خصم 15%' },
        { minQuantity: 2500, discountPercentage: 20, label: 'خصم 20%' },
      ],
    });
    setIsProductModalOpen(true);
  };

  const handleOpenEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setProductForm({ ...prod });
    setIsProductModalOpen(true);
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!productForm.name || !productForm.price) return;

    if (editingProduct) {
      const updatedProd = { ...editingProduct, ...productForm } as Product;
      await store.updateProductServer(updatedProd);
      const updatedList = products.map((p) => (p.id === editingProduct.id ? updatedProd : p));
      onUpdateProducts(updatedList);
    } else {
      const newProd = await store.addProductServer({
        name: productForm.name || 'منتج جديد',
        description: productForm.description || '',
        price: Number(productForm.price) || 0,
        unitPrice:
          Number(productForm.unitPrice) ||
          Number(productForm.price) / Math.max(1, Number(productForm.minQuantity) || 1),
        category: productForm.category || 'business-cards',
        image: productForm.image || mediaList[0]?.url || '',
        minQuantity: Number(productForm.minQuantity) || 1,
        discountTiers: productForm.discountTiers || [],
      });
      onUpdateProducts([newProd, ...products]);
    }
    setIsProductModalOpen(false);
  };

  const handleDeleteProduct = async (id: string) => {
    if (window.confirm('هل أنت متأكد من حذف هذا المنتج من السيرفر؟')) {
      const filtered = await store.deleteProductServer(id);
      onUpdateProducts(filtered);
    }
  };

  // Handlers for categories on server
  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCategoryName.trim()) return;
    const catId = newCategoryId.trim() || undefined;
    const newCat = await store.addCategoryServer(newCategoryName.trim(), catId);
    onUpdateCategories([...categories, newCat]);
    setNewCategoryName('');
    setNewCategoryId('');
  };

  const handleDeleteCategory = async (id: string) => {
    if (id === 'all') {
      alert('لا يمكن حذف الصنف الأساسي (الكل)');
      return;
    }
    if (window.confirm('هل أنت متأكد من حذف هذا الصنف من السيرفر؟')) {
      const updated = await store.deleteCategoryServer(id);
      onUpdateCategories(updated);
    }
  };

  // Handlers for Site Design Settings on server
  const handleSaveDesign = async (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(designForm);
    await store.saveSettings(designForm);
    setDesignSuccessMsg('تم حفظ وتحديث تصميم الموقع على السيرفر بنجاح!');
    setTimeout(() => setDesignSuccessMsg(''), 3000);
  };

  const handleResetDesign = async () => {
    if (window.confirm('هل ترغب في إعادة ضبط الموقع للإعدادات الأصلية على السيرفر؟')) {
      await store.resetServerToDefaults();
      const fresh = await store.syncFromServer();
      onUpdateProducts(fresh.products);
      onUpdateCategories(fresh.categories);
      onUpdateSettings(fresh.settings);
      setMediaList(fresh.media);
      setDesignForm(fresh.settings);
      setDesignSuccessMsg('تم استرجاع الإعدادات الافتراضية بنجاح.');
      setTimeout(() => setDesignSuccessMsg(''), 3000);
    }
  };

  // Handlers for orders workflow on server
  const handleUpdateOrderStatus = async (
    orderId: string,
    status: OrderWorkflowStatus,
    statusNote?: string,
    estimatedDate?: string
  ) => {
    const updated = await store.updateOrderStatus(orderId, status, statusNote, estimatedDate);
    setOrders([...updated]);
  };

  const handleDeleteOrder = async (orderId: string) => {
    if (window.confirm('حذف هذا الطلب من السيرفر؟')) {
      const updated = await store.deleteOrder(orderId);
      setOrders([...updated]);
      setOrderActionMsg('تم حذف الطلب بنجاح من السيرفر');
      setTimeout(() => setOrderActionMsg(''), 3000);
    }
  };

  // Order View, Export PDF & Edit Handlers
  const handleOpenExportPdf = (order: Order, type: 'invoice' | 'packing_slip' = 'invoice') => {
    setPdfExportOrder(order);
    setExportDocType(type);
    setIsExportPdfModalOpen(true);
  };

  const handleOpenViewOrder = (order: Order) => {
    setViewingOrder(order);
    setIsViewOrderModalOpen(true);
  };

  const handleOpenEditOrder = (order: Order) => {
    setEditingOrder(order);
    setEditOrderForm({
      ...order,
      items: order.items.map((it) => ({ ...it })),
    });
    setSelectedNewProductId('');
    setIsEditOrderModalOpen(true);
  };

  const recalculateOrderTotals = (items: OrderItem[]) => {
    const subtotal = items.reduce((sum, it) => sum + (it.unitPrice * it.quantity), 0);
    const finalTotal = items.reduce((sum, it) => sum + it.totalPrice, 0);
    const discountTotal = Math.max(0, subtotal - finalTotal);
    setEditOrderForm((prev) => ({
      ...prev,
      items,
      subtotal: Math.round(subtotal),
      discountTotal: Math.round(discountTotal),
      finalTotal: Math.round(finalTotal),
    }));
  };

  const handleItemQuantityChange = (index: number, newQty: number) => {
    if (!editOrderForm.items) return;
    const qty = Math.max(1, Number(newQty) || 1);
    const newItems = editOrderForm.items.map((it, idx) => {
      if (idx === index) {
        const discount = it.discountPercentage || 0;
        const totalPrice = Math.round(it.unitPrice * qty * (1 - discount / 100));
        return { ...it, quantity: qty, totalPrice };
      }
      return it;
    });
    recalculateOrderTotals(newItems);
  };

  const handleItemUnitPriceChange = (index: number, newUnitPrice: number) => {
    if (!editOrderForm.items) return;
    const price = Math.max(0, Number(newUnitPrice) || 0);
    const newItems = editOrderForm.items.map((it, idx) => {
      if (idx === index) {
        const discount = it.discountPercentage || 0;
        const totalPrice = Math.round(price * it.quantity * (1 - discount / 100));
        return { ...it, unitPrice: price, totalPrice };
      }
      return it;
    });
    recalculateOrderTotals(newItems);
  };

  const handleItemCustomTextChange = (index: number, text: string) => {
    if (!editOrderForm.items) return;
    const newItems = editOrderForm.items.map((it, idx) => (idx === index ? { ...it, customText: text } : it));
    setEditOrderForm((prev) => ({ ...prev, items: newItems }));
  };

  const handleRemoveOrderItem = (index: number) => {
    if (!editOrderForm.items) return;
    if (editOrderForm.items.length <= 1) {
      alert('يجب أن تحتوي الطلبية على صنف واحد على الأقل.');
      return;
    }
    const newItems = editOrderForm.items.filter((_, idx) => idx !== index);
    recalculateOrderTotals(newItems);
  };

  const handleAddProductToOrder = () => {
    if (!selectedNewProductId) return;
    const prod = products.find((p) => p.id === selectedNewProductId);
    if (!prod) return;

    const minQty = prod.minQuantity || 1;
    const unitP = prod.unitPrice || (prod.price / Math.max(1, minQty));
    const newItem: OrderItem = {
      id: `item-${Date.now()}`,
      productId: prod.id,
      productName: prod.name,
      quantity: minQty,
      unitPrice: unitP,
      discountPercentage: 0,
      totalPrice: Math.round(prod.price),
    };

    const newItems = [...(editOrderForm.items || []), newItem];
    setSelectedNewProductId('');
    recalculateOrderTotals(newItems);
  };

  const handleSaveEditOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingOrder || !editOrderForm.customerName || !editOrderForm.customerPhone) {
      alert('يرجى ملء اسم العميل ورقم هاتفه');
      return;
    }

    const updated: Order = {
      ...editingOrder,
      customerName: editOrderForm.customerName.trim(),
      customerPhone: editOrderForm.customerPhone.trim(),
      customerAddress: editOrderForm.customerAddress?.trim() || undefined,
      notes: editOrderForm.notes?.trim() || undefined,
      status: (editOrderForm.status as OrderWorkflowStatus) || editingOrder.status,
      statusNote: editOrderForm.statusNote?.trim() || editingOrder.statusNote,
      estimatedDate: editOrderForm.estimatedDate?.trim() || editingOrder.estimatedDate,
      items: editOrderForm.items || editingOrder.items,
      subtotal: editOrderForm.subtotal !== undefined ? Number(editOrderForm.subtotal) : editingOrder.subtotal,
      discountTotal: editOrderForm.discountTotal !== undefined ? Number(editOrderForm.discountTotal) : editingOrder.discountTotal,
      finalTotal: editOrderForm.finalTotal !== undefined ? Number(editOrderForm.finalTotal) : editingOrder.finalTotal,
      updatedAt: new Date().toISOString(),
    };

    const newOrders = await store.updateOrder(updated);
    setOrders(newOrders);
    setIsEditOrderModalOpen(false);
    setOrderActionMsg(`تم تحديث وتعديل بيانات الطلب (${updated.id}) بنجاح ✓`);
    setTimeout(() => setOrderActionMsg(''), 4000);
  };

  // Handlers for Tiered Discounts Management
  const handleOpenAddTier = () => {
    setEditingTierIndex(null);
    setTierForm({ minQuantity: 100, discountPercentage: 5, label: '' });
    setIsTierModalOpen(true);
  };

  const handleOpenEditTier = (index: number) => {
    setEditingTierIndex(index);
    setTierForm({ ...discountTiers[index] });
    setIsTierModalOpen(true);
  };

  const handleSaveTier = (e: React.FormEvent) => {
    e.preventDefault();
    const minQty = Math.max(1, Number(tierForm.minQuantity) || 1);
    const discPct = Math.min(99, Math.max(1, Number(tierForm.discountPercentage) || 1));
    const label = tierForm.label?.trim() || `خصم ${discPct}% عند طلب ${minQty.toLocaleString()}+`;

    const newTier: DiscountTier = {
      minQuantity: minQty,
      discountPercentage: discPct,
      label,
    };

    let updatedTiers: DiscountTier[];
    if (editingTierIndex !== null) {
      updatedTiers = discountTiers.map((t, idx) => (idx === editingTierIndex ? newTier : t));
    } else {
      updatedTiers = [...discountTiers, newTier];
    }
    updatedTiers.sort((a, b) => a.minQuantity - b.minQuantity);
    setDiscountTiers(updatedTiers);
    setIsTierModalOpen(false);
  };

  const handleDeleteTier = (index: number) => {
    if (discountTiers.length <= 1) {
      alert('يجب الإبقاء على شريحة خصم واحدة على الأقل');
      return;
    }
    if (window.confirm('هل أنت متأكد من حذف هذه الشريحة؟')) {
      const updated = discountTiers.filter((_, idx) => idx !== index);
      setDiscountTiers(updated);
    }
  };

  const handleApplyDiscountsToProducts = async () => {
    try {
      const updatedProducts = await store.applyDiscountsToAllProducts(discountTiers, selectedDiscountCategory);
      onUpdateProducts(updatedProducts);
      const catName =
        selectedDiscountCategory === 'all'
          ? 'جميع المنتجات'
          : categories.find((c) => c.id === selectedDiscountCategory)?.name || selectedDiscountCategory;
      setDiscountActionMsg(`تم تطبيق ${discountTiers.length} شرائح خصم بنجاح على ${catName}! ✨`);
      setTimeout(() => setDiscountActionMsg(''), 4500);
    } catch {
      setDiscountActionMsg('حدث خطأ أثناء تطبيق الخصومات على السيرفر');
      setTimeout(() => setDiscountActionMsg(''), 3500);
    }
  };

  const handleResetDefaultTiers = () => {
    if (window.confirm('هل ترغب في استعادة شرائح الخصم الافتراضية؟')) {
      setDiscountTiers(DEFAULT_DISCOUNT_TIERS);
      setDiscountActionMsg('تمت استعادة شرائح الخصم الافتراضية.');
      setTimeout(() => setDiscountActionMsg(''), 3000);
    }
  };

  // Handlers for quotes on server
  const handleUpdateQuoteStatus = async (quoteId: string, status: QuoteRequest['status']) => {
    const updated = await store.updateQuoteStatus(quoteId, status);
    setQuotes([...updated]);
  };

  const handleDeleteQuote = async (quoteId: string) => {
    if (window.confirm('هل أنت متأكد من حذف طلب عرض السعر هذا نهائياً من السيرفر؟')) {
      const updated = await store.deleteQuote(quoteId);
      setQuotes([...updated]);
      setQuoteActionMsg('تم حذف عرض السعر بنجاح');
      setTimeout(() => setQuoteActionMsg(''), 3000);
    }
  };

  const handleOpenEditQuote = (quote: QuoteRequest) => {
    setEditingQuote(quote);
    setQuoteForm({ ...quote });
    setIsQuoteModalOpen(true);
  };

  const handleSaveQuote = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingQuote || !quoteForm.customerName || !quoteForm.phone) return;

    const updated: QuoteRequest = {
      ...editingQuote,
      customerName: quoteForm.customerName.trim(),
      phone: quoteForm.phone.trim(),
      serviceName: quoteForm.serviceName?.trim() || editingQuote.serviceName,
      details: quoteForm.details?.trim() || editingQuote.details,
      quantity: quoteForm.quantity !== undefined && quoteForm.quantity !== null && !isNaN(Number(quoteForm.quantity))
        ? Number(quoteForm.quantity)
        : editingQuote.quantity,
      status: (quoteForm.status as QuoteRequest['status']) || editingQuote.status,
      offeredPrice: quoteForm.offeredPrice !== undefined && quoteForm.offeredPrice !== null && !isNaN(Number(quoteForm.offeredPrice))
        ? Number(quoteForm.offeredPrice)
        : undefined,
      adminNotes: quoteForm.adminNotes !== undefined ? quoteForm.adminNotes.trim() : editingQuote.adminNotes,
      updatedAt: new Date().toISOString(),
    };

    const newQuotes = await store.updateQuote(updated);
    setQuotes(newQuotes);
    setIsQuoteModalOpen(false);
    setQuoteActionMsg('تم حفظ وتحديث بيانات عرض السعر بنجاح ✓');
    setTimeout(() => setQuoteActionMsg(''), 3500);
  };

  const handleSendWhatsAppProposal = (q: QuoteRequest) => {
    const priceText = q.offeredPrice ? `💰 السعر المقترح للطلب: ${q.offeredPrice} ₪` : '💰 سيتم تزويدكم بالتسعيرة الدقيقة بعد مراجعة ملف التصميم';
    const notesText = q.adminNotes ? `\n📝 ملاحظات وتوصيات فنية: ${q.adminNotes}` : '';
    const qtyText = q.quantity ? `\n🔢 الكمية: ${q.quantity}` : '';

    const text = `مرحباً أستاذ/ة ${q.customerName} المحترم/ة 🌸\n` +
      `تحية طيبة من شركة إنتر تكنولوجي للطباعة والدعاية والإعلان.\n` +
      `بخصوص طلب عرض السعر رقم (${q.id}):\n` +
      `📌 الخدمة المطلوبة: ${q.serviceName}${qtyText}\n` +
      `📋 التفاصيل: ${q.details}\n` +
      `${priceText}${notesText}\n\n` +
      `✨ يشمل العرض التدقيق الفني المسبق والمعاينة، وضمان مطابقة الألوان.\n` +
      `🚚 خدمة التوصيل متوفرة لجميع المناطق.\n\n` +
      `يسعدنا تأكيد طلبكم للبدء فوراً في التجهيز.`;

    sendWhatsAppMessage(q.phone, text);
  };

  // Password change handler with strict verification
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordMsg('');
    setPasswordError('');

    if (!newPassword || newPassword.trim().length < 6) {
      setPasswordError('يرجى إدخال كلمة مرور جديدة مكونة من 6 خانات على الأقل.');
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordError('كلمتا المرور غير متطابقتين. يرجى إعادة التأكيد بعناية.');
      return;
    }

    const res = await store.changePasswordServer(newPassword.trim());
    if (res.success) {
      setPasswordMsg('تم تحديث كلمة المرور على السيرفر بنجاح! تم إلغاء كلمة المرور الافتراضية admin123 فوراً.');
      setNewPassword('');
      setConfirmPassword('');
      setTimeout(() => setPasswordMsg(''), 5000);
    } else {
      setPasswordError(res.message || 'تعذر تحديث كلمة المرور.');
    }
  };

  // WhatsApp click generator
  const sendWhatsAppMessage = (phone: string, text: string) => {
    const cleanPhone = phone.replace(/[^0-9]/g, '');
    const url = `https://wa.me/${cleanPhone.startsWith('05') ? '970' + cleanPhone.slice(1) : cleanPhone}?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };

  // Testimonial Handlers (Add, Edit, Delete, Toggle Status)
  const handleOpenAddTestimonial = () => {
    setEditingTestimonial(null);
    setTestimonialForm({
      name: '',
      role: '',
      content: '',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&h=120&q=80',
      verified: true,
      productName: products[0]?.name || 'كروت شخصية فاخرة',
      status: 'approved',
    });
    setIsTestimonialModalOpen(true);
  };

  const handleOpenEditTestimonial = (test: Testimonial) => {
    setEditingTestimonial(test);
    setTestimonialForm({
      name: test.name,
      role: test.role,
      content: test.content,
      rating: test.rating || 5,
      avatar: test.avatar,
      verified: test.verified !== undefined ? test.verified : true,
      productName: test.productName || '',
      status: test.status || 'approved',
    });
    setIsTestimonialModalOpen(true);
  };

  const handleSaveTestimonial = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!testimonialForm.name || !testimonialForm.content) return;

    if (editingTestimonial) {
      const updated = await store.updateTestimonial(editingTestimonial.id, testimonialForm);
      if (updated) {
        const newList = testimonialsList.map((t) => (String(t.id) === String(editingTestimonial.id) ? updated : t));
        setTestimonialsList(newList);
        onUpdateTestimonials?.(newList);
        setTestimonialActionMsg('تم تحديث التقييم بنجاح وحفظ التغييرات');
      }
    } else {
      const created = await store.addTestimonial(testimonialForm);
      const newList = [created, ...testimonialsList];
      setTestimonialsList(newList);
      onUpdateTestimonials?.(newList);
      setTestimonialActionMsg('تمت إضافة التقييم الجديد بنجاح');
    }
    setIsTestimonialModalOpen(false);
    setTimeout(() => setTestimonialActionMsg(''), 4000);
  };

  const handleDeleteTestimonial = async (id: string | number) => {
    await store.deleteTestimonial(id);
    const newList = testimonialsList.filter((t) => String(t.id) !== String(id));
    setTestimonialsList(newList);
    onUpdateTestimonials?.(newList);
    setDeletingTestimonialId(null);
    setTestimonialActionMsg('تم حذف التقييم بنجاح');
    setTimeout(() => setTestimonialActionMsg(''), 4000);
  };

  const handleToggleTestimonialStatus = async (test: Testimonial) => {
    const newStatus = test.status === 'pending' ? 'approved' : 'pending';
    const updated = await store.updateTestimonial(test.id, { status: newStatus });
    if (updated) {
      const newList = testimonialsList.map((t) => (String(t.id) === String(test.id) ? updated : t));
      setTestimonialsList(newList);
      onUpdateTestimonials?.(newList);
      setTestimonialActionMsg(newStatus === 'approved' ? 'تم اعتماد ونشر التقييم في الموقع' : 'تم تحويل التقييم إلى قيد المراجعة');
      setTimeout(() => setTestimonialActionMsg(''), 4000);
    }
  };

  const handleToggleTestimonialVerified = async (test: Testimonial) => {
    const newVerified = !test.verified;
    const updated = await store.updateTestimonial(test.id, { verified: newVerified });
    if (updated) {
      const newList = testimonialsList.map((t) => (String(t.id) === String(test.id) ? updated : t));
      setTestimonialsList(newList);
      onUpdateTestimonials?.(newList);
      setTestimonialActionMsg(newVerified ? 'تم وسم العميل كعميل موثق' : 'تم إلغاء وسم التوثيق');
      setTimeout(() => setTestimonialActionMsg(''), 4000);
    }
  };

  const filteredTestimonials = testimonialsList.filter((t) => {
    const q = testimonialSearch.toLowerCase().trim();
    const matchesSearch =
      !q ||
      t.name.toLowerCase().includes(q) ||
      t.role.toLowerCase().includes(q) ||
      t.content.toLowerCase().includes(q) ||
      (t.productName && t.productName.toLowerCase().includes(q));

    const matchesRating =
      testimonialRatingFilter === 'all' ||
      String(t.rating || 5) === testimonialRatingFilter;

    const matchesStatus =
      testimonialStatusFilter === 'all' ||
      (t.status || 'approved') === testimonialStatusFilter;

    return matchesSearch && matchesRating && matchesStatus;
  });

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(productSearch.toLowerCase()) ||
      p.category.toLowerCase().includes(productSearch.toLowerCase())
  );

  const filteredMedia = mediaList.filter(
    (m) => mediaCategoryFilter === 'all' || m.category === mediaCategoryFilter
  );

  const totalRevenue = orders.reduce((sum, ord) => sum + (ord.finalTotal || 0), 0);
  const unreadNotifsCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="fixed inset-0 z-50 flex bg-gray-900/60 backdrop-blur-sm overflow-hidden font-sans" dir="rtl">
      <div className="w-full h-full bg-white flex flex-col md:flex-row shadow-2xl">
        
        {/* Sidebar */}
        <aside className="w-full md:w-64 bg-brand-dark text-white p-4 flex flex-col justify-between shrink-0 border-b md:border-b-0 md:border-l border-gray-800">
          <div>
            {/* Header Brand */}
            <div className="flex items-center justify-between pb-5 mb-5 border-b border-white/10">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-brand-yellow text-brand-purple flex items-center justify-center font-black">
                  IT
                </div>
                <div>
                  <h3 className="font-bold text-sm text-brand-yellow">لوحة تحكم الإدارة</h3>
                  <p className="text-[11px] text-gray-400">نظام إدارة المطبوعات الكامل</p>
                </div>
              </div>
              <button onClick={onClose} className="md:hidden text-gray-400 hover:text-white p-1">
                <X size={20} />
              </button>
            </div>

            {/* Nav Tabs */}
            <nav className="space-y-1.5 text-xs font-semibold">
              <button
                onClick={() => setActiveTab('overview')}
                className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition-all ${
                  activeTab === 'overview'
                    ? 'bg-brand-purple text-white shadow-md'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <LayoutDashboard size={17} />
                <span>نظرة عامة وإحصائيات</span>
              </button>

              <button
                onClick={() => setActiveTab('orders')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all ${
                  activeTab === 'orders'
                    ? 'bg-brand-purple text-white shadow-md'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <ShoppingBag size={17} />
                  <span>متابعة وسير الطلبات</span>
                </div>
                <span className="text-[10px] bg-emerald-500/80 px-1.5 py-0.5 rounded-full text-white">
                  {orders.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('media')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all ${
                  activeTab === 'media'
                    ? 'bg-brand-purple text-white shadow-md'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <ImageIcon size={17} />
                  <span>مكتبة الصور والشعار</span>
                </div>
                <span className="text-[10px] bg-brand-yellow text-brand-purple px-1.5 py-0.5 rounded-full font-bold">
                  {mediaList.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('products')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all ${
                  activeTab === 'products'
                    ? 'bg-brand-purple text-white shadow-md'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Package size={17} />
                  <span>إدارة المنتجات والأسعار</span>
                </div>
                <span className="text-[10px] bg-white/15 px-1.5 py-0.5 rounded-full">{products.length}</span>
              </button>

              <button
                onClick={() => setActiveTab('categories')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all ${
                  activeTab === 'categories'
                    ? 'bg-brand-purple text-white shadow-md'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Layers size={17} />
                  <span>الأصناف والتصنيفات</span>
                </div>
                <span className="text-[10px] bg-white/15 px-1.5 py-0.5 rounded-full">{categories.length}</span>
              </button>

              <button
                onClick={() => setActiveTab('design')}
                className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition-all ${
                  activeTab === 'design'
                    ? 'bg-brand-purple text-white shadow-md'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <Palette size={17} />
                <span>تصميم وهوية الموقع</span>
              </button>

              <button
                onClick={() => setActiveTab('quotes')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all ${
                  activeTab === 'quotes'
                    ? 'bg-brand-purple text-white shadow-md'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <FileText size={17} />
                  <span>عروض الأسعار</span>
                </div>
                <span className="text-[10px] bg-amber-500/80 px-1.5 py-0.5 rounded-full text-white">
                  {quotes.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('discounts')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all ${
                  activeTab === 'discounts'
                    ? 'bg-brand-purple text-white shadow-md'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Percent size={17} />
                  <span>الخصومات والكميات</span>
                </div>
                <span className="text-[10px] bg-brand-yellow text-brand-purple font-black px-1.5 py-0.5 rounded-full">
                  {discountTiers.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('testimonials')}
                className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl transition-all ${
                  activeTab === 'testimonials'
                    ? 'bg-brand-purple text-white shadow-md'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <Star size={17} />
                  <span>الآراء والتقييمات</span>
                </div>
                <span className="text-[10px] bg-brand-yellow text-brand-purple font-black px-1.5 py-0.5 rounded-full">
                  {testimonialsList.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('security')}
                className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl transition-all ${
                  activeTab === 'security'
                    ? 'bg-brand-purple text-white shadow-md'
                    : 'text-gray-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <KeyRound size={17} />
                <span>أمان وكلمة المرور</span>
              </button>
            </nav>
          </div>

          {/* Bottom Actions */}
          <div className="pt-4 border-t border-white/10 space-y-2">
            <button
              onClick={onClose}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-bold bg-white/10 hover:bg-white/20 text-white transition-colors"
            >
              <ExternalLink size={14} />
              <span>معاينة الموقع للعملاء</span>
            </button>
            <button
              onClick={onLogout}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-xs font-bold text-red-400 hover:bg-red-500/10 transition-colors"
            >
              <LogOut size={14} />
              <span>تسجيل الخروج</span>
            </button>
          </div>
        </aside>

        {/* Main Content Area */}
        <main className="flex-grow p-4 sm:p-7 overflow-y-auto bg-gray-50/70">
          
          {/* Top Bar with Browser Notification Toggle */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 mb-6 border-b border-gray-200">
            <div>
              <h1 className="text-2xl font-black text-gray-900">
                {activeTab === 'overview' && 'نظرة عامة وإحصائيات سريعة'}
                {activeTab === 'orders' && 'متابعة وسير مراحل تنفيذ الطلبات'}
                {activeTab === 'media' && 'مكتبة الصور والشعار الخاصة'}
                {activeTab === 'products' && 'إدارة المنتجات والمطبوعات'}
                {activeTab === 'categories' && 'إدارة الأصناف والتصنيفات'}
                {activeTab === 'design' && 'التحكم بكامل تصميم الموقع والصور'}
                {activeTab === 'quotes' && 'طلبات عروض الأسعار المستلمة'}
                {activeTab === 'discounts' && 'الخصومات وباقات التوفير التصاعدية'}
                {activeTab === 'testimonials' && 'إدارة آراء وتقييمات العملاء وتعديلها'}
                {activeTab === 'security' && 'إعدادات الأمان والدخول'}
              </h1>
              <p className="text-xs text-gray-500 mt-0.5">
                تحديثات فورية تنعكس مباشرة على تجربة الزوار وصفحة تتبع الطلبات
              </p>
            </div>

            {/* Server Persistence & Notifications Toolbar */}
            <div className="flex flex-wrap items-center gap-2 self-start sm:self-auto">
              {/* Server Live Status Badge */}
              {serverDbInfo ? (
                <div
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-xl text-xs font-bold"
                  title={`مسار التخزين على السيرفر: ${serverDbInfo.dbPath || '/data/db.json'}`}
                >
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                  </span>
                  <Server size={14} className="text-emerald-700" />
                  <span>متصل بالسيرفر (db.json)</span>
                </div>
              ) : (
                <div
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-50 border border-amber-200 text-amber-800 rounded-xl text-xs font-bold"
                  title="الموقع يعمل في وضع الاستضافة الثابتة (مثل Netlify). يتم حفظ الطلبات محلياً وإرسالها فوراً إلى واتساب."
                >
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
                  <Server size={14} className="text-amber-600" />
                  <span>وضع الاستضافة الثابتة (Netlify)</span>
                </div>
              )}

              {/* Server Sync Button */}
              <button
                onClick={() => refreshAllFromServer()}
                disabled={isSyncingServer}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-brand-purple hover:bg-[#4d2377] text-white rounded-xl text-xs font-bold transition-all shadow-xs active:scale-95 disabled:opacity-50"
                title={`آخر فحص: ${serverSyncTime}`}
              >
                <RefreshCw size={13} className={isSyncingServer ? 'animate-spin' : ''} />
                <span>{isSyncingServer ? 'مزامنة...' : 'تحديث من السيرفر'}</span>
              </button>

              {/* Notification Permission Toggle */}
              {hasNotifPermission ? (
                <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 bg-gray-100 border border-gray-200 text-gray-700 rounded-xl text-xs font-semibold">
                  <BellRing size={14} className="text-emerald-600" />
                  <span>الإشعارات مفعلة</span>
                </div>
              ) : (
                <button
                  onClick={handleEnableNotifications}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold transition-all shadow-xs active:scale-95"
                >
                  <Bell size={14} />
                  <span>تفعيل الإشعارات 🔔</span>
                </button>
              )}

              {/* Test Audio Chime button */}
              <button
                onClick={handleTestNotification}
                className="hidden sm:block px-2.5 py-1.5 bg-white border border-gray-200 hover:bg-gray-100 rounded-xl text-xs text-gray-700 font-semibold transition-colors"
                title="تشغيل تنبيه تجريبي بالصوت والإشعار"
              >
                رنين 🔊
              </button>

              <button
                onClick={onClose}
                className="hidden md:flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-300 hover:bg-gray-100 rounded-xl text-xs font-bold text-gray-700 transition-colors shadow-xs"
              >
                <span>الرجوع للموقع</span>
                <X size={15} />
              </button>
            </div>
          </div>

          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Stat Cards */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs">
                  <div className="flex items-center justify-between text-gray-400 mb-2">
                    <span className="text-xs font-bold">إجمالي الطلبات</span>
                    <ShoppingBag size={20} className="text-emerald-600" />
                  </div>
                  <div className="text-2xl font-black text-gray-900">{orders.length}</div>
                  <div className="text-[11px] text-emerald-600 font-semibold mt-1">طلبات قيد المتابعة</div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs">
                  <div className="flex items-center justify-between text-gray-400 mb-2">
                    <span className="text-xs font-bold">صور المكتبة</span>
                    <ImageIcon size={20} className="text-brand-yellow" />
                  </div>
                  <div className="text-2xl font-black text-gray-900">{mediaList.length}</div>
                  <div className="text-[11px] text-gray-500 mt-1">صور وشعارات مرفوعة</div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs">
                  <div className="flex items-center justify-between text-gray-400 mb-2">
                    <span className="text-xs font-bold">إجمالي المنتجات</span>
                    <Package size={20} className="text-brand-purple" />
                  </div>
                  <div className="text-2xl font-black text-gray-900">{products.length}</div>
                  <div className="text-[11px] text-gray-500 mt-1">مطبوعات نشطة في المتجر</div>
                </div>

                <div className="bg-white p-5 rounded-2xl border border-gray-200/80 shadow-xs">
                  <div className="flex items-center justify-between text-gray-400 mb-2">
                    <span className="text-xs font-bold">قيمة المبيعات التقديرية</span>
                    <DollarSign size={20} className="text-brand-yellow" />
                  </div>
                  <div className="text-2xl font-black text-brand-purple">{totalRevenue.toLocaleString()} ₪</div>
                  <div className="text-[11px] text-gray-500 mt-1">شامل الخصومات التصاعدية</div>
                </div>
              </div>

              {/* Notification Banner */}
              <div className="bg-gradient-to-r from-brand-purple/10 to-indigo-50 p-5 rounded-2xl border border-brand-purple/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-brand-purple text-white flex items-center justify-center shrink-0">
                    <BellRing size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-brand-dark">نظام الإشعارات المباشرة للمطبعة</h3>
                    <p className="text-xs text-gray-600">
                      بمجرد أن يقوم أي عميل بتأكيد طلب جديد، سيصدر تنبيه صوتي وإشعار فوري على سطح المكتب.
                    </p>
                  </div>
                </div>

                <button
                  onClick={handleTestNotification}
                  className="bg-brand-purple text-white px-4 py-2 rounded-xl text-xs font-bold hover:bg-[#4d2377] transition-all shrink-0"
                >
                  اختبار الصوت الآن
                </button>
              </div>

              {/* Server Database Persistence Verification Card */}
              <div className="bg-white p-5 sm:p-6 rounded-2xl border border-emerald-200/80 shadow-xs">
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 pb-4 border-b border-gray-100">
                  <div className="flex items-start gap-3.5">
                    <div className="w-11 h-11 rounded-xl bg-emerald-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                      <Database size={22} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold text-base text-gray-900">
                          حالة التخزين المركزي على السيرفر (Server-Side Storage)
                        </h3>
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800">
                          <CheckCircle2 size={12} />
                          نشط ومحفوظ
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                        جميع البيانات مخزنة فعلياً على القرص الصلب للسيرفر في ملف <code className="bg-gray-100 text-brand-purple font-mono px-1.5 py-0.5 rounded text-[11px]">/data/db.json</code> والمرفقات داخل <code className="bg-gray-100 text-brand-purple font-mono px-1.5 py-0.5 rounded text-[11px]">/uploads/</code>. لا يعتمد الموقع على ذاكرة المتصفح، وتظهر الطلبات والتعديلات لجميع الأجهزة تلقائياً فورياً.
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 shrink-0">
                    <a
                      href="/api/backup"
                      download="enter_tech_db_backup.json"
                      className="flex items-center gap-1.5 px-3.5 py-2 bg-gray-100 hover:bg-gray-200 text-gray-800 rounded-xl text-xs font-bold transition-all shadow-xs"
                      title="تحميل نسخة احتياطية من ملف قاعدة البيانات db.json"
                    >
                      <HardDrive size={15} />
                      <span>تحميل نسخة احتياطية (JSON)</span>
                    </a>

                    <button
                      onClick={() => refreshAllFromServer()}
                      disabled={isSyncingServer}
                      className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs disabled:opacity-50"
                    >
                      <RefreshCw size={14} className={isSyncingServer ? 'animate-spin' : ''} />
                      <span>{isSyncingServer ? 'جاري الفحص...' : 'فحص السيرفر الآن'}</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 pt-4 text-center">
                  <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                    <div className="text-[11px] text-gray-500">الطلبات بالسيرفر</div>
                    <div className="text-lg font-black text-emerald-600">{serverDbInfo?.stats?.ordersCount ?? orders.length}</div>
                  </div>
                  <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                    <div className="text-[11px] text-gray-500">عروض الأسعار</div>
                    <div className="text-lg font-black text-indigo-600">{serverDbInfo?.stats?.quotesCount ?? quotes.length}</div>
                  </div>
                  <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                    <div className="text-[11px] text-gray-500">المنتجات النشطة</div>
                    <div className="text-lg font-black text-brand-purple">{serverDbInfo?.stats?.productsCount ?? products.length}</div>
                  </div>
                  <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                    <div className="text-[11px] text-gray-500">أصناف المطبوعات</div>
                    <div className="text-lg font-black text-brand-dark">{serverDbInfo?.stats?.categoriesCount ?? categories.length}</div>
                  </div>
                  <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                    <div className="text-[11px] text-gray-500">الآراء والتقييمات</div>
                    <div className="text-lg font-black text-amber-600">{serverDbInfo?.stats?.testimonialsCount ?? testimonialsList.length}</div>
                  </div>
                  <div className="bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                    <div className="text-[11px] text-gray-500">الملفات والميديا</div>
                    <div className="text-lg font-black text-teal-600">{serverDbInfo?.stats?.mediaCount ?? mediaList.length}</div>
                  </div>
                </div>
              </div>

              {/* Quick Actions & Recent Orders */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-sm text-gray-900 flex items-center gap-2">
                      <ShoppingBag size={17} className="text-brand-purple" />
                      آخر الطلبات المسجلة
                    </h3>
                    <button
                      onClick={() => setActiveTab('orders')}
                      className="text-xs text-brand-purple font-bold hover:underline"
                    >
                      إدارة سير العمل ({orders.length})
                    </button>
                  </div>

                  <div className="space-y-3">
                    {orders.slice(0, 3).map((ord) => (
                      <div
                        key={ord.id}
                        className="p-3 bg-gray-50 rounded-xl border border-gray-200/60 flex items-center justify-between text-xs"
                      >
                        <div>
                          <div className="font-bold text-gray-900">{ord.customerName} ({ord.id})</div>
                          <div className="text-gray-500 text-[11px]">
                            {ord.items.length} منتجات · {ord.finalTotal} ₪ · {ord.statusNote || 'قيد المتابعة'}
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => sendWhatsAppMessage(ord.customerPhone, `مرحباً ${ord.customerName}، نتواصل معك بخصوص طلبك رقم ${ord.id} من إنتر تكنولوجي`)}
                            className="p-1.5 bg-[#25D366] text-white rounded-lg hover:bg-emerald-600"
                            title="مراسلة عبر واتساب"
                          >
                            <MessageCircle size={14} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Media Library Quick Card */}
                <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="font-bold text-sm text-gray-900 flex items-center gap-2">
                      <ImageIcon size={17} className="text-brand-yellow" />
                      مكتبة الصور والشعارات ({mediaList.length})
                    </h3>
                    <button
                      onClick={() => setActiveTab('media')}
                      className="text-xs text-brand-purple font-bold hover:underline"
                    >
                      فتح المكتبة ورفع صور
                    </button>
                  </div>

                  <div className="grid grid-cols-4 gap-2">
                    {mediaList.slice(0, 4).map((m) => (
                      <div key={m.id} className="relative rounded-xl overflow-hidden border border-gray-200 aspect-square">
                        <img src={m.url} alt={m.name} className="w-full h-full object-cover" />
                        <span className="absolute bottom-0 inset-x-0 bg-black/60 text-white text-[9px] p-0.5 truncate text-center">
                          {m.name}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: ORDERS WORKFLOW TRACKING */}
          {activeTab === 'orders' && (
            <div className="space-y-6">
              {orderActionMsg && (
                <div className="p-3.5 rounded-2xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center justify-between animate-fade-in">
                  <span>{orderActionMsg}</span>
                  <button onClick={() => setOrderActionMsg('')} className="text-emerald-600 hover:text-emerald-900">
                    <X size={15} />
                  </button>
                </div>
              )}

              <div className="bg-white rounded-2xl border border-gray-200/80 shadow-xs overflow-hidden">
                {/* Header, Search & Filters */}
                <div className="p-5 border-b border-gray-100 flex flex-col md:flex-row md:items-center justify-between gap-4">
                  <div>
                    <h3 className="font-black text-sm text-gray-900 flex items-center gap-2">
                      <ShoppingBag size={18} className="text-brand-purple" />
                      <span>إدارة ومتابعة طلبيات العملاء ({orders.length})</span>
                    </h3>
                    <p className="text-xs text-gray-400 mt-0.5">
                      يمكنك معاينة الطلبية بالكامل، طباعة أمر التشغيل/الفاتورة، تعديل أصناف وأسعار الطلب، وتحديث مراحل التنفيذ.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <div className="relative">
                      <input
                        type="text"
                        value={orderSearch}
                        onChange={(e) => setOrderSearch(e.target.value)}
                        placeholder="بحث برقم الطلب، العميل، الهاتف..."
                        className="text-xs pl-8 pr-3 py-2 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-brand-purple w-52"
                      />
                      <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
                    </div>

                    <select
                      value={orderFilterStatus}
                      onChange={(e) => setOrderFilterStatus(e.target.value)}
                      className="text-xs py-2 px-3 rounded-xl border border-gray-200 font-bold text-gray-700 outline-none"
                    >
                      <option value="all">جميع المراحل ({orders.length})</option>
                      <option value="new">1. طلب جديد</option>
                      <option value="review">2. قيد المراجعة الفنية</option>
                      <option value="in_press">3. في المطبعة قيد التنفيذ</option>
                      <option value="packaging">4. مرحلة التغليف</option>
                      <option value="ready">5. جاهز للاستلام</option>
                      <option value="completed">تم التسليم</option>
                      <option value="cancelled">ملغي</option>
                    </select>
                  </div>
                </div>

                {/* Orders List */}
                <div className="divide-y divide-gray-100">
                  {orders.length === 0 ? (
                    <div className="p-14 text-center text-gray-400 text-xs">لا توجد طلبيات مسجلة بعد.</div>
                  ) : (
                    orders
                      .filter((ord) => {
                        const q = orderSearch.toLowerCase();
                        const matchesSearch =
                          !orderSearch ||
                          ord.id.toLowerCase().includes(q) ||
                          ord.customerName.toLowerCase().includes(q) ||
                          ord.customerPhone.includes(q) ||
                          (ord.customerAddress && ord.customerAddress.toLowerCase().includes(q));
                        const matchesStatus = orderFilterStatus === 'all' || ord.status === orderFilterStatus;
                        return matchesSearch && matchesStatus;
                      })
                      .map((ord) => (
                        <div key={ord.id} className="p-5 space-y-4 hover:bg-gray-50/50 transition-colors">
                          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                            <div>
                              <div className="flex flex-wrap items-center gap-2">
                                <span className="font-black text-sm text-gray-900">{ord.customerName}</span>
                                <span className="text-xs text-brand-purple font-mono font-bold bg-brand-purple/10 px-2.5 py-0.5 rounded-md">
                                  {ord.id}
                                </span>
                                <span
                                  className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                                    ord.status === 'new'
                                      ? 'bg-amber-100 text-amber-800'
                                      : ord.status === 'review'
                                      ? 'bg-purple-100 text-purple-800'
                                      : ord.status === 'in_press'
                                      ? 'bg-blue-100 text-blue-800'
                                      : ord.status === 'packaging'
                                      ? 'bg-orange-100 text-orange-800'
                                      : ord.status === 'ready'
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : ord.status === 'completed'
                                      ? 'bg-gray-100 text-gray-800'
                                      : 'bg-red-100 text-red-800'
                                  }`}
                                >
                                  {ord.status === 'new'
                                    ? 'استلام جديد'
                                    : ord.status === 'review'
                                    ? 'قيد التدقيق الفني'
                                    : ord.status === 'in_press'
                                    ? 'في المطبعة قيد التنفيذ'
                                    : ord.status === 'packaging'
                                    ? 'تغليف وتجهيز'
                                    : ord.status === 'ready'
                                    ? 'جاهز للاستلام والتوصيل'
                                    : ord.status === 'completed'
                                    ? 'تم التسليم'
                                    : 'ملغي'}
                                </span>
                                <span className="text-xs font-black text-brand-purple bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-md border border-emerald-200">
                                  {ord.finalTotal} ₪
                                </span>
                              </div>
                              <div className="text-xs text-gray-500 mt-1 flex flex-wrap gap-3 items-center">
                                <span>الهاتف: <span className="font-mono font-bold text-gray-700">{ord.customerPhone}</span></span>
                                {ord.customerAddress && <span>العنوان: {ord.customerAddress}</span>}
                                <span>التاريخ: {new Date(ord.createdAt).toLocaleDateString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                                {ord.updatedAt && (
                                  <span className="text-brand-purple font-medium">· آخر تعديل: {new Date(ord.updatedAt).toLocaleDateString('ar-EG', { month: 'short', day: 'numeric' })}</span>
                                )}
                              </div>
                            </div>

                            {/* Action Buttons: View, Edit, WhatsApp, Delete */}
                            <div className="flex flex-wrap items-center gap-2 shrink-0">
                              <button
                                onClick={() => handleOpenViewOrder(ord)}
                                className="flex items-center gap-1.5 bg-brand-purple/10 hover:bg-brand-purple text-brand-purple hover:text-white text-xs px-3 py-2 rounded-xl font-bold transition-all active:scale-95 shadow-xs"
                                title="عرض تفاصيل الطلبية بالكامل والفاتورة"
                              >
                                <Eye size={15} />
                                <span>معاينة الطلبية</span>
                              </button>

                              <button
                                onClick={() => handleOpenExportPdf(ord, 'invoice')}
                                className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-white text-xs px-3 py-2 rounded-xl font-bold transition-all active:scale-95 shadow-xs"
                                title="تصدير فاتورة مبيعات أو سند تسليم PDF للطلب"
                              >
                                <FileText size={14} />
                                <span>تصدير PDF</span>
                              </button>

                              <button
                                onClick={() => handleOpenEditOrder(ord)}
                                className="flex items-center gap-1.5 bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs px-3 py-2 rounded-xl font-bold transition-all active:scale-95 shadow-xs"
                                title="تعديل تفاصيل الطلب والكميات والأسعار"
                              >
                                <Edit2 size={14} className="text-brand-purple" />
                                <span>تعديل الطلبية</span>
                              </button>

                              <button
                                onClick={() =>
                                  sendWhatsAppMessage(
                                    ord.customerPhone,
                                    `مرحباً ${ord.customerName}، نود إعلامك أن طلبك رقم (${ord.id}) وصل إلى مرحلة: ${ord.statusNote || 'التنفيذ بالمطبعة'}، الموعد المتوقع: ${ord.estimatedDate || 'قريباً'}.`
                                  )
                                }
                                className="flex items-center gap-1 bg-[#25D366] hover:bg-emerald-600 text-white text-xs px-3 py-2 rounded-xl font-bold transition-colors shadow-xs"
                                title="إرسال إشعار للعميل عبر واتساب"
                              >
                                <MessageCircle size={15} />
                                <span>واتساب</span>
                              </button>

                              <button
                                onClick={() => handleDeleteOrder(ord.id)}
                                className="text-red-400 hover:text-red-600 p-2 rounded-xl hover:bg-red-50 transition-colors"
                                title="حذف الطلب نهائياً"
                              >
                                <Trash2 size={16} />
                              </button>
                            </div>
                          </div>

                          {/* Quick Workflow Status, Note & Estimated date */}
                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 bg-gray-50/80 p-3.5 rounded-xl border border-gray-100 text-xs">
                            <div>
                              <label className="block text-[11px] font-bold text-gray-700 mb-1">
                                المرحلة السريعة لسير العمل:
                              </label>
                              <select
                                value={ord.status}
                                onChange={(e) =>
                                  handleUpdateOrderStatus(
                                    ord.id,
                                    e.target.value as OrderWorkflowStatus,
                                    ord.statusNote,
                                    ord.estimatedDate
                                  )
                                }
                                className="w-full text-xs bg-white border border-gray-200 rounded-lg p-2 font-bold text-brand-purple outline-none focus:border-brand-purple"
                              >
                                <option value="new">1. استلام الطلب (جديد)</option>
                                <option value="review">2. قيد المراجعة والتدقيق الفني</option>
                                <option value="in_press">3. في المطبعة قيد التنفيذ والطباعة</option>
                                <option value="packaging">4. مرحلة التغليف والتجهيز</option>
                                <option value="ready">5. جاهز للاستلام والتوصيل</option>
                                <option value="completed">تم التسليم النهائي</option>
                                <option value="cancelled">ملغي</option>
                              </select>
                            </div>

                            <div>
                              <label className="block text-[11px] font-bold text-gray-700 mb-1">
                                ملاحظة فنية للمطبعة (تظهر للعميل في التتبع):
                              </label>
                              <input
                                type="text"
                                value={ord.statusNote || ''}
                                onChange={(e) =>
                                  handleUpdateOrderStatus(ord.id, ord.status, e.target.value, ord.estimatedDate)
                                }
                                placeholder="مثال: تم اعتماد البروفة والطلب جاري طباعته على ماكينة الأوفست..."
                                className="w-full text-xs p-2 rounded-lg bg-white border border-gray-200 outline-none focus:border-brand-purple"
                              />
                            </div>

                            <div>
                              <label className="block text-[11px] font-bold text-gray-700 mb-1">
                                الموعد المتوقع للتسليم:
                              </label>
                              <input
                                type="text"
                                value={ord.estimatedDate || ''}
                                onChange={(e) =>
                                  handleUpdateOrderStatus(ord.id, ord.status, ord.statusNote, e.target.value)
                                }
                                placeholder="مثال: غداً الساعة 4 عصراً، أو خلال 48 ساعة"
                                className="w-full text-xs p-2 rounded-lg bg-white border border-gray-200 outline-none focus:border-brand-purple"
                              />
                            </div>
                          </div>

                          {/* Order Items Breakdown */}
                          <div className="bg-white p-3.5 rounded-xl border border-gray-100 text-xs space-y-2">
                            <div className="flex items-center justify-between text-gray-700 font-bold border-b border-gray-100 pb-1.5">
                              <span>عناصر الطلبية ({ord.items.length}):</span>
                              <span className="text-[11px] text-gray-400">انقر على "معاينة الطلبية" لعرض الفاتورة والملفات</span>
                            </div>
                            <div className="space-y-1.5">
                              {ord.items.map((item, i) => (
                                <div key={i} className="flex flex-col sm:flex-row sm:items-center justify-between text-gray-600 bg-gray-50/60 p-2 rounded-lg gap-1">
                                  <div>
                                    <span className="font-bold text-gray-900">{item.productName}</span>
                                    <span className="text-gray-500 mr-2 font-mono text-[11px]">
                                      ({item.quantity.toLocaleString()} قطعة × {item.unitPrice} ₪)
                                    </span>
                                    {item.optionsSummary && (
                                      <span className="text-[11px] text-gray-500 block">خيارات: {item.optionsSummary}</span>
                                    )}
                                    {item.customText && (
                                      <span className="text-brand-purple block text-[11px] font-medium">
                                        ملاحظة العميل: {item.customText}
                                      </span>
                                    )}
                                  </div>
                                  <div className="text-left font-black text-brand-purple shrink-0">
                                    {item.totalPrice} ₪
                                  </div>
                                </div>
                              ))}
                            </div>
                            <div className="border-t border-gray-100 pt-2 flex flex-wrap justify-between items-center text-xs font-bold">
                              <span className="text-gray-500">
                                المجموع الفرعي: {ord.subtotal} ₪ {ord.discountTotal > 0 && <span className="text-emerald-600 mr-2">(خصم: -{ord.discountTotal} ₪)</span>}
                              </span>
                              <div className="font-black text-sm text-gray-900">
                                الإجمالي النهائي: <span className="text-brand-purple">{ord.finalTotal} ₪</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: MEDIA LIBRARY (مكتبة الصور والشعار الخاصة) */}
          {activeTab === 'media' && (
            <div className="space-y-6">
              {mediaActionMessage && (
                <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-xl flex items-center gap-2">
                  <Check size={16} />
                  <span>{mediaActionMessage}</span>
                </div>
              )}

              {/* Toolbar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 rounded-2xl border border-gray-200/80 shadow-xs">
                {/* Category filters */}
                <div className="flex flex-wrap items-center gap-2">
                  {[
                    { id: 'all', label: 'جميع الصور' },
                    { id: 'logo', label: 'الشعارات' },
                    { id: 'products', label: 'المطبوعات والمنتجات' },
                    { id: 'banners', label: 'البانرات والإعلانات' },
                    { id: 'general', label: 'صور عامة' },
                  ].map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => setMediaCategoryFilter(cat.id)}
                      className={`text-xs px-3 py-1.5 rounded-xl font-bold transition-all ${
                        mediaCategoryFilter === cat.id
                          ? 'bg-brand-purple text-white shadow-xs'
                          : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>

                <button
                  onClick={() => setIsUploadModalOpen(true)}
                  className="flex items-center gap-2 bg-brand-yellow hover:bg-yellow-400 text-brand-purple px-5 py-2.5 rounded-xl text-xs font-black shadow-md transition-all active:scale-95 shrink-0"
                >
                  <Upload size={16} />
                  <span>رفع صورة أو شعار جديد</span>
                </button>
              </div>

              {/* Media Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                {filteredMedia.map((media) => (
                  <div
                    key={media.id}
                    className="bg-white rounded-2xl border border-gray-200/80 overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
                  >
                    <div>
                      <div className="h-44 relative bg-gray-100 overflow-hidden group">
                        <img
                          src={media.url}
                          alt={media.name}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                        <span className="absolute top-2 right-2 bg-black/60 text-white text-[10px] px-2 py-0.5 rounded-md backdrop-blur-xs font-medium">
                          {media.category === 'logo' ? 'شعار' : media.category === 'banners' ? 'بانر' : 'منتج'}
                        </span>
                      </div>

                      <div className="p-3.5 space-y-1">
                        <h4 className="font-bold text-xs text-gray-900 truncate" title={media.name}>
                          {media.name}
                        </h4>
                        <div className="text-[10px] text-gray-400 flex items-center justify-between">
                          <span>{media.size || 'حجم قياسي'}</span>
                          <span>{new Date(media.uploadedAt).toLocaleDateString('ar-EG')}</span>
                        </div>
                      </div>
                    </div>

                    {/* Actions on Media */}
                    <div className="p-3 border-t border-gray-100 flex flex-col gap-1.5 bg-gray-50/50">
                      <div className="grid grid-cols-2 gap-1.5">
                        <button
                          onClick={() => handleSetAsSiteLogo(media.url)}
                          className="text-[11px] font-bold bg-brand-purple/10 hover:bg-brand-purple hover:text-white text-brand-purple py-1.5 px-2 rounded-lg transition-colors text-center truncate"
                          title="تعيين كشعار رسمي للموقع"
                        >
                          تعيين كشعار
                        </button>

                        <button
                          onClick={() => handleCopyMediaUrl(media.url, media.id)}
                          className="text-[11px] font-bold bg-gray-200 hover:bg-gray-300 text-gray-700 py-1.5 px-2 rounded-lg transition-colors flex items-center justify-center gap-1"
                        >
                          <Copy size={12} />
                          <span>{copiedId === media.id ? 'تم النسخ!' : 'نسخ الرابط'}</span>
                        </button>
                      </div>

                      <button
                        onClick={() => handleDeleteMedia(media.id)}
                        className="text-[11px] text-red-500 hover:text-red-700 hover:bg-red-50 py-1 rounded transition-colors text-center"
                      >
                        حذف من المكتبة
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: PRODUCTS */}
          {activeTab === 'products' && (
            <div className="space-y-6">
              {/* Toolbar */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="relative max-w-sm w-full">
                  <input
                    type="text"
                    placeholder="ابحث عن منتج..."
                    value={productSearch}
                    onChange={(e) => setProductSearch(e.target.value)}
                    className="w-full pr-10 pl-4 py-2.5 bg-white rounded-xl border border-gray-200 text-xs focus:ring-2 focus:ring-brand-purple outline-none"
                  />
                  <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                </div>

                <button
                  onClick={handleOpenAddProduct}
                  className="flex items-center gap-2 bg-brand-purple hover:bg-[#4d2377] text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all active:scale-95 shrink-0"
                >
                  <Plus size={16} />
                  <span>إضافة منتج أو خدمة جديدة</span>
                </button>
              </div>

              {/* Products Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {filteredProducts.map((prod) => (
                  <div
                    key={prod.id}
                    className="bg-white rounded-2xl border border-gray-200/80 overflow-hidden shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between"
                  >
                    <div>
                      <div className="h-44 relative bg-gray-100">
                        <img
                          src={prod.image}
                          alt={prod.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-2 right-2 bg-brand-purple/90 text-white text-[11px] font-bold px-2.5 py-1 rounded-md">
                          {prod.price} ₪ (حد أدنى: {prod.minQuantity})
                        </div>
                      </div>

                      <div className="p-4 space-y-2">
                        <div className="flex items-start justify-between">
                          <h4 className="font-bold text-sm text-gray-900">{prod.name}</h4>
                          <span className="text-[10px] text-gray-500 bg-gray-100 px-2 py-0.5 rounded">
                            {prod.category}
                          </span>
                        </div>
                        <p className="text-xs text-gray-500 line-clamp-2">{prod.description}</p>

                        {/* Tier preview */}
                        {prod.discountTiers && prod.discountTiers.length > 0 && (
                          <div className="flex flex-wrap gap-1 pt-1">
                            {prod.discountTiers.map((t, idx) => (
                              <span
                                key={idx}
                                className="text-[10px] bg-emerald-50 text-emerald-800 font-semibold px-2 py-0.5 rounded"
                              >
                                {t.minQuantity}+: خصم {t.discountPercentage}%
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="p-4 pt-2 border-t border-gray-100 flex items-center justify-between">
                      <span className="text-xs text-gray-400">ID: {prod.id}</span>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleOpenEditProduct(prod)}
                          className="p-2 text-gray-600 hover:text-brand-purple hover:bg-brand-purple/10 rounded-lg transition-colors"
                          title="تعديل المنتج"
                        >
                          <Edit2 size={15} />
                        </button>
                        <button
                          onClick={() => handleDeleteProduct(prod.id)}
                          className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                          title="حذف المنتج"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 5: CATEGORIES */}
          {activeTab === 'categories' && (
            <div className="space-y-6">
              <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs max-w-xl">
                <h3 className="font-bold text-sm text-gray-900 mb-3 flex items-center gap-2">
                  <Plus size={16} className="text-brand-purple" />
                  إضافة تصنيف جديد
                </h3>
                <form onSubmit={handleAddCategory} className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">اسم التصنيف</label>
                      <input
                        type="text"
                        required
                        value={newCategoryName}
                        onChange={(e) => setNewCategoryName(e.target.value)}
                        placeholder="مثال: أختام وسندات"
                        className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">المعرف (انجليزي)</label>
                      <input
                        type="text"
                        value={newCategoryId}
                        onChange={(e) => setNewCategoryId(e.target.value)}
                        placeholder="stamps"
                        className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                      />
                    </div>
                  </div>
                  <button
                    type="submit"
                    className="bg-brand-purple text-white px-5 py-2.5 rounded-xl text-xs font-bold hover:bg-[#4d2377] transition-all"
                  >
                    حفظ التصنيف
                  </button>
                </form>
              </div>

              <div className="bg-white rounded-2xl border border-gray-200/80 shadow-xs overflow-hidden">
                <div className="p-4 border-b border-gray-100 font-bold text-xs text-gray-700">
                  قائمة الأصناف الحالية ({categories.length})
                </div>
                <div className="divide-y divide-gray-100">
                  {categories.map((cat) => {
                    const count = products.filter((p) => p.category === cat.id).length;
                    return (
                      <div key={cat.id} className="p-4 flex items-center justify-between text-xs">
                        <div>
                          <div className="font-bold text-gray-900">{cat.name}</div>
                          <div className="text-gray-400 text-[11px]">
                            المعرف: {cat.id} · يحتوي على {count} منتجات
                          </div>
                        </div>
                        {cat.id !== 'all' && (
                          <button
                            onClick={() => handleDeleteCategory(cat.id)}
                            className="text-red-500 hover:bg-red-50 p-2 rounded-lg transition-colors"
                            title="حذف التصنيف"
                          >
                            <Trash2 size={15} />
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: SITE DESIGN & IMAGES */}
          {activeTab === 'design' && (
            <div className="space-y-6 max-w-4xl">
              {designSuccessMsg && (
                <div className="p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
                  <Check size={16} />
                  <span>{designSuccessMsg}</span>
                </div>
              )}

              <form onSubmit={handleSaveDesign} className="space-y-6">
                <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs space-y-4">
                  <h3 className="font-black text-sm text-gray-900 flex items-center gap-2">
                    <Palette size={17} className="text-brand-purple" />
                    هوية وشعار المؤسسة
                  </h3>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">اسم المؤسسة / المتجر</label>
                      <input
                        type="text"
                        value={designForm.companyName}
                        onChange={(e) => setDesignForm({ ...designForm, companyName: e.target.value })}
                        className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">الشعار والوصف التعريفي</label>
                      <input
                        type="text"
                        value={designForm.tagline}
                        onChange={(e) => setDesignForm({ ...designForm, tagline: e.target.value })}
                        className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">رابط الشعار أو اختياره من المكتبة</label>
                    <div className="flex gap-3 items-center">
                      <input
                        type="text"
                        value={designForm.logoUrl}
                        onChange={(e) => setDesignForm({ ...designForm, logoUrl: e.target.value })}
                        className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                      />
                      <img
                        src={designForm.logoUrl}
                        alt="Logo Preview"
                        className="h-10 w-24 object-contain bg-brand-purple rounded p-1 border"
                      />
                    </div>

                    {/* Quick Choose from media library */}
                    <div className="pt-2">
                      <span className="text-[11px] text-gray-400 block mb-1">أو اختر شعاراً من مكتبتك الخاصة بنقرة واحدة:</span>
                      <div className="flex gap-2 overflow-x-auto pb-1">
                        {mediaList.slice(0, 6).map((m) => (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => setDesignForm({ ...designForm, logoUrl: m.url })}
                            className="h-12 w-16 border rounded-lg overflow-hidden shrink-0 hover:border-brand-purple focus:ring-2 focus:ring-brand-purple"
                          >
                            <img src={m.url} alt={m.name} className="w-full h-full object-cover" />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* HERO WELCOME BACKGROUND & PURPLE OVERLAY SECTION */}
                <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs space-y-6">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-gray-100">
                    <div>
                      <h3 className="font-black text-sm text-gray-900 flex items-center gap-2">
                        <ImageIcon size={18} className="text-brand-purple" />
                        <span>خلفية الواجهة الترحيبية والطبقة البنفسجية العلوية</span>
                      </h3>
                      <p className="text-xs text-gray-500 mt-0.5">
                        تحكم في صورة خلفية الهيرو الترحيبي والأرضية البنفسجية كطبقة علوية فوق الصورة مع التحكم في درجة الشفافية (Opacity).
                      </p>
                    </div>

                    <span className="self-start sm:self-auto text-[11px] font-bold text-brand-purple bg-purple-50 border border-purple-200 px-3 py-1 rounded-full font-mono">
                      شفافية الطبقة: {designForm.heroOverlayOpacity !== undefined ? designForm.heroOverlayOpacity : 60}%
                    </span>
                  </div>

                  {/* 1. Live Interactive Preview of Hero Banner */}
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-2">
                      معاينة حية وفورية للواجهة الترحيبية (تأثير الصورة + الطبقة البنفسجية بالأوباسيتي المحددة):
                    </label>
                    <div className="relative h-48 sm:h-56 rounded-2xl overflow-hidden border-2 border-brand-purple/20 shadow-md flex items-center justify-center">
                      {/* Background Image Preview */}
                      <div
                        className="absolute inset-0 bg-cover bg-center transition-all duration-300"
                        style={{
                          backgroundImage: `url(${
                            designForm.heroBackground ||
                            'https://images.unsplash.com/photo-1562654501-a0ccc0fc3fb1?auto=format&fit=crop&w=1920&q=80'
                          })`,
                        }}
                      />

                      {/* Purple Overlay Layer with Dynamic Opacity */}
                      <div
                        className="absolute inset-0 transition-opacity duration-200 pointer-events-none"
                        style={{
                          backgroundColor: designForm.heroOverlayColor || '#5D2E8E',
                          opacity: (designForm.heroOverlayOpacity !== undefined ? designForm.heroOverlayOpacity : 60) / 100,
                        }}
                      />

                      {/* Depth Gradient */}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-black/20 pointer-events-none" />

                      {/* Interactive Indicator Card */}
                      <div className="relative z-10 text-center p-4 max-w-md bg-black/40 backdrop-blur-md rounded-2xl border border-white/25 text-white shadow-xl">
                        <div className="inline-flex items-center gap-1.5 bg-brand-yellow text-brand-purple text-[10px] font-black px-2.5 py-0.5 rounded-full mb-1">
                          <Sparkles size={12} />
                          <span>معاينة حية للمظهر</span>
                        </div>
                        <h4 className="font-black text-sm sm:text-base text-white">
                          مظهر الواجهة الترحيبية المعتمد
                        </h4>
                        <p className="text-[11px] text-gray-200 mt-1">
                          {designForm.heroShowContent
                            ? 'عناصر ونصوص الواجهة مفعلة وظاهرة'
                            : 'عناصر الواجهة مزالة ومخفية لظهور الصورة والأرضية البنفسجية بنقاء تام'}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* 2. Hero Background Image Controls */}
                  <div className="space-y-3 pt-2">
                    <label className="block text-xs font-bold text-gray-800">
                      صورة خلفية الواجهة الترحيبية:
                    </label>

                    <div className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center">
                      <input
                        type="text"
                        value={designForm.heroBackground || ''}
                        onChange={(e) => setDesignForm({ ...designForm, heroBackground: e.target.value })}
                        placeholder="أدخل رابط صورة الخلفية (URL) أو ارفع صورة من جهازك..."
                        className="flex-grow text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                      />

                      {/* Upload from Device button */}
                      <label className="flex items-center justify-center gap-2 bg-brand-purple hover:bg-[#4d2377] text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer active:scale-95 shrink-0">
                        <Upload size={15} />
                        <span>رفع صورة من جهازك</span>
                        <input
                          type="file"
                          accept="image/*"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              try {
                                const uploaded = await store.uploadMediaFileServer(
                                  file,
                                  'banners',
                                  `خلفية الواجهة-${Date.now()}`
                                );
                                setMediaList(store.getMedia());
                                setDesignForm({ ...designForm, heroBackground: uploaded.url });
                                setDesignSuccessMsg('تم رفع وتعيين صورة الخلفية بنجاح!');
                                setTimeout(() => setDesignSuccessMsg(''), 3000);
                              } catch (err) {
                                alert('حدث خطأ أثناء رفع صورة الخلفية.');
                              }
                            }
                          }}
                        />
                      </label>
                    </div>

                    {/* Quick choose from media library */}
                    <div>
                      <span className="text-[11px] text-gray-500 font-medium block mb-1.5">
                        أو اختر صورة من مكتبة الوسائط بنقرة واحدة:
                      </span>
                      <div className="flex gap-2.5 overflow-x-auto pb-1.5">
                        {mediaList.slice(0, 8).map((m) => (
                          <button
                            key={m.id}
                            type="button"
                            onClick={() => setDesignForm({ ...designForm, heroBackground: m.url })}
                            className={`h-14 w-24 rounded-xl border-2 overflow-hidden shrink-0 transition-all ${
                              designForm.heroBackground === m.url
                                ? 'border-brand-purple ring-2 ring-brand-purple/30 scale-105'
                                : 'border-gray-200 hover:border-brand-purple/60 opacity-80 hover:opacity-100'
                            }`}
                            title={`تعيين ${m.name} كخلفية للواجهة`}
                          >
                            <img src={m.url} alt={m.name} className="w-full h-full object-cover" />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* 3. Purple Overlay Opacity Controls & Presets */}
                  <div className="p-4 bg-gray-50 rounded-2xl border border-gray-200 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-4 h-4 rounded-full bg-brand-purple border border-white shadow-xs" />
                        <span className="text-xs font-bold text-gray-800">
                          التحكم في أوباسيتي (شفافية) الطبقة البنفسجية فوق الصورة:
                        </span>
                      </div>
                      <span className="text-sm font-black text-brand-purple font-mono bg-white px-2.5 py-1 rounded-lg border border-purple-200 shadow-2xs">
                        {designForm.heroOverlayOpacity !== undefined ? designForm.heroOverlayOpacity : 60}%
                      </span>
                    </div>

                    {/* Slider Range */}
                    <div className="space-y-1">
                      <input
                        type="range"
                        min="0"
                        max="100"
                        step="5"
                        value={designForm.heroOverlayOpacity !== undefined ? designForm.heroOverlayOpacity : 60}
                        onChange={(e) =>
                          setDesignForm({ ...designForm, heroOverlayOpacity: Number(e.target.value) })
                        }
                        className="w-full h-2.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-brand-purple"
                      />
                      <div className="flex justify-between text-[10px] text-gray-400 font-mono">
                        <span>0% (شفاف تماماً - الصورة ظاهرة 100%)</span>
                        <span>50% (نصف شفاف)</span>
                        <span>100% (بنفسجي معتم بالكامل)</span>
                      </div>
                    </div>

                    {/* Quick Preset Buttons */}
                    <div>
                      <span className="text-[11px] font-bold text-gray-600 block mb-2">
                        أزرار سريعة للتحكم في الأوباسيتي:
                      </span>
                      <div className="flex flex-wrap gap-2">
                        {[
                          { val: 0, label: '0% (بدون طبقة - صورة نقية)' },
                          { val: 25, label: '25% (طبقة خفيفة)' },
                          { val: 50, label: '50% (متوازن)' },
                          { val: 65, label: '65% (الافتراضي الموصى به)' },
                          { val: 80, label: '80% (طبقة داكنة)' },
                          { val: 100, label: '100% (بنفسجي كامل)' },
                        ].map((btn) => (
                          <button
                            key={btn.val}
                            type="button"
                            onClick={() => setDesignForm({ ...designForm, heroOverlayOpacity: btn.val })}
                            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                              (designForm.heroOverlayOpacity !== undefined ? designForm.heroOverlayOpacity : 60) === btn.val
                                ? 'bg-brand-purple text-white shadow-xs scale-105'
                                : 'bg-white border border-gray-200 text-gray-700 hover:border-brand-purple'
                            }`}
                          >
                            {btn.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* 4. Welcome Section Content Elements Toggle */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-purple-50/50 rounded-2xl border border-purple-200/70">
                    <div>
                      <div className="font-bold text-xs text-gray-900">
                        عناصر ونصوص الواجهة الترحيبية (النصوص والأزرار)
                      </div>
                      <div className="text-[11px] text-gray-500 mt-0.5">
                        {designForm.heroShowContent
                          ? 'العناصر مفعلة حالياً وتظهر فوق صورة الخلفية والطبقة البنفسجية.'
                          : 'العناصر مزالة حالياً لإبراز صورة الخلفية والأرضية البنفسجية بنقاء تام.'}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() =>
                          setDesignForm({ ...designForm, heroShowContent: !designForm.heroShowContent })
                        }
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer shadow-xs ${
                          designForm.heroShowContent
                            ? 'bg-brand-purple text-white'
                            : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-50'
                        }`}
                      >
                        {designForm.heroShowContent ? '✓ العناصر مفعلة (إظهار)' : '✕ العناصر مزالة (مظهر نقي)'}
                      </button>
                    </div>
                  </div>
                </div>

                {/* Banner & Contacts */}
                <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs space-y-4">
                  <h3 className="font-black text-sm text-gray-900">نصوص البانر الرئيسي</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">الوسام</label>
                      <input
                        type="text"
                        value={designForm.heroBadge}
                        onChange={(e) => setDesignForm({ ...designForm, heroBadge: e.target.value })}
                        className="w-full text-xs p-2.5 rounded-xl border border-gray-200"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">العنوان الأول</label>
                      <input
                        type="text"
                        value={designForm.heroTitle}
                        onChange={(e) => setDesignForm({ ...designForm, heroTitle: e.target.value })}
                        className="w-full text-xs p-2.5 rounded-xl border border-gray-200"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">النص المميز الأصفر</label>
                      <input
                        type="text"
                        value={designForm.heroHighlight}
                        onChange={(e) => setDesignForm({ ...designForm, heroHighlight: e.target.value })}
                        className="w-full text-xs p-2.5 rounded-xl border border-gray-200"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">الوصف</label>
                    <textarea
                      value={designForm.heroSubtitle}
                      onChange={(e) => setDesignForm({ ...designForm, heroSubtitle: e.target.value })}
                      className="w-full text-xs p-2.5 rounded-xl border border-gray-200 h-16 resize-none"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <button
                    type="submit"
                    className="flex items-center gap-2 bg-brand-purple hover:bg-[#4d2377] text-white px-7 py-3 rounded-xl text-xs font-bold shadow-md transition-all active:scale-95"
                  >
                    <Save size={16} />
                    <span>حفظ جميع تعديلات التصميم</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleResetDesign}
                    className="flex items-center gap-2 bg-gray-200 hover:bg-gray-300 text-gray-700 px-5 py-3 rounded-xl text-xs font-bold transition-all"
                  >
                    <RotateCcw size={15} />
                    <span>استعادة الافتراضي</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 7: QUOTES */}
          {activeTab === 'quotes' && (
            <div className="space-y-6">
              {quoteActionMsg && (
                <div className="p-3.5 rounded-2xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center justify-between animate-fade-in">
                  <span>{quoteActionMsg}</span>
                  <button onClick={() => setQuoteActionMsg('')} className="text-emerald-600 hover:text-emerald-900">
                    <X size={15} />
                  </button>
                </div>
              )}

              <div className="bg-white rounded-2xl border border-gray-200/80 shadow-xs overflow-hidden">
                {/* Header & Filters */}
                <div className="p-5 border-b border-gray-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="font-black text-sm text-gray-900 flex items-center gap-2">
                      <FileText size={18} className="text-brand-purple" />
                      <span>طلبات عروض الأسعار المستلمة ({quotes.length})</span>
                    </h3>
                    <p className="text-xs text-gray-400 mt-0.5">
                      يمكنك تحديد السعر المقترح، كتابة ملاحظات فنية، تعديل وحذف العروض، وإرسالها للعميل عبر واتساب.
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    <div className="relative">
                      <input
                        type="text"
                        value={quoteSearch}
                        onChange={(e) => setQuoteSearch(e.target.value)}
                        placeholder="بحث بالعميل أو الخدمة..."
                        className="text-xs pl-8 pr-3 py-2 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-brand-purple w-44"
                      />
                      <Search size={14} className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-400" />
                    </div>

                    <select
                      value={quoteStatusFilter}
                      onChange={(e) => setQuoteStatusFilter(e.target.value)}
                      className="text-xs py-2 px-3 rounded-xl border border-gray-200 font-bold text-gray-700 outline-none"
                    >
                      <option value="all">جميع الحالات</option>
                      <option value="new">جديد فقط</option>
                      <option value="contacted">تم التواصل</option>
                      <option value="completed">مكتمل</option>
                      <option value="cancelled">ملغي</option>
                    </select>
                  </div>
                </div>

                {/* Quotes List */}
                <div className="divide-y divide-gray-100">
                  {quotes.length === 0 ? (
                    <div className="p-14 text-center text-gray-400 text-xs">لا توجد طلبات عروض أسعار حتى الآن.</div>
                  ) : (
                    quotes
                      .filter((q) => {
                        const matchesSearch =
                          !quoteSearch ||
                          q.customerName.toLowerCase().includes(quoteSearch.toLowerCase()) ||
                          q.serviceName.toLowerCase().includes(quoteSearch.toLowerCase()) ||
                          q.phone.includes(quoteSearch) ||
                          q.id.toLowerCase().includes(quoteSearch.toLowerCase());
                        const matchesStatus = quoteStatusFilter === 'all' || q.status === quoteStatusFilter;
                        return matchesSearch && matchesStatus;
                      })
                      .map((q) => (
                        <div key={q.id} className="p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4 hover:bg-gray-50/50 transition-colors">
                          <div className="space-y-2 flex-grow">
                            <div className="flex flex-wrap items-center gap-2.5">
                              <span className="font-black text-sm text-gray-900">{q.customerName}</span>
                              <span className="text-xs text-gray-400 font-mono bg-gray-100 px-2 py-0.5 rounded-md font-semibold">
                                {q.id}
                              </span>
                              <span
                                className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                                  q.status === 'new'
                                    ? 'bg-amber-100 text-amber-800'
                                    : q.status === 'contacted'
                                    ? 'bg-blue-100 text-blue-800'
                                    : q.status === 'completed'
                                    ? 'bg-emerald-100 text-emerald-800'
                                    : 'bg-red-100 text-red-800'
                                }`}
                              >
                                {q.status === 'new'
                                  ? 'جديد'
                                  : q.status === 'contacted'
                                  ? 'تم التواصل'
                                  : q.status === 'completed'
                                  ? 'مكتمل'
                                  : 'ملغي'}
                              </span>
                              {q.quantity && (
                                <span className="text-[11px] bg-purple-100 text-purple-800 font-bold px-2 py-0.5 rounded-md">
                                  الكمية: {q.quantity.toLocaleString()} قطعة
                                </span>
                              )}
                              {q.offeredPrice !== undefined && q.offeredPrice > 0 && (
                                <span className="text-[11px] bg-emerald-500 text-white font-black px-2.5 py-0.5 rounded-full shadow-xs">
                                  السعر المعروض: {q.offeredPrice} ₪
                                </span>
                              )}
                            </div>

                            <div className="text-xs font-bold text-brand-purple">
                              الخدمة المطلوبة: <span className="text-gray-800 font-semibold">{q.serviceName}</span>
                            </div>

                            <p className="text-xs text-gray-600 bg-gray-50 p-3 rounded-xl border border-gray-100 max-w-2xl leading-relaxed">
                              {q.details}
                            </p>

                            {q.adminNotes && (
                              <div className="text-xs text-amber-900 bg-amber-50/80 p-2.5 rounded-xl border border-amber-200/60 max-w-2xl">
                                <span className="font-bold">ملاحظات الإدارة: </span>
                                {q.adminNotes}
                              </div>
                            )}

                            <div className="text-[11px] text-gray-400 flex flex-wrap items-center gap-3 pt-1">
                              <span>الهاتف: <span className="font-mono text-gray-600 font-semibold">{q.phone}</span></span>
                              <span>·</span>
                              <span>التاريخ: {new Date(q.createdAt).toLocaleDateString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}</span>
                              {q.updatedAt && (
                                <>
                                  <span>·</span>
                                  <span className="text-brand-purple">تم التعديل: {new Date(q.updatedAt).toLocaleDateString('ar-EG', { month: 'short', day: 'numeric' })}</span>
                                </>
                              )}
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex flex-wrap items-center gap-2 shrink-0 self-start lg:self-center">
                            <select
                              value={q.status}
                              onChange={(e) => handleUpdateQuoteStatus(q.id, e.target.value as QuoteRequest['status'])}
                              className="text-xs bg-gray-50 border border-gray-200 rounded-xl p-2 font-bold text-gray-700 outline-none hover:border-brand-purple"
                            >
                              <option value="new">جديد</option>
                              <option value="contacted">تم التواصل</option>
                              <option value="completed">مكتمل</option>
                              <option value="cancelled">ملغي</option>
                            </select>

                            <button
                              onClick={() => handleOpenEditQuote(q)}
                              className="flex items-center gap-1.5 bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs px-3.5 py-2 rounded-xl font-bold transition-all active:scale-95"
                              title="تعديل وتحديد السعر"
                            >
                              <Edit2 size={14} className="text-brand-purple" />
                              <span>تعديل السعر والمواصفات</span>
                            </button>

                            <button
                              onClick={() => handleSendWhatsAppProposal(q)}
                              className="flex items-center gap-1.5 bg-[#25D366] hover:bg-emerald-600 text-white text-xs px-3.5 py-2 rounded-xl font-bold transition-all shadow-xs active:scale-95"
                              title="إرسال عرض السعر المكتوب عبر واتساب"
                            >
                              <MessageCircle size={15} />
                              <span>إرسال واتساب</span>
                            </button>

                            <button
                              onClick={() => handleDeleteQuote(q.id)}
                              className="text-red-400 hover:text-red-600 p-2 rounded-xl hover:bg-red-50 transition-colors"
                              title="حذف نهائياً"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                        </div>
                      ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB: DISCOUNTS & QUANTITY TIERS */}
          {activeTab === 'discounts' && (
            <div className="space-y-6">
              {discountActionMsg && (
                <div className="p-3.5 rounded-2xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center justify-between animate-fade-in">
                  <span>{discountActionMsg}</span>
                  <button onClick={() => setDiscountActionMsg('')} className="text-emerald-600 hover:text-emerald-900">
                    <X size={15} />
                  </button>
                </div>
              )}

              {/* Top Banner and Quick Controls */}
              <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-100">
                  <div>
                    <h3 className="font-black text-base text-gray-900 flex items-center gap-2">
                      <Percent size={20} className="text-brand-purple" />
                      <span>إدارة وتعديل شرائح الخصومات للكميات</span>
                    </h3>
                    <p className="text-xs text-gray-500 mt-1">
                      حدّد نسب الخصم التلقائية عند وصول الكمية لرقم محدد، وطبّقها بضغطة زر على جميع المنتجات أو أصناف مختارة.
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={handleOpenAddTier}
                      className="flex items-center gap-1.5 bg-brand-purple hover:bg-[#4d2377] text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all active:scale-95"
                    >
                      <Plus size={16} />
                      <span>إضافة شريحة خصم</span>
                    </button>

                    <button
                      onClick={handleResetDefaultTiers}
                      className="flex items-center gap-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 px-3 py-2.5 rounded-xl text-xs font-bold transition-colors"
                      title="استعادة القيم الافتراضية للشرائح"
                    >
                      <RotateCcw size={14} />
                      <span>الافتراضي</span>
                    </button>
                  </div>
                </div>

                {/* Bulk Apply to Products Row */}
                <div className="bg-purple-50/60 p-4 rounded-xl border border-purple-100 flex flex-col md:flex-row md:items-center justify-between gap-3">
                  <div className="space-y-0.5">
                    <div className="font-bold text-xs text-brand-purple flex items-center gap-1.5">
                      <Sparkles size={14} />
                      <span>تطبيق هذه الشرائح على المنتجات المعروضة للعملاء</span>
                    </div>
                    <div className="text-[11px] text-gray-600">
                      سيتم تحديث حاسبة التكلفة الفورية تلقائياً لكل منتج مشمول.
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <select
                      value={selectedDiscountCategory}
                      onChange={(e) => setSelectedDiscountCategory(e.target.value)}
                      className="text-xs p-2 rounded-xl border border-purple-200 bg-white font-bold text-gray-700 outline-none"
                    >
                      <option value="all">جميع المنتجات في المتجر ({products.length})</option>
                      {categories.filter((c) => c.id !== 'all').map((c) => (
                        <option key={c.id} value={c.id}>
                          تصنيف: {c.name}
                        </option>
                      ))}
                    </select>

                    <button
                      onClick={handleApplyDiscountsToProducts}
                      className="flex items-center gap-1.5 bg-brand-purple hover:bg-[#4d2377] text-white px-4 py-2 rounded-xl text-xs font-bold shadow-sm transition-all active:scale-95"
                    >
                      <Check size={15} />
                      <span>تطبيق الآن على المنتجات</span>
                    </button>
                  </div>
                </div>

                {/* Active Tiers Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
                  {discountTiers.map((tier, idx) => (
                    <div
                      key={idx}
                      className="p-4 bg-gray-50/80 rounded-2xl border border-gray-200 hover:border-brand-purple transition-all relative group"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[11px] font-bold text-gray-500 bg-white px-2 py-0.5 rounded-md border border-gray-200">
                          شريحة #{idx + 1}
                        </span>
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handleOpenEditTier(idx)}
                            className="p-1 text-gray-400 hover:text-brand-purple rounded-md hover:bg-white"
                            title="تعديل الشريحة"
                          >
                            <Edit2 size={13} />
                          </button>
                          <button
                            onClick={() => handleDeleteTier(idx)}
                            className="p-1 text-gray-400 hover:text-red-600 rounded-md hover:bg-white"
                            title="حذف الشريحة"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-baseline gap-1 my-1">
                        <span className="text-2xl font-black text-brand-purple">
                          {tier.discountPercentage}%
                        </span>
                        <span className="text-xs font-bold text-emerald-600">خصم مباشر</span>
                      </div>

                      <div className="text-xs font-bold text-gray-800 mt-1">
                        عند طلب: <span className="font-black text-brand-dark">{tier.minQuantity.toLocaleString()}</span> قطعة فأكثر
                      </div>

                      {tier.label && (
                        <div className="text-[10px] text-gray-500 mt-2 bg-white/80 p-1.5 rounded-lg border border-gray-100 truncate">
                          {tier.label}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Interactive Discount Simulator & Calculator */}
              <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-gray-100">
                  <div className="flex items-center gap-2">
                    <Calculator size={18} className="text-emerald-600" />
                    <h4 className="font-black text-sm text-gray-900">
                      محاكي واختبار الخصومات المباشر (Discount Simulator)
                    </h4>
                  </div>
                  <span className="text-xs text-gray-400 font-semibold">تحقق فوري من الحسابات والأسعار للعميل</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Inputs */}
                  <div className="space-y-4 bg-gray-50/80 p-4 rounded-xl border border-gray-200/80">
                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">
                        سعر الدفعة أو القطعة الأساسي (₪)
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={simBasePrice}
                        onChange={(e) => setSimBasePrice(Math.max(1, Number(e.target.value) || 1))}
                        className="w-full text-xs p-2.5 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-brand-purple"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-bold text-gray-700 mb-1">
                        كمية الطلب للاختبار (عدد القطع)
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={simQuantity}
                        onChange={(e) => setSimQuantity(Math.max(1, Number(e.target.value) || 1))}
                        className="w-full text-xs p-2.5 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-brand-purple"
                      />
                    </div>

                    <div className="flex flex-wrap gap-2 pt-1">
                      {[100, 250, 500, 1000, 2500, 5000].map((qty) => (
                        <button
                          key={qty}
                          type="button"
                          onClick={() => setSimQuantity(qty)}
                          className={`text-[11px] px-2.5 py-1 rounded-lg font-bold transition-all ${
                            simQuantity === qty
                              ? 'bg-brand-purple text-white shadow-xs'
                              : 'bg-white border border-gray-200 text-gray-700 hover:bg-gray-100'
                          }`}
                        >
                          {qty.toLocaleString()} قطعة
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Computed Results */}
                  {(() => {
                    const sortedTiers = [...discountTiers].sort((a, b) => a.minQuantity - b.minQuantity);
                    let activeDiscount = 0;
                    let nextTier: DiscountTier | null = null;

                    for (let i = 0; i < sortedTiers.length; i++) {
                      if (simQuantity >= sortedTiers[i].minQuantity) {
                        activeDiscount = sortedTiers[i].discountPercentage;
                      } else if (!nextTier) {
                        nextTier = sortedTiers[i];
                      }
                    }

                    const baseTotal = simBasePrice * (simQuantity >= 100 ? simQuantity / 100 : simQuantity);
                    const savings = Math.round(baseTotal * (activeDiscount / 100) * 10) / 10;
                    const finalTotal = Math.max(0, Math.round(baseTotal - savings));
                    const effectiveUnit = simQuantity > 0 ? (finalTotal / simQuantity).toFixed(2) : '0';

                    return (
                      <div className="bg-brand-purple/5 p-4 rounded-xl border border-brand-purple/20 space-y-3 flex flex-col justify-between">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-600">نسبة الخصم المطبقة:</span>
                            <span className="font-black text-brand-purple bg-white px-2 py-0.5 rounded-md border border-purple-200">
                              {activeDiscount}%
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-xs">
                            <span className="text-gray-600">المجموع قبل الخصم:</span>
                            <span className="font-bold text-gray-500 line-through">
                              {Math.round(baseTotal)} ₪
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-xs">
                            <span className="text-emerald-700 font-bold">توفير العميل المالي:</span>
                            <span className="font-black text-emerald-600 bg-emerald-100/60 px-2 py-0.5 rounded-md">
                              - {savings} ₪
                            </span>
                          </div>

                          <div className="flex items-center justify-between pt-2 border-t border-purple-200/60">
                            <span className="font-bold text-sm text-gray-900">السعر النهائي للعميل:</span>
                            <span className="text-xl font-black text-brand-purple">
                              {finalTotal} ₪
                            </span>
                          </div>

                          <div className="flex items-center justify-between text-[11px] text-gray-500 pt-1">
                            <span>السعر الصافي للقطعة الواحدة:</span>
                            <span className="font-bold text-brand-dark">{effectiveUnit} ₪ / قطعة</span>
                          </div>
                        </div>

                        {nextTier && (
                          <div className="p-2.5 rounded-lg bg-white border border-purple-200 text-xs text-brand-purple flex items-center justify-between">
                            <span>الشريحة القادمة: {nextTier.discountPercentage}%</span>
                            <span className="font-bold text-[11px]">
                              أضف {(nextTier.minQuantity - simQuantity).toLocaleString()} قطعة لتفعيلها
                            </span>
                          </div>
                        )}
                      </div>
                    );
                  })()}
                </div>
              </div>
            </div>
          )}

          {/* TAB: CUSTOMER TESTIMONIALS & REVIEWS */}
          {activeTab === 'testimonials' && (
            <div className="space-y-6">
              {testimonialActionMsg && (
                <div className="p-3.5 rounded-2xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center justify-between animate-fade-in shadow-xs">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-emerald-600" />
                    <span>{testimonialActionMsg}</span>
                  </div>
                  <button onClick={() => setTestimonialActionMsg('')} className="text-emerald-600 hover:text-emerald-900 cursor-pointer">
                    <X size={16} />
                  </button>
                </div>
              )}

              {/* Top Statistics & Action Header */}
              <div className="bg-white p-6 rounded-3xl border border-gray-200/80 shadow-xs space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-100">
                  <div>
                    <h3 className="text-lg font-black text-gray-900 flex items-center gap-2">
                      <Star size={20} className="text-brand-yellow fill-brand-yellow" />
                      <span>إدارة آراء وتقييمات العملاء الحقيقية</span>
                    </h3>
                    <p className="text-xs text-gray-500 mt-1">
                      تحكم كامل بآراء وتقييمات العملاء التي تظهر على الموقع، مع إمكانية التعديل، الحذف، والتوثيق المباشر.
                    </p>
                  </div>

                  <button
                    onClick={handleOpenAddTestimonial}
                    className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl font-bold text-xs text-brand-purple bg-brand-yellow hover:bg-yellow-300 transition-all shadow-md active:scale-95 cursor-pointer self-start sm:self-auto"
                  >
                    <Plus size={16} />
                    <span>إضافة رأي جديد</span>
                  </button>
                </div>

                {/* 4 Summary Stat Cards */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
                  <div className="p-4 rounded-2xl bg-purple-50/70 border border-purple-100">
                    <span className="text-[11px] font-bold text-purple-700 block mb-1">إجمالي الآراء المسجلة</span>
                    <span className="text-2xl font-black text-brand-purple font-mono">{testimonialsList.length}</span>
                  </div>

                  <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-100">
                    <span className="text-[11px] font-bold text-emerald-700 block mb-1">آراء معتمدة ومنشورة</span>
                    <span className="text-2xl font-black text-emerald-800 font-mono">
                      {testimonialsList.filter((t) => (t.status || 'approved') === 'approved').length}
                    </span>
                  </div>

                  <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-100">
                    <span className="text-[11px] font-bold text-amber-700 block mb-1">متوسط تقييم النجوم</span>
                    <div className="flex items-center gap-1.5">
                      <span className="text-2xl font-black text-amber-800 font-mono">
                        {testimonialsList.length > 0
                          ? (
                              testimonialsList.reduce((acc, t) => acc + (t.rating || 5), 0) /
                              testimonialsList.length
                            ).toFixed(1)
                          : '5.0'}
                      </span>
                      <div className="flex text-amber-400">
                        <Star size={16} fill="currentColor" />
                      </div>
                    </div>
                  </div>

                  <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-100">
                    <span className="text-[11px] font-bold text-blue-700 block mb-1">عملاء موثقون بطلبيات</span>
                    <span className="text-2xl font-black text-blue-800 font-mono">
                      {testimonialsList.filter((t) => t.verified).length}
                    </span>
                  </div>
                </div>

                {/* Search & Filter Controls */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 border-t border-gray-100">
                  <div className="relative">
                    <input
                      type="text"
                      value={testimonialSearch}
                      onChange={(e) => setTestimonialSearch(e.target.value)}
                      placeholder="بحث بالاسم أو النشاط أو نص الرأي..."
                      className="w-full text-xs pl-3 pr-9 py-2.5 rounded-xl border border-gray-200 outline-none focus:border-brand-purple focus:ring-1 focus:ring-brand-purple/20 bg-gray-50/50"
                    />
                    <Search size={15} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  </div>

                  <div>
                    <select
                      value={testimonialRatingFilter}
                      onChange={(e) => setTestimonialRatingFilter(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl border border-gray-200 outline-none focus:border-brand-purple bg-gray-50/50 text-gray-700"
                    >
                      <option value="all">كل التقييمات بالنجوم</option>
                      <option value="5">⭐⭐⭐⭐⭐ (5 نجوم فقط)</option>
                      <option value="4">⭐⭐⭐⭐ (4 نجوم)</option>
                      <option value="3">⭐⭐⭐ (3 نجوم)</option>
                    </select>
                  </div>

                  <div>
                    <select
                      value={testimonialStatusFilter}
                      onChange={(e) => setTestimonialStatusFilter(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-xl border border-gray-200 outline-none focus:border-brand-purple bg-gray-50/50 text-gray-700"
                    >
                      <option value="all">كافة الحالات (الكل)</option>
                      <option value="approved">معتمد ومنشور بالموقع</option>
                      <option value="pending">قيد المراجعة والانتظار</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Testimonials Cards Grid */}
              {filteredTestimonials.length === 0 ? (
                <div className="bg-white p-12 rounded-3xl border border-dashed border-gray-300 text-center space-y-3">
                  <Star size={36} className="mx-auto text-gray-300" />
                  <h4 className="font-bold text-gray-800 text-sm">لا توجد آراء مطابقة للبحث</h4>
                  <p className="text-xs text-gray-500 max-w-sm mx-auto">
                    يمكنك تعديل معايير البحث أو إضافة رأي عميل جديد بضغطة زر.
                  </p>
                  <button
                    onClick={handleOpenAddTestimonial}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-brand-purple text-white text-xs font-bold rounded-xl shadow-xs hover:bg-[#4d2377] transition-all cursor-pointer"
                  >
                    <Plus size={14} />
                    <span>إضافة أول تقييم</span>
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {filteredTestimonials.map((item) => {
                    const isApproved = (item.status || 'approved') === 'approved';
                    const ratingNum = item.rating || 5;

                    return (
                      <div
                        key={item.id}
                        className={`bg-white rounded-2xl border transition-all p-5 flex flex-col justify-between space-y-4 shadow-xs hover:shadow-md ${
                          isApproved ? 'border-gray-200' : 'border-amber-300 bg-amber-50/20'
                        }`}
                      >
                        {/* Card Top: Customer Details */}
                        <div className="space-y-3">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex items-center gap-3">
                              <img
                                src={item.avatar}
                                alt={item.name}
                                onError={(e) => {
                                  (e.target as HTMLImageElement).src =
                                    'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&h=120&q=80';
                                }}
                                className="w-12 h-12 rounded-full object-cover border-2 border-brand-yellow shadow-xs shrink-0"
                              />
                              <div>
                                <h4 className="font-bold text-sm text-gray-900 leading-snug">{item.name}</h4>
                                <p className="text-[11px] text-gray-500 font-medium line-clamp-1">{item.role}</p>
                              </div>
                            </div>

                            {/* Status Pill with Toggle */}
                            <button
                              onClick={() => handleToggleTestimonialStatus(item)}
                              title="انقر لتبديل حالة العرض"
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold border transition-colors cursor-pointer shrink-0 ${
                                isApproved
                                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:bg-emerald-100'
                                  : 'bg-amber-50 text-amber-700 border-amber-200 hover:bg-amber-100'
                              }`}
                            >
                              {isApproved ? 'معتمد' : 'مخفي'}
                            </button>
                          </div>

                          {/* Star Rating and Badges */}
                          <div className="flex flex-wrap items-center justify-between gap-2 pt-1 border-t border-gray-100">
                            <div className="flex items-center gap-1 text-amber-400">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <Star
                                  key={star}
                                  size={14}
                                  fill={star <= ratingNum ? 'currentColor' : 'none'}
                                  className={star <= ratingNum ? 'text-amber-400' : 'text-gray-300'}
                                />
                              ))}
                              <span className="text-[11px] font-mono font-bold text-gray-600 mr-1">
                                {ratingNum}/5
                              </span>
                            </div>

                            <div className="flex items-center gap-1">
                              {/* Verified Customer Toggle */}
                              <button
                                onClick={() => handleToggleTestimonialVerified(item)}
                                title="انقر لتبديل حالة التوثيق"
                                className={
                                  "inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold border cursor-pointer " +
                                  (item.verified
                                    ? "bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100"
                                    : "bg-gray-100 text-gray-500 border-gray-200 hover:bg-gray-200")
                                }
                              >
                                <CheckCircle size={10} className={item.verified ? "text-blue-600" : "text-gray-400"} />
                                <span>{item.verified ? "عميل موثق" : "غير موثق"}</span>
                              </button>
                            </div>
                          </div>

                          {/* Product Reference if available */}
                          {item.productName && (
                            <div className="text-[11px] text-brand-purple bg-purple-50 px-2.5 py-1 rounded-lg font-semibold border border-purple-100 inline-block truncate max-w-full">
                              الطلب: {item.productName}
                            </div>
                          )}

                          {/* Content Quote */}
                          <div className="p-3 rounded-xl bg-gray-50 border border-gray-100 text-xs text-gray-700 leading-relaxed italic relative">
                            "{item.content}"
                          </div>
                        </div>

                        {/* Card Bottom: Date & Management Actions */}
                        <div className="pt-3 border-t border-gray-100 flex items-center justify-between">
                          <span className="text-[10px] text-gray-400 font-mono">
                            {item.date || 'حديثاً'}
                          </span>

                          <div className="flex items-center gap-1.5">
                            <button
                              onClick={() => handleOpenEditTestimonial(item)}
                              className="px-2.5 py-1 rounded-lg bg-gray-100 hover:bg-brand-purple hover:text-white text-gray-700 text-xs font-bold transition-colors flex items-center gap-1 cursor-pointer"
                              title="تعديل التقييم"
                            >
                              <Edit2 size={12} />
                              <span>تعديل</span>
                            </button>

                            <button
                              onClick={() => setDeletingTestimonialId(item.id)}
                              className="p-1 rounded-lg bg-red-50 hover:bg-red-600 hover:text-white text-red-600 transition-colors cursor-pointer"
                              title="حذف التقييم"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* TAB 8: SECURITY */}
          {activeTab === 'security' && (
            <div className="space-y-6 max-w-lg">
              <div className="bg-white p-6 rounded-2xl border border-gray-200/80 shadow-xs space-y-4">
                <div className="flex items-center gap-2 pb-3 border-b border-gray-100">
                  <KeyRound size={19} className="text-brand-purple" />
                  <div>
                    <h3 className="font-black text-sm text-gray-900">تغيير كلمة مرور الإدارة</h3>
                    <p className="text-[11px] text-gray-500">
                      يتم حفظ كلمة المرور مشفرة على السيرفر، ويلغي أي كلمة مرور سابقة فوراً.
                    </p>
                  </div>
                </div>

                {passwordMsg && (
                  <div className="p-3.5 rounded-xl bg-emerald-50 text-emerald-800 text-xs font-bold border border-emerald-200 flex items-center gap-2">
                    <CheckCircle2 size={16} className="text-emerald-600 shrink-0" />
                    <span>{passwordMsg}</span>
                  </div>
                )}

                {passwordError && (
                  <div className="p-3.5 rounded-xl bg-red-50 text-red-800 text-xs font-bold border border-red-200 flex items-center gap-2">
                    <AlertCircle size={16} className="text-red-600 shrink-0" />
                    <span>{passwordError}</span>
                  </div>
                )}

                <form onSubmit={handleChangePassword} className="space-y-3.5">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">
                      كلمة المرور الجديدة (6 خانات على الأقل)
                    </label>
                    <input
                      type="password"
                      required
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="أدخل كلمة مرور قوية"
                      className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">
                      تأكيد كلمة المرور الجديدة
                    </label>
                    <input
                      type="password"
                      required
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="أعد إدخال نفس كلمة المرور للتأكيد"
                      className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                    />
                  </div>

                  <div className="p-3 bg-amber-50/80 rounded-xl border border-amber-200/60 text-[11px] text-amber-900 leading-relaxed">
                    ⚠️ <strong>تنبيه أمني صارم:</strong> بمجرد حفظ كلمة المرور الجديدة، سيتم تعطيل وإلغاء كلمة المرور الافتراضية <code className="bg-white px-1 py-0.5 rounded border border-amber-300 font-mono">admin123</code> نهائياً، ولن يتمكن أي شخص من الدخول إلا بالكلمة الجديدة.
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-brand-purple hover:bg-[#4d2377] text-white py-2.5 rounded-xl text-xs font-bold transition-all shadow-md active:scale-95 flex items-center justify-center gap-1.5"
                  >
                    <Save size={15} />
                    <span>تحديث كلمة المرور وحفظها على السيرفر</span>
                  </button>
                </form>
              </div>

              {/* Active Protection Overview */}
              <div className="bg-gray-50 p-5 rounded-2xl border border-gray-200 text-xs space-y-3">
                <h4 className="font-bold text-gray-800 flex items-center gap-2">
                  <ShieldCheck size={16} className="text-emerald-600" />
                  حالة أنظمة الحماية النشطة
                </h4>
                <div className="space-y-2 text-gray-600">
                  <div className="flex items-center justify-between">
                    <span>إخفاء بيانات الدخول عن العامة:</span>
                    <span className="text-emerald-700 font-bold bg-emerald-100/60 px-2 py-0.5 rounded-full text-[11px]">مفعل ومحمي ✓</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>مكافحة التخمين والقفل المؤقت (5 محاولات):</span>
                    <span className="text-emerald-700 font-bold bg-emerald-100/60 px-2 py-0.5 rounded-full text-[11px]">نشط على السيرفر ✓</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>التحقق الأمني الذكي (Bot Challenge):</span>
                    <span className="text-emerald-700 font-bold bg-emerald-100/60 px-2 py-0.5 rounded-full text-[11px]">نشط ✓</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>اختصار فتح الإدارة المصرح للمشرف:</span>
                    <span className="font-mono text-gray-700 bg-white px-1.5 py-0.5 rounded border text-[11px]">Ctrl+Shift+A</span>
                  </div>
                </div>
              </div>
            </div>
          )}

        </main>
      </div>

      {/* Upload Media Modal */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" dir="rtl">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <h3 className="font-black text-base text-gray-900 flex items-center gap-2">
                <Upload size={18} className="text-brand-purple" />
                <span>رفع صورة أو شعار إلى المكتبة</span>
              </h3>
              <button
                onClick={() => setIsUploadModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 p-1 rounded-full"
              >
                <X size={18} />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">اسم الصورة / الوصف</label>
                <input
                  type="text"
                  value={newMediaName}
                  onChange={(e) => setNewMediaName(e.target.value)}
                  placeholder="مثال: الشعار الذهبي الرسمي، أو عينة رول أب"
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-brand-purple"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">تصنيف الصورة</label>
                <select
                  value={newMediaCategory}
                  onChange={(e) => setNewMediaCategory(e.target.value as MediaItem['category'])}
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 outline-none"
                >
                  <option value="logo">شعار ومطبوعات الهوية</option>
                  <option value="products">منتج ومطبوعات</option>
                  <option value="banners">بانر وإعلان</option>
                  <option value="general">عام</option>
                </select>
              </div>

              {/* Option 1: File Upload */}
              <div className="p-4 bg-gray-50 rounded-2xl border-2 border-dashed border-gray-300 text-center relative cursor-pointer hover:border-brand-purple transition-colors">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleMediaFileUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                />
                <Upload size={24} className="mx-auto text-brand-purple mb-1.5" />
                <span className="text-xs font-bold text-gray-700 block">اضغط لاختيار ملف من جهازك</span>
                <span className="text-[10px] text-gray-400">PNG, JPG, SVG, WebP (سيتم حفظها محلياً)</span>
              </div>

              <div className="relative text-center">
                <span className="text-xs text-gray-400 bg-white px-2">أو أضف رابط خارجي</span>
                <div className="absolute top-1/2 inset-x-0 h-px bg-gray-200 -z-10"></div>
              </div>

              {/* Option 2: Image URL input */}
              <form onSubmit={handleAddMediaUrl} className="space-y-3">
                <input
                  type="text"
                  value={newMediaUrl}
                  onChange={(e) => setNewMediaUrl(e.target.value)}
                  placeholder="https://example.com/image.jpg"
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-brand-purple"
                />
                <button
                  type="submit"
                  className="w-full bg-brand-purple hover:bg-[#4d2377] text-white py-2.5 rounded-xl text-xs font-bold shadow-md transition-all active:scale-95"
                >
                  حفظ الرابط في المكتبة
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Product Add / Edit Modal */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto" dir="rtl">
          <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-7 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <h3 className="font-black text-lg text-gray-900">
                {editingProduct ? 'تعديل بيانات المنتج' : 'إضافة منتج أو خدمة جديدة'}
              </h3>
              <button
                onClick={() => setIsProductModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 p-1 rounded-full"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveProduct} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">اسم المنتج</label>
                  <input
                    type="text"
                    required
                    value={productForm.name}
                    onChange={(e) => setProductForm({ ...productForm, name: e.target.value })}
                    className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                    placeholder="مثال: ستيكرات مقاومة للماء"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">التصنيف</label>
                  <select
                    value={productForm.category}
                    onChange={(e) => setProductForm({ ...productForm, category: e.target.value })}
                    className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                  >
                    {categories.filter((c) => c.id !== 'all').map((c) => (
                      <option key={c.id} value={c.id}>{c.name}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">السعر الأساسي (₪)</label>
                  <input
                    type="number"
                    required
                    value={productForm.price}
                    onChange={(e) => setProductForm({ ...productForm, price: Number(e.target.value) })}
                    className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">الحد الأدنى للكمية</label>
                  <input
                    type="number"
                    required
                    value={productForm.minQuantity}
                    onChange={(e) => setProductForm({ ...productForm, minQuantity: Number(e.target.value) })}
                    className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">وصف المنتج والمواصفات</label>
                <textarea
                  value={productForm.description}
                  onChange={(e) => setProductForm({ ...productForm, description: e.target.value })}
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none h-20 resize-none"
                  placeholder="نوع الورق، تقنيات الطباعة، المقاسات المتوفرة..."
                />
              </div>

              {/* Image Selection with Media Library Integration */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">صورة المنتج</label>
                <input
                  type="text"
                  value={productForm.image}
                  onChange={(e) => setProductForm({ ...productForm, image: e.target.value })}
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none mb-2"
                  placeholder="رابط الصورة أو اختر من مكتبة الصور أدناه"
                />

                <span className="text-[11px] text-gray-400 font-semibold block mb-1">
                  اختر مباشرة من مكتبة صورك المرفوعة:
                </span>
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 max-h-36 overflow-y-auto p-1 border rounded-xl">
                  {mediaList.map((img) => (
                    <button
                      key={img.id}
                      type="button"
                      onClick={() => setProductForm({ ...productForm, image: img.url })}
                      className={`relative rounded-lg overflow-hidden border-2 h-16 transition-all ${
                        productForm.image === img.url
                          ? 'border-brand-purple ring-2 ring-brand-purple/20 scale-105'
                          : 'border-gray-200 opacity-80 hover:opacity-100'
                      }`}
                    >
                      <img src={img.url} alt={img.name} className="w-full h-full object-cover" />
                      <span className="absolute bottom-0 inset-x-0 bg-black/60 text-white text-[9px] p-0.5 truncate text-center">
                        {img.name}
                      </span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsProductModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="bg-brand-purple hover:bg-[#4d2377] text-white px-6 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all active:scale-95"
                >
                  حفظ المنتج
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Quote Edit & Price Setting Modal */}
      {isQuoteModalOpen && editingQuote && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto" dir="rtl">
          <div className="bg-white rounded-3xl w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-7 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <FileText size={20} className="text-brand-purple" />
                <h3 className="font-black text-base text-gray-900">
                  تعديل وتحديد تسعيرة عرض السعر ({editingQuote.id})
                </h3>
              </div>
              <button
                onClick={() => setIsQuoteModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 p-1 rounded-full"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveQuote} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">اسم العميل</label>
                  <input
                    type="text"
                    required
                    value={quoteForm.customerName || ''}
                    onChange={(e) => setQuoteForm({ ...quoteForm, customerName: e.target.value })}
                    className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">رقم الهاتف</label>
                  <input
                    type="text"
                    required
                    value={quoteForm.phone || ''}
                    onChange={(e) => setQuoteForm({ ...quoteForm, phone: e.target.value })}
                    className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">الخدمة المطلوبة</label>
                  <input
                    type="text"
                    required
                    value={quoteForm.serviceName || ''}
                    onChange={(e) => setQuoteForm({ ...quoteForm, serviceName: e.target.value })}
                    className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">الكمية المطلوبة (اختياري)</label>
                  <input
                    type="number"
                    min="1"
                    value={quoteForm.quantity || ''}
                    onChange={(e) => setQuoteForm({ ...quoteForm, quantity: e.target.value ? Number(e.target.value) : undefined })}
                    placeholder="مثال: 500"
                    className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-emerald-800 mb-1">
                    السعر المقترح للعميل (₪ شيكل)
                  </label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    value={quoteForm.offeredPrice !== undefined ? quoteForm.offeredPrice : ''}
                    onChange={(e) => setQuoteForm({ ...quoteForm, offeredPrice: e.target.value !== '' ? Number(e.target.value) : undefined })}
                    placeholder="حدد السعر الإجمالي المقترح"
                    className="w-full text-xs p-2.5 rounded-xl border-2 border-emerald-300 focus:ring-2 focus:ring-emerald-500 font-bold text-emerald-700 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">حالة العرض</label>
                  <select
                    value={quoteForm.status || 'new'}
                    onChange={(e) => setQuoteForm({ ...quoteForm, status: e.target.value as QuoteRequest['status'] })}
                    className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none font-bold"
                  >
                    <option value="new">جديد (بانتظار الرد)</option>
                    <option value="contacted">تم التواصل والتسعير</option>
                    <option value="completed">مكتمل وتم الاتفاق</option>
                    <option value="cancelled">ملغي / غير مناسب</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">تفاصيل طلب العميل</label>
                <textarea
                  value={quoteForm.details || ''}
                  onChange={(e) => setQuoteForm({ ...quoteForm, details: e.target.value })}
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none h-20 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-amber-800 mb-1">
                  ملاحظات وتوصيات فنية من الإدارة (تظهر في واتساب العميل)
                </label>
                <textarea
                  value={quoteForm.adminNotes || ''}
                  onChange={(e) => setQuoteForm({ ...quoteForm, adminNotes: e.target.value })}
                  placeholder="مثال: نوع الورق كوشيه 350 غم مع سلوفان مطفي وبصمة ذهبية، التسليم خلال 48 ساعة."
                  className="w-full text-xs p-2.5 rounded-xl border border-amber-200 focus:ring-2 focus:ring-amber-500 outline-none h-20 resize-none bg-amber-50/30"
                />
              </div>

              <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => handleSendWhatsAppProposal({ ...editingQuote, ...quoteForm } as QuoteRequest)}
                  className="flex items-center gap-1.5 bg-[#25D366] hover:bg-emerald-600 text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-sm transition-all"
                >
                  <MessageCircle size={15} />
                  <span>معاينة وإرسال عبر واتساب</span>
                </button>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setIsQuoteModalOpen(false)}
                    className="px-4 py-2.5 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="bg-brand-purple hover:bg-[#4d2377] text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all active:scale-95 flex items-center gap-1.5"
                  >
                    <Save size={15} />
                    <span>حفظ التعديلات</span>
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Discount Tier Add / Edit Modal */}
      {isTierModalOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" dir="rtl">
          <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl p-6 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <h3 className="font-black text-base text-gray-900 flex items-center gap-2">
                <Percent size={18} className="text-brand-purple" />
                <span>{editingTierIndex !== null ? 'تعديل شريحة الخصم' : 'إضافة شريحة خصم جديدة'}</span>
              </h3>
              <button
                onClick={() => setIsTierModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 p-1 rounded-full"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveTier} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  الحد الأدنى للكمية لتطبيق الخصم (عدد القطع)
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  value={tierForm.minQuantity}
                  onChange={(e) => setTierForm({ ...tierForm, minQuantity: Math.max(1, Number(e.target.value) || 1) })}
                  placeholder="مثال: 500"
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-brand-purple"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  نسبة الخصم المئوية (% OFF)
                </label>
                <input
                  type="number"
                  required
                  min="1"
                  max="99"
                  value={tierForm.discountPercentage}
                  onChange={(e) => setTierForm({ ...tierForm, discountPercentage: Math.max(1, Math.min(99, Number(e.target.value) || 1)) })}
                  placeholder="مثال: 15"
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-brand-purple"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">
                  وصف الشريحة التوضيحي (اختياري)
                </label>
                <input
                  type="text"
                  value={tierForm.label || ''}
                  onChange={(e) => setTierForm({ ...tierForm, label: e.target.value })}
                  placeholder="مثال: خصم 15% للكميات الكبيرة فوق 1,000 قطعة"
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-brand-purple"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsTierModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="bg-brand-purple hover:bg-[#4d2377] text-white px-5 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all active:scale-95"
                >
                  {editingTierIndex !== null ? 'تحديث الشريحة' : 'حفظ الشريحة'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* View Order Details & Invoice Modal */}
      {isViewOrderModalOpen && viewingOrder && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto" dir="rtl">
          <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl p-6 sm:p-8 space-y-6">
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-gray-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-brand-purple/10 text-brand-purple flex items-center justify-center font-bold">
                  <FileText size={20} />
                </div>
                <div>
                  <h3 className="font-black text-lg text-gray-900 flex items-center gap-2">
                    <span>تفاصيل الطلبية وأمر التشغيل</span>
                    <span className="font-mono text-sm bg-brand-purple text-white px-2.5 py-0.5 rounded-lg">
                      {viewingOrder.id}
                    </span>
                  </h3>
                  <p className="text-xs text-gray-400">
                    تاريخ التسجيل: {new Date(viewingOrder.createdAt).toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleOpenExportPdf(viewingOrder, 'invoice')}
                  className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-white text-xs px-3 py-1.5 rounded-xl font-bold transition-all shadow-xs"
                  title="تصدير فاتورة مبيعات أو سند تسليم PDF"
                >
                  <FileText size={14} />
                  <span>تصدير PDF</span>
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="p-2 text-gray-500 hover:text-brand-purple hover:bg-gray-100 rounded-xl transition-colors"
                  title="طباعة أمر التشغيل / الفاتورة"
                >
                  <Printer size={18} />
                </button>
                <button
                  type="button"
                  onClick={() => setIsViewOrderModalOpen(false)}
                  className="p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* Customer & Delivery Information Card */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-gray-50 p-4 rounded-2xl border border-gray-100 text-xs">
              <div className="space-y-1.5">
                <div className="font-bold text-gray-800 text-sm">{viewingOrder.customerName}</div>
                <div className="text-gray-600 flex items-center gap-1.5">
                  <Phone size={13} className="text-brand-purple" />
                  <span className="font-mono font-semibold">{viewingOrder.customerPhone}</span>
                </div>
                {viewingOrder.customerAddress && (
                  <div className="text-gray-600">
                    <span className="font-bold">العنوان:</span> {viewingOrder.customerAddress}
                  </div>
                )}
              </div>

              <div className="space-y-1.5 sm:border-r sm:border-gray-200/80 sm:pr-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-500">حالة الطلب:</span>
                  <span
                    className={`font-bold px-2.5 py-0.5 rounded-full text-[11px] ${
                      viewingOrder.status === 'new'
                        ? 'bg-amber-100 text-amber-800'
                        : viewingOrder.status === 'review'
                        ? 'bg-purple-100 text-purple-800'
                        : viewingOrder.status === 'in_press'
                        ? 'bg-blue-100 text-blue-800'
                        : viewingOrder.status === 'packaging'
                        ? 'bg-orange-100 text-orange-800'
                        : viewingOrder.status === 'ready'
                        ? 'bg-emerald-100 text-emerald-800'
                        : viewingOrder.status === 'completed'
                        ? 'bg-gray-100 text-gray-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {viewingOrder.status === 'new'
                      ? 'جديد'
                      : viewingOrder.status === 'review'
                      ? 'قيد التدقيق الفني'
                      : viewingOrder.status === 'in_press'
                      ? 'في المطبعة'
                      : viewingOrder.status === 'packaging'
                      ? 'مرحلة التغليف'
                      : viewingOrder.status === 'ready'
                      ? 'جاهز للاستلام والتوصيل'
                      : viewingOrder.status === 'completed'
                      ? 'تم التسليم'
                      : 'ملغي'}
                  </span>
                </div>
                {viewingOrder.statusNote && (
                  <div className="text-gray-600">
                    <span className="font-bold">ملاحظة المرحلة:</span> {viewingOrder.statusNote}
                  </div>
                )}
                {viewingOrder.estimatedDate && (
                  <div className="text-gray-600">
                    <span className="font-bold">الموعد المتوقع:</span> {viewingOrder.estimatedDate}
                  </div>
                )}
              </div>
            </div>

            {viewingOrder.notes && (
              <div className="bg-amber-50 p-3 rounded-xl border border-amber-200/60 text-xs text-amber-900">
                <span className="font-bold">ملاحظات العميل العامة: </span>
                {viewingOrder.notes}
              </div>
            )}

            {/* Line Items Table */}
            <div className="space-y-2">
              <h4 className="font-black text-xs text-gray-700">الأصناف المطلوبة والمواصفات:</h4>
              <div className="border border-gray-200 rounded-2xl overflow-hidden divide-y divide-gray-100">
                {viewingOrder.items.map((item, idx) => (
                  <div key={idx} className="p-4 space-y-2 bg-white text-xs">
                    <div className="flex items-center justify-between">
                      <div className="font-bold text-sm text-gray-900 flex items-center gap-2">
                        <span className="text-brand-purple font-mono">#{idx + 1}</span>
                        <span>{item.productName}</span>
                      </div>
                      <div className="font-black text-sm text-brand-purple">
                        {item.totalPrice} ₪
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] text-gray-500 bg-gray-50/70 p-2.5 rounded-xl">
                      <div>
                        الكمية: <span className="font-bold text-gray-900">{item.quantity.toLocaleString()}</span> قطعة
                      </div>
                      <div>
                        سعر الوحدة: <span className="font-bold text-gray-900">{item.unitPrice} ₪</span>
                      </div>
                      {item.discountPercentage > 0 && (
                        <div className="text-emerald-700 font-bold">
                          الخصم: {item.discountPercentage}%
                        </div>
                      )}
                      <div>
                        الإجمالي: <span className="font-bold text-brand-purple">{item.totalPrice} ₪</span>
                      </div>
                    </div>

                    {item.optionsSummary && (
                      <div className="text-[11px] text-gray-600">
                        <span className="font-bold text-gray-700">الخيارات المحددة:</span> {item.optionsSummary}
                      </div>
                    )}

                    {item.customText && (
                      <div className="text-[11px] text-purple-900 bg-purple-50 p-2 rounded-lg">
                        <span className="font-bold">نص الطباعة / متطلبات العميل:</span> {item.customText}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Financial Summary */}
            <div className="bg-brand-purple/5 p-4 rounded-2xl border border-brand-purple/20 space-y-2 text-xs">
              <div className="flex items-center justify-between text-gray-600">
                <span>المجموع الفرعي:</span>
                <span className="font-bold">{viewingOrder.subtotal} ₪</span>
              </div>
              {viewingOrder.discountTotal > 0 && (
                <div className="flex items-center justify-between text-emerald-700 font-bold">
                  <span>إجمالي الخصم الترويجي:</span>
                  <span>- {viewingOrder.discountTotal} ₪</span>
                </div>
              )}
              <div className="flex items-center justify-between text-base font-black text-brand-purple pt-2 border-t border-purple-200">
                <span>المجموع الإجمالي للطلب:</span>
                <span>{viewingOrder.finalTotal} ₪</span>
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-gray-100">
              <button
                type="button"
                onClick={() =>
                  sendWhatsAppMessage(
                    viewingOrder.customerPhone,
                    `مرحباً ${viewingOrder.customerName}، تفاصيل طلبك رقم (${viewingOrder.id}):\nعدد المنتجات: ${viewingOrder.items.length}\nالمجموع الإجمالي: ${viewingOrder.finalTotal} ₪\nالحالة الحالية: ${viewingOrder.statusNote || 'قيد المعالجة'}.`
                  )
                }
                className="flex items-center gap-1.5 bg-[#25D366] hover:bg-emerald-600 text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-xs"
              >
                <MessageCircle size={15} />
                <span>إرسال الفاتورة عبر واتساب</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleOpenExportPdf(viewingOrder, 'invoice')}
                  className="flex items-center gap-1.5 bg-amber-500 hover:bg-amber-600 text-white px-4 py-2.5 rounded-xl text-xs font-bold transition-all shadow-xs"
                  title="تصدير فاتورة مبيعات أو سند تسليم PDF"
                >
                  <FileText size={15} />
                  <span>تصدير إلى PDF</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setIsViewOrderModalOpen(false);
                    handleOpenEditOrder(viewingOrder);
                  }}
                  className="flex items-center gap-1.5 bg-brand-purple hover:bg-[#4d2377] text-white px-4 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all active:scale-95"
                >
                  <Edit2 size={14} />
                  <span>تعديل هذه الطلبية</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsViewOrderModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Edit Order Modal */}
      {isEditOrderModalOpen && editingOrder && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto" dir="rtl">
          <div className="bg-white rounded-3xl w-full max-w-3xl max-h-[92vh] overflow-y-auto shadow-2xl p-6 sm:p-8 space-y-6">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-brand-purple text-white flex items-center justify-center">
                  <Edit2 size={18} />
                </div>
                <div>
                  <h3 className="font-black text-base text-gray-900">
                    تعديل بيانات وأصناف الطلبية ({editingOrder.id})
                  </h3>
                  <p className="text-xs text-gray-400">
                    يمكنك تعديل بيانات العميل، إضافة أو حذف منتجات، وتعديل الكميات والأسعار.
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsEditOrderModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 p-1 rounded-full"
              >
                <X size={20} />
              </button>
            </div>

            <form onSubmit={handleSaveEditOrder} className="space-y-5">
              {/* Customer Info Inputs */}
              <div className="bg-gray-50/80 p-4 rounded-2xl border border-gray-200/80 space-y-3">
                <h4 className="font-bold text-xs text-gray-800">بيانات العميل والتوصيل</h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">اسم العميل</label>
                    <input
                      type="text"
                      required
                      value={editOrderForm.customerName || ''}
                      onChange={(e) => setEditOrderForm({ ...editOrderForm, customerName: e.target.value })}
                      className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">رقم الهاتف</label>
                    <input
                      type="text"
                      required
                      value={editOrderForm.customerPhone || ''}
                      onChange={(e) => setEditOrderForm({ ...editOrderForm, customerPhone: e.target.value })}
                      className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">عنوان التوصيل (اختياري)</label>
                    <input
                      type="text"
                      value={editOrderForm.customerAddress || ''}
                      onChange={(e) => setEditOrderForm({ ...editOrderForm, customerAddress: e.target.value })}
                      placeholder="المدينة، الشارع، تفاصيل التوصيل"
                      className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">المرحلة الحالية للطلب</label>
                    <select
                      value={editOrderForm.status || 'review'}
                      onChange={(e) => setEditOrderForm({ ...editOrderForm, status: e.target.value as OrderWorkflowStatus })}
                      className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none bg-white font-bold text-brand-purple"
                    >
                      <option value="new">1. استلام الطلب (جديد)</option>
                      <option value="review">2. قيد المراجعة والتدقيق الفني</option>
                      <option value="in_press">3. في المطبعة قيد التنفيذ</option>
                      <option value="packaging">4. مرحلة التغليف والتجهيز</option>
                      <option value="ready">5. جاهز للاستلام والتوصيل</option>
                      <option value="completed">تم التسليم النهائي</option>
                      <option value="cancelled">ملغي</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">الملاحظة الفنية للعميل</label>
                    <input
                      type="text"
                      value={editOrderForm.statusNote || ''}
                      onChange={(e) => setEditOrderForm({ ...editOrderForm, statusNote: e.target.value })}
                      placeholder="مثال: جاري تجهيز قوالب الطباعة..."
                      className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-gray-700 mb-1">الموعد المتوقع للتسليم</label>
                    <input
                      type="text"
                      value={editOrderForm.estimatedDate || ''}
                      onChange={(e) => setEditOrderForm({ ...editOrderForm, estimatedDate: e.target.value })}
                      placeholder="مثال: غداً 3 عصراً"
                      className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">ملاحظات العميل</label>
                  <input
                    type="text"
                    value={editOrderForm.notes || ''}
                    onChange={(e) => setEditOrderForm({ ...editOrderForm, notes: e.target.value })}
                    className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-purple outline-none bg-white"
                  />
                </div>
              </div>

              {/* Order Items Editor */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs text-gray-800">
                    أصناف ومنتجات الطلبية ({editOrderForm.items?.length || 0})
                  </h4>
                  <span className="text-[11px] text-gray-400">تعديل الكميات والأسعار يعيد حساب الإجمالي تلقائياً</span>
                </div>

                <div className="space-y-3 max-h-72 overflow-y-auto p-1">
                  {editOrderForm.items?.map((item, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 bg-white rounded-2xl border border-gray-200 space-y-2.5 shadow-xs"
                    >
                      <div className="flex items-center justify-between">
                        <div className="font-bold text-xs text-gray-900 flex items-center gap-2">
                          <span className="bg-brand-purple/10 text-brand-purple px-2 py-0.5 rounded-md font-mono text-[11px]">
                            #{idx + 1}
                          </span>
                          <span>{item.productName}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleRemoveOrderItem(idx)}
                          className="text-red-400 hover:text-red-600 p-1 rounded-lg hover:bg-red-50 text-xs flex items-center gap-1 font-semibold"
                        >
                          <Trash2 size={13} />
                          <span>حذف الصنف</span>
                        </button>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                        <div>
                          <label className="block text-[11px] font-bold text-gray-600 mb-0.5">الكمية (قطع)</label>
                          <input
                            type="number"
                            min="1"
                            value={item.quantity}
                            onChange={(e) => handleItemQuantityChange(idx, Number(e.target.value))}
                            className="w-full text-xs p-2 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-brand-purple font-bold"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-bold text-gray-600 mb-0.5">سعر الوحدة (₪)</label>
                          <input
                            type="number"
                            min="0"
                            step="any"
                            value={item.unitPrice}
                            onChange={(e) => handleItemUnitPriceChange(idx, Number(e.target.value))}
                            className="w-full text-xs p-2 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-brand-purple font-bold"
                          />
                        </div>

                        <div>
                          <label className="block text-[11px] font-bold text-gray-600 mb-0.5">إجمالي الصنف (₪)</label>
                          <div className="w-full text-xs p-2 rounded-xl bg-gray-50 border border-gray-200 font-black text-brand-purple">
                            {item.totalPrice} ₪
                          </div>
                        </div>
                      </div>

                      <div>
                        <label className="block text-[11px] font-bold text-gray-600 mb-0.5">
                          نص الطباعة والملاحظة المخصصة
                        </label>
                        <input
                          type="text"
                          value={item.customText || ''}
                          onChange={(e) => handleItemCustomTextChange(idx, e.target.value)}
                          placeholder="مثال: يرجى وضع الشعار على الوجهين"
                          className="w-full text-xs p-2 rounded-xl border border-gray-200 outline-none focus:ring-2 focus:ring-brand-purple"
                        />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Add New Product to this Order */}
                <div className="flex flex-col sm:flex-row items-center gap-2 p-3 bg-gray-50 rounded-2xl border border-dashed border-gray-300">
                  <select
                    value={selectedNewProductId}
                    onChange={(e) => setSelectedNewProductId(e.target.value)}
                    className="w-full sm:w-auto flex-grow text-xs p-2 rounded-xl border border-gray-200 outline-none bg-white font-medium"
                  >
                    <option value="">-- اختر منتجاً لإضافته إلى الطلبية --</option>
                    {products.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.name} ({p.price} ₪ / {p.minQuantity} قطعة)
                      </option>
                    ))}
                  </select>

                  <button
                    type="button"
                    onClick={handleAddProductToOrder}
                    disabled={!selectedNewProductId}
                    className="w-full sm:w-auto flex items-center justify-center gap-1.5 bg-brand-purple disabled:opacity-50 hover:bg-[#4d2377] text-white px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0"
                  >
                    <Plus size={15} />
                    <span>إضافة الصنف</span>
                  </button>
                </div>
              </div>

              {/* Price Totals Breakdown */}
              <div className="bg-purple-50/70 p-4 rounded-2xl border border-purple-200 space-y-3 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-[11px] font-bold text-gray-600 mb-1">المجموع الفرعي (₪)</label>
                    <input
                      type="number"
                      value={editOrderForm.subtotal !== undefined ? editOrderForm.subtotal : ''}
                      onChange={(e) => setEditOrderForm({ ...editOrderForm, subtotal: Number(e.target.value) })}
                      className="w-full text-xs p-2 rounded-xl border border-purple-200 bg-white font-bold text-gray-700 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-emerald-700 mb-1">الخصم المطبق (₪)</label>
                    <input
                      type="number"
                      value={editOrderForm.discountTotal !== undefined ? editOrderForm.discountTotal : ''}
                      onChange={(e) => {
                        const disc = Number(e.target.value) || 0;
                        const sub = editOrderForm.subtotal || 0;
                        setEditOrderForm({
                          ...editOrderForm,
                          discountTotal: disc,
                          finalTotal: Math.max(0, sub - disc),
                        });
                      }}
                      className="w-full text-xs p-2 rounded-xl border border-emerald-300 bg-white font-bold text-emerald-700 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] font-bold text-brand-purple mb-1">
                      الإجمالي النهائي الصافي (₪)
                    </label>
                    <input
                      type="number"
                      value={editOrderForm.finalTotal !== undefined ? editOrderForm.finalTotal : ''}
                      onChange={(e) => setEditOrderForm({ ...editOrderForm, finalTotal: Number(e.target.value) })}
                      className="w-full text-xs p-2 rounded-xl border-2 border-brand-purple bg-white font-black text-brand-purple outline-none text-base"
                    />
                  </div>
                </div>
              </div>

              {/* Submit / Cancel */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsEditOrderModalOpen(false)}
                  className="px-5 py-2.5 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="bg-brand-purple hover:bg-[#4d2377] text-white px-6 py-2.5 rounded-xl text-xs font-bold shadow-md transition-all active:scale-95 flex items-center gap-1.5"
                >
                  <Save size={15} />
                  <span>حفظ تعديلات الطلبية على السيرفر</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Export to PDF / Printable Invoice & Packing Slip Modal */}
      {isExportPdfModalOpen && pdfExportOrder && (
        <div
          className="fixed inset-0 z-70 flex items-center justify-center p-2 sm:p-4 bg-black/80 backdrop-blur-sm overflow-y-auto printable-modal-overlay"
          dir="rtl"
        >
          <div className="bg-white rounded-3xl w-full max-w-4xl max-h-[96vh] overflow-y-auto shadow-2xl p-4 sm:p-8 space-y-6 printable-document-sheet">
            {/* Non-print Top Action Toolbar */}
            <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-gray-200">
              <div>
                <h3 className="font-black text-lg text-gray-900 flex items-center gap-2">
                  <FileText size={22} className="text-amber-500" />
                  <span>تصدير وطباعة مستند الطلب ({pdfExportOrder.id})</span>
                </h3>
                <p className="text-xs text-gray-500 mt-0.5">
                  يمكنك التبديل بين الفاتورة الضريبية وسند التسليم/بوليصة الشحن، ثم التصدير كملف PDF جاهز للعميل
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {/* Doc Type Selector */}
                <div className="bg-gray-100 p-1 rounded-xl flex items-center text-xs font-bold">
                  <button
                    type="button"
                    onClick={() => setExportDocType('invoice')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      exportDocType === 'invoice'
                        ? 'bg-white text-brand-purple shadow-xs font-black'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    فاتورة مبيعات (Invoice)
                  </button>
                  <button
                    type="button"
                    onClick={() => setExportDocType('packing_slip')}
                    className={`px-3 py-1.5 rounded-lg transition-all ${
                      exportDocType === 'packing_slip'
                        ? 'bg-white text-brand-purple shadow-xs font-black'
                        : 'text-gray-600 hover:text-gray-900'
                    }`}
                  >
                    سند تسليم وبوليصة شحن (Packing Slip)
                  </button>
                </div>

                {/* Export to PDF / Print Button */}
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-2 bg-brand-purple hover:bg-[#4d2377] text-white px-4 py-2 rounded-xl text-xs font-black shadow-md transition-all active:scale-95 cursor-pointer"
                  title="حفظ بصيغة PDF أو طباعة فورية"
                >
                  <Printer size={16} />
                  <span>تصدير إلى PDF / طباعة</span>
                </button>

                <button
                  type="button"
                  onClick={() => setIsExportPdfModalOpen(false)}
                  className="p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors cursor-pointer"
                >
                  <X size={20} />
                </button>
              </div>
            </div>

            {/* The Printable A4 Sheet Body */}
            <div className="bg-white p-6 sm:p-10 border border-gray-200 rounded-2xl space-y-6 text-gray-900 font-sans print:border-0 print:p-0">
              {/* Printable Header */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-6 pb-6 border-b-2 border-gray-900">
                <div>
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-xl bg-brand-purple text-brand-yellow font-black text-2xl flex items-center justify-center font-mono shadow-xs">
                      E
                    </div>
                    <div>
                      <h1 className="text-xl sm:text-2xl font-black text-brand-purple tracking-tight">
                        Enter Print & Technology
                      </h1>
                      <p className="text-xs text-gray-600 font-bold">
                        إنتر تكنولوجي للطباعة الرقمية والأوفست والدعاية والإعلان
                      </p>
                    </div>
                  </div>
                  <div className="text-[11px] text-gray-500 mt-3 space-y-0.5">
                    <p>فلسطين - الضفة الغربية · هاتف المبيعات: <span className="font-mono text-gray-800 font-bold">0568 204 195</span></p>
                    <p>البريد الإلكتروني: <span className="font-mono">enter.co.ps@gmail.com</span></p>
                    <p>خدمات الدعاية والإعلان والطباعة والتجهيز السريع</p>
                  </div>
                </div>

                <div className="text-right sm:text-left space-y-1 sm:self-start">
                  <span className="inline-block bg-brand-purple text-white text-xs font-black px-3.5 py-1.5 rounded-lg uppercase tracking-wider mb-1">
                    {exportDocType === 'invoice' ? 'فاتورة مبيعات وأمر تشغيل' : 'سند تسليم وبوليصة تجهيز'}
                  </span>
                  <div className="text-xs text-gray-500 font-mono">
                    رقم المستند: <strong className="text-gray-900">{exportDocType === 'invoice' ? `INV-${pdfExportOrder.id}` : `PACK-${pdfExportOrder.id}`}</strong>
                  </div>
                  <div className="text-xs text-gray-500 font-mono">
                    رقم الطلب: <strong className="text-brand-purple">{pdfExportOrder.id}</strong>
                  </div>
                  <div className="text-[11px] text-gray-500">
                    تاريخ الإصدار: {new Date().toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })}
                  </div>
                </div>
              </div>

              {/* Customer & Delivery Spec Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-gray-50/90 p-4 rounded-xl border border-gray-200 text-xs">
                <div className="space-y-1.5">
                  <div className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">بيانات العميل المستلم:</div>
                  <div className="text-sm font-black text-gray-900">{pdfExportOrder.customerName}</div>
                  <div className="text-gray-700 font-mono flex items-center gap-1.5">
                    <Phone size={13} className="text-brand-purple" />
                    <span className="font-bold">{pdfExportOrder.customerPhone}</span>
                  </div>
                  <div className="text-gray-600">
                    <span className="font-bold">مكان التسليم: </span>
                    {pdfExportOrder.customerAddress || 'الاستلام المباشر من مقر المطبعة'}
                  </div>
                </div>

                <div className="space-y-1.5 sm:border-r sm:border-gray-200 sm:pr-4">
                  <div className="text-[11px] font-bold text-gray-400 uppercase tracking-wide">بيانات التنفيذ والطلب:</div>
                  <div className="text-gray-700">
                    <span className="font-bold">تاريخ إنشاء الطلب: </span>
                    {new Date(pdfExportOrder.createdAt).toLocaleDateString('ar-EG', { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </div>
                  <div className="text-gray-700">
                    <span className="font-bold">الموعد المحدد للتسليم: </span>
                    <span className="font-semibold text-emerald-700">{pdfExportOrder.estimatedDate || 'خلال 24-48 ساعة'}</span>
                  </div>
                  <div className="text-gray-700">
                    <span className="font-bold">حالة المرحلة: </span>
                    <span className="font-black text-brand-purple">
                      {pdfExportOrder.status === 'ready'
                        ? 'جاهز للاستلام والتوصيل'
                        : pdfExportOrder.status === 'in_press'
                        ? 'في المطبعة قيد التنفيذ'
                        : pdfExportOrder.status === 'packaging'
                        ? 'مرحلة التغليف والتجهيز'
                        : pdfExportOrder.status === 'completed'
                        ? 'تم التسليم'
                        : 'قيد التدقيق والتجهيز'}
                    </span>
                  </div>
                </div>
              </div>

              {pdfExportOrder.notes && (
                <div className="bg-amber-50/80 p-3 rounded-xl border border-amber-200/80 text-xs text-amber-950">
                  <span className="font-bold">ملاحظات العميل والتسليم: </span>
                  {pdfExportOrder.notes}
                </div>
              )}

              {/* Line Items Table */}
              <div className="space-y-2">
                <div className="text-xs font-black text-gray-800">
                  {exportDocType === 'invoice' ? 'جدول الأصناف والخدمات والأسعار:' : 'قائمة محتويات الطرد وأصناف التسليم:'}
                </div>
                <div className="border border-gray-300 rounded-xl overflow-hidden">
                  <table className="w-full text-right text-xs">
                    <thead className="bg-gray-100 text-gray-700 font-bold border-b border-gray-300">
                      <tr>
                        <th className="py-2.5 px-3 w-10 text-center">#</th>
                        <th className="py-2.5 px-3">بيان الصنف والمطبوعات</th>
                        <th className="py-2.5 px-3">المواصفات الفنية ونصوص العميل</th>
                        <th className="py-2.5 px-3 text-center">الكمية</th>
                        {exportDocType === 'invoice' ? (
                          <>
                            <th className="py-2.5 px-3 text-center">سعر الوحدة</th>
                            <th className="py-2.5 px-3 text-center">الخصم</th>
                            <th className="py-2.5 px-3 text-left">الإجمالي</th>
                          </>
                        ) : (
                          <th className="py-2.5 px-3 text-center w-40">حالة الفحص والمطابقة</th>
                        )}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200 bg-white">
                      {pdfExportOrder.items.map((item, idx) => (
                        <tr key={idx} className="hover:bg-gray-50/50">
                          <td className="py-3 px-3 text-center font-mono font-bold text-gray-500">{idx + 1}</td>
                          <td className="py-3 px-3 font-black text-gray-900">{item.productName}</td>
                          <td className="py-3 px-3 text-gray-600 text-[11px] space-y-0.5">
                            {item.optionsSummary && <div>{item.optionsSummary}</div>}
                            {item.customText && (
                              <div className="text-brand-purple font-medium">"{item.customText}"</div>
                            )}
                          </td>
                          <td className="py-3 px-3 text-center font-bold text-gray-900">
                            {item.quantity.toLocaleString()} قطعة
                          </td>
                          {exportDocType === 'invoice' ? (
                            <>
                              <td className="py-3 px-3 text-center font-mono text-gray-700">{item.unitPrice} ₪</td>
                              <td className="py-3 px-3 text-center font-bold text-emerald-700">
                                {item.discountPercentage > 0 ? `${item.discountPercentage}%` : '-'}
                              </td>
                              <td className="py-3 px-3 text-left font-black font-mono text-brand-purple">
                                {item.totalPrice} ₪
                              </td>
                            </>
                          ) : (
                            <td className="py-3 px-3 text-center">
                              <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-0.5 rounded-md">
                                ✓ مطابق للمواصفات
                              </span>
                            </td>
                          )}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Financial Breakdown (Invoice) */}
              {exportDocType === 'invoice' ? (
                <div className="flex justify-end">
                  <div className="w-full sm:w-80 bg-gray-50 p-4 rounded-xl border border-gray-200 text-xs space-y-2">
                    <div className="flex justify-between text-gray-600">
                      <span>المجموع الفرعي:</span>
                      <span className="font-mono font-bold">{pdfExportOrder.subtotal} ₪</span>
                    </div>
                    {pdfExportOrder.discountTotal > 0 && (
                      <div className="flex justify-between text-emerald-700 font-bold">
                        <span>خصم الكميات التصاعدي:</span>
                        <span className="font-mono">- {pdfExportOrder.discountTotal} ₪</span>
                      </div>
                    )}
                    <div className="flex justify-between text-base font-black text-brand-purple pt-2 border-t-2 border-gray-300">
                      <span>المجموع الإجمالي المستحق:</span>
                      <span className="font-mono text-xl">{pdfExportOrder.finalTotal} ₪</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 text-xs text-gray-700 flex flex-wrap items-center justify-between gap-3">
                  <span>إجمالي عدد الطرود / بنود المطبوعات المسلمة: <strong className="text-gray-900">{pdfExportOrder.items.length} صنف</strong></span>
                  <span>الكمية الإجمالية المسلمة: <strong className="text-gray-900">{pdfExportOrder.items.reduce((acc, it) => acc + it.quantity, 0).toLocaleString()} قطعة</strong></span>
                </div>
              )}

              {/* Signature & Seal Block */}
              <div className="grid grid-cols-2 gap-8 pt-8 border-t-2 border-dashed border-gray-300 text-xs">
                <div className="space-y-12">
                  <div>
                    <p className="font-bold text-gray-900">إدارة المطبعة والتدقيق الفني:</p>
                    <p className="text-[11px] text-gray-500">مكتب إنتر تكنولوجي للخدمات الدعائية</p>
                  </div>
                  <div className="text-[11px] text-gray-400 border-b border-gray-300 pb-1 w-48">
                    الختم والتوقيع المعتمد
                  </div>
                </div>

                <div className="space-y-12 text-left">
                  <div>
                    <p className="font-bold text-gray-900">توقيع المستلم / العميل:</p>
                    <p className="text-[11px] text-gray-500">أقر باستلام المطبوعات كاملة وبحالة ممتازة ومطابقة</p>
                  </div>
                  <div className="text-[11px] text-gray-400 border-b border-gray-300 pb-1 w-48 mr-auto">
                    توقيع المستلم والتاريخ
                  </div>
                </div>
              </div>

              {/* Footer Note */}
              <div className="text-center text-[10px] text-gray-400 pt-3 border-t border-gray-200">
                شكراً لاختياركم إنتر تكنولوجي · نلتزم بأعلى معايير الجودة والسرعة في عالم المطبوعات · هاتف المبيعات: 0568 204 195
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Testimonial Add / Edit Modal */}
      {isTestimonialModalOpen && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm overflow-y-auto" dir="rtl">
          <div className="bg-white rounded-3xl w-full max-w-xl max-h-[90vh] overflow-y-auto shadow-2xl p-6 sm:p-7 space-y-5 animate-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-gray-100">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-500">
                  <Star size={18} fill="currentColor" />
                </div>
                <div>
                  <h3 className="font-black text-base text-gray-900">
                    {editingTestimonial ? 'تعديل تقييم ورأي العميل' : 'إضافة رأي وتقييم جديد'}
                  </h3>
                  <p className="text-[11px] text-gray-500">
                    {editingTestimonial ? 'تحديث نص التقييم والبيانات الظاهرة على الموقع' : 'إضافة رأي حقيقي معتمد من زبائن وشركاء المطبعة'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsTestimonialModalOpen(false)}
                className="text-gray-400 hover:text-gray-600 p-1.5 rounded-full hover:bg-gray-100 transition-colors cursor-pointer"
              >
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSaveTestimonial} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">اسم العميل / المؤسسة <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    required
                    value={testimonialForm.name || ''}
                    onChange={(e) => setTestimonialForm({ ...testimonialForm, name: e.target.value })}
                    className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:border-brand-purple focus:ring-1 focus:ring-brand-purple/20 outline-none"
                    placeholder="مثال: م. حسام النجار أو شركة الأوائل"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-700 mb-1">المسمى الوظيفي / المدينة والنشاط <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    required
                    value={testimonialForm.role || ''}
                    onChange={(e) => setTestimonialForm({ ...testimonialForm, role: e.target.value })}
                    className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:border-brand-purple focus:ring-1 focus:ring-brand-purple/20 outline-none"
                    placeholder="مثال: مدير العمليات - رام الله"
                  />
                </div>
              </div>

              {/* Star Rating Selector */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1.5">التقييم بالنجوم (1 إلى 5)</label>
                <div className="flex items-center gap-2 p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <div className="flex items-center gap-1.5">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setTestimonialForm({ ...testimonialForm, rating: star })}
                        className="p-1 hover:scale-125 transition-transform cursor-pointer"
                      >
                        <Star
                          size={24}
                          fill={star <= (testimonialForm.rating || 5) ? 'currentColor' : 'none'}
                          className={star <= (testimonialForm.rating || 5) ? 'text-amber-400' : 'text-gray-300'}
                        />
                      </button>
                    ))}
                  </div>
                  <span className="text-xs font-black text-amber-600 bg-amber-50 px-2.5 py-1 rounded-lg border border-amber-200 mr-auto font-mono">
                    {testimonialForm.rating || 5} من 5 نجوم
                  </span>
                </div>
              </div>

              {/* Associated Product */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">المنتج المرتبط بالطلب (اختياري)</label>
                <select
                  value={testimonialForm.productName || ''}
                  onChange={(e) => setTestimonialForm({ ...testimonialForm, productName: e.target.value })}
                  className="w-full text-xs p-2.5 rounded-xl border border-gray-200 focus:border-brand-purple focus:ring-1 focus:ring-brand-purple/20 outline-none bg-white"
                >
                  <option value="">بدون تحديد منتج معين</option>
                  {products.map((p) => (
                    <option key={p.id} value={p.name}>
                      {p.name}
                    </option>
                  ))}
                  <option value="كروت شخصية فاخرة + رول أب">كروت شخصية فاخرة + رول أب</option>
                  <option value="هدايا دعائية ومطبوعات مكتبية">هدايا دعائية ومطبوعات مكتبية</option>
                  <option value="لافتات ولوحات إعلانية خارجية">لافتات ولوحات إعلانية خارجية</option>
                </select>
              </div>

              {/* Review Content */}
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1">نص التقييم والتجربة <span className="text-red-500">*</span></label>
                <textarea
                  required
                  rows={4}
                  value={testimonialForm.content || ''}
                  onChange={(e) => setTestimonialForm({ ...testimonialForm, content: e.target.value })}
                  className="w-full text-xs p-3 rounded-xl border border-gray-200 focus:border-brand-purple focus:ring-1 focus:ring-brand-purple/20 outline-none leading-relaxed"
                  placeholder="اكتب تجربة العميل الفعلية ورأيه في جودة المطبوعات، سرعة التسليم، التعامل والأسعار..."
                />
              </div>

              {/* Avatar Selector & Presets */}
              <div className="space-y-2 p-3.5 bg-gray-50 rounded-2xl border border-gray-200">
                <label className="block text-xs font-bold text-gray-700">صورة العميل الرمزية (Avatar)</label>
                <div className="flex items-center gap-3">
                  <img
                    src={testimonialForm.avatar || 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&h=120&q=80'}
                    alt="معاينة"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src =
                        'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=120&h=120&q=80';
                    }}
                    className="w-12 h-12 rounded-full object-cover border-2 border-brand-yellow shrink-0 shadow-xs"
                  />
                  <input
                    type="url"
                    value={testimonialForm.avatar || ''}
                    onChange={(e) => setTestimonialForm({ ...testimonialForm, avatar: e.target.value })}
                    placeholder="رابط صورة الصورة الشخصية..."
                    className="flex-grow text-xs p-2 rounded-xl border border-gray-200 focus:border-brand-purple outline-none bg-white"
                  />
                </div>

                {/* 4 Quick Avatar Presets */}
                <div className="flex items-center gap-2 pt-2">
                  <span className="text-[11px] text-gray-500 font-medium">نماذج سريعة:</span>
                  {[
                    { label: 'رجل أعمال', url: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=120&h=120&q=80' },
                    { label: 'سيدة أعمال', url: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=120&h=120&q=80' },
                    { label: 'مهندس / تقني', url: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=120&h=120&q=80' },
                    { label: 'طبيبة / مديرة', url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=120&h=120&q=80' },
                  ].map((preset, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setTestimonialForm({ ...testimonialForm, avatar: preset.url })}
                      className="px-2 py-1 text-[10px] font-bold rounded-lg border border-gray-200 bg-white hover:bg-brand-purple hover:text-white transition-colors cursor-pointer"
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Toggles: Verified & Status */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                <label className="flex items-center gap-2.5 p-3 rounded-xl border border-gray-200 bg-gray-50/50 cursor-pointer hover:bg-gray-100 transition-colors">
                  <input
                    type="checkbox"
                    checked={testimonialForm.verified !== false}
                    onChange={(e) => setTestimonialForm({ ...testimonialForm, verified: e.target.checked })}
                    className="w-4 h-4 text-brand-purple rounded focus:ring-brand-purple"
                  />
                  <div>
                    <span className="text-xs font-bold text-gray-800 block">توثيق العميل (عميل موثق)</span>
                    <span className="text-[10px] text-gray-500">إظهار شارة التحقق الأزرق بجانب الاسم</span>
                  </div>
                </label>

                <label className="flex items-center gap-2.5 p-3 rounded-xl border border-gray-200 bg-gray-50/50 cursor-pointer hover:bg-gray-100 transition-colors">
                  <input
                    type="checkbox"
                    checked={(testimonialForm.status || 'approved') === 'approved'}
                    onChange={(e) =>
                      setTestimonialForm({
                        ...testimonialForm,
                        status: e.target.checked ? 'approved' : 'pending',
                      })
                    }
                    className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
                  />
                  <div>
                    <span className="text-xs font-bold text-gray-800 block">اعتماد ونشر في الموقع</span>
                    <span className="text-[10px] text-gray-500">يظهر فوراً في قسم آراء العملاء بالصفحة الرئيسية</span>
                  </div>
                </label>
              </div>

              {/* Submit / Cancel Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsTestimonialModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl text-xs font-bold text-gray-600 hover:bg-gray-100 transition-colors cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl text-xs font-bold text-white bg-brand-purple hover:bg-[#4d2377] transition-all shadow-md active:scale-95 cursor-pointer flex items-center gap-2"
                >
                  <Save size={14} />
                  <span>{editingTestimonial ? 'حفظ التعديلات' : 'إضافة التقييم'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Testimonial Confirmation Modal */}
      {deletingTestimonialId !== null && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" dir="rtl">
          <div className="bg-white rounded-3xl w-full max-w-sm shadow-2xl p-6 text-center space-y-4 animate-in zoom-in-95 duration-150">
            <div className="w-12 h-12 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center mx-auto border border-red-100">
              <Trash2 size={24} />
            </div>
            <div>
              <h3 className="font-black text-base text-gray-900">تأكيد حذف التقييم</h3>
              <p className="text-xs text-gray-500 mt-1">
                هل أنت متأكد من رغبتك بحذف هذا التقييم نهائياً من قاعدة البيانات وقسم الآراء؟ لا يمكن التراجع عن هذا الإجراء.
              </p>
            </div>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setDeletingTestimonialId(null)}
                className="px-4 py-2.5 rounded-xl text-xs font-bold text-gray-600 bg-gray-100 hover:bg-gray-200 transition-colors cursor-pointer"
              >
                تراجع
              </button>
              <button
                onClick={() => handleDeleteTestimonial(deletingTestimonialId)}
                className="px-5 py-2.5 rounded-xl text-xs font-bold text-white bg-red-600 hover:bg-red-700 transition-all shadow-md cursor-pointer"
              >
                تأكيد الحذف
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

export default AdminDashboard;
