import React, { useState } from 'react';
import { X, Send, MessageCircle, CheckCircle2, Copy, Check } from 'lucide-react';
import { store } from '../services/store';
import { Language, QuoteRequest } from '../types';
import { UI_TRANSLATIONS, LANGUAGES } from '../translations';

interface QuoteModalProps {
  initialProduct?: string;
  onClose: () => void;
  whatsappNumber?: string;
  currentLang?: Language;
}

export const QuoteModal: React.FC<QuoteModalProps> = ({
  initialProduct,
  onClose,
  whatsappNumber = '970568204195',
  currentLang = 'ar',
}) => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [details, setDetails] = useState('');
  const [product, setProduct] = useState(initialProduct || '');
  const [submitted, setSubmitted] = useState(false);
  const [createdQuote, setCreatedQuote] = useState<QuoteRequest | null>(null);
  const [waLink, setWaLink] = useState('');
  const [isCopied, setIsCopied] = useState(false);

  const t = UI_TRANSLATIONS[currentLang] || UI_TRANSLATIONS.ar;
  const isRtl = LANGUAGES[currentLang]?.dir === 'rtl';

  const buildWhatsAppText = (quoteId: string) => {
    const isEn = currentLang === 'en';
    const isHe = currentLang === 'he';
    let text = isEn
      ? `📋 *New Quotation Request - Enter Technology*\n`
      : isHe
      ? `📋 *בקשה להצעת מחיר חדשה - Enter Technology*\n`
      : `📋 *طلب عرض سعر جديد - مطبعة إنتر تكنولوجي*\n`;
    text += `━━━━━━━━━━━━━━━━━━━━━\n`;
    text += isEn
      ? `🔖 *Quote ID:* ${quoteId}\n` +
        `👤 *Customer Name:* ${name.trim()}\n` +
        `📱 *Phone:* ${phone.trim()}\n` +
        `🏷️ *Service/Product:* ${product.trim() || 'Custom Print Project'}\n` +
        `📝 *Specifications & Quantities:* ${details.trim()}\n`
      : isHe
      ? `🔖 *מספר הצעה:* ${quoteId}\n` +
        `👤 *שם הלקוח:* ${name.trim()}\n` +
        `📱 *טלפון:* ${phone.trim()}\n` +
        `🏷️ *שירות/מוצר:* ${product.trim() || 'פרויקט דפוס'}\n` +
        `📝 *מפרט וכמויות:* ${details.trim()}\n`
      : `🔖 *رقم عرض السعر:* ${quoteId}\n` +
        `👤 *اسم العميل:* ${name.trim()}\n` +
        `📱 *رقم الهاتف:* ${phone.trim()}\n` +
        `🏷️ *الخدمة أو المطبوعات:* ${product.trim() || 'مشروع جديد'}\n` +
        `📝 *المواصفات والكميات:* ${details.trim()}\n`;
    text += `━━━━━━━━━━━━━━━━━━━━━\n`;
    text += isEn
      ? `Sent via Enter Technology Online Store`
      : isHe
      ? `נשלח מאתר אינטר טכנולוגיה`
      : `مرسل عبر الموقع الإلكتروني لمطبعة إنتر تكنولوجي`;
    return text;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim()) return;

    // Save quote in store & server
    const saved = await store.addQuote({
      customerName: name.trim(),
      phone: phone.trim(),
      serviceName: product.trim() || (currentLang === 'en' ? 'Custom Print Project' : 'مشروع مطبوعات مخصص'),
      details: details.trim(),
      status: 'new',
    });

    const cleanPhone = whatsappNumber.replace(/[^0-9]/g, '') || '970568204195';
    const waText = buildWhatsAppText(saved.id);
    const url = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(waText)}`;

    setCreatedQuote(saved);
    setWaLink(url);
    setSubmitted(true);

    // Try opening WhatsApp directly
    try {
      window.open(url, '_blank', 'noopener,noreferrer');
    } catch {
      // Handled by direct <a> tag on success view
    }
  };

  const handleCopySummary = () => {
    if (!createdQuote) return;
    const text = buildWhatsAppText(createdQuote.id);
    navigator.clipboard.writeText(text).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2500);
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200 font-sans" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl relative overflow-hidden border border-gray-100">
        
        {/* Header */}
        <div className="bg-brand-purple p-6 text-white text-center relative">
          <button
            onClick={onClose}
            className={`absolute top-4 ${isRtl ? 'left-4' : 'right-4'} text-white/80 hover:text-white hover:bg-white/10 p-1.5 rounded-full transition-colors cursor-pointer`}
          >
            <X size={20} />
          </button>
          <h2 className="text-2xl font-black mb-1">{t.quoteModalTitle}</h2>
          <p className="text-brand-yellow/90 text-xs font-semibold">
            {t.quoteModalSubtitle}
          </p>
        </div>

        {submitted && createdQuote ? (
          <div className="p-7 text-center space-y-4">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-1 animate-bounce">
              <CheckCircle2 size={36} />
            </div>
            
            <h3 className="text-xl font-bold text-gray-800">
              {currentLang === 'en' ? 'Quote Request Received!' : currentLang === 'he' ? 'בקשת הצעת המחיר התקבלה!' : 'تم تسجيل طلب عرض السعر بنجاح!'}
            </h3>
            
            <div className="bg-brand-purple/5 border border-brand-purple/20 p-3.5 rounded-2xl text-xs space-y-1">
              <div className="font-bold text-brand-purple text-sm">
                {currentLang === 'en' ? 'Quote Reference:' : currentLang === 'he' ? 'מספר הצעה:' : 'رقم مرجع العرض:'} {createdQuote.id}
              </div>
              <p className="text-gray-600 leading-relaxed text-[11px]">
                {currentLang === 'en'
                  ? 'To ensure fast processing, please click below to send your request directly to management on WhatsApp.'
                  : currentLang === 'he'
                  ? 'כדי להבטיח מענה מהיר, לחץ על הכפתור למטה לשליחת המפרט ישירות למנהל בוואטסאפ.'
                  : 'لتسريع الرد وتجهيز العرض، اضغط على الزر الأخضر بالأسفل لإرسال المواصفات إلى واتساب إدارة المطبعة مباشرة.'}
              </p>
            </div>
            
            <div className="pt-2 flex flex-col gap-2.5">
              {/* Direct WhatsApp Action Button (Unblockable anchor) */}
              <a
                href={waLink}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full bg-[#25D366] hover:bg-[#20ba5a] text-white py-3.5 rounded-xl font-black text-sm flex items-center justify-center gap-2 shadow-lg transition-all active:scale-95 cursor-pointer"
              >
                <MessageCircle size={20} />
                <span>
                  {currentLang === 'en'
                    ? 'Send to WhatsApp Now'
                    : currentLang === 'he'
                    ? 'שלח לוואטסאפ של המנהל כעת'
                    : 'فتح واتساب وإرسال الطلب للإدارة فوراً 📱'}
                </span>
              </a>

              <button
                type="button"
                onClick={handleCopySummary}
                className="w-full bg-gray-100 hover:bg-gray-200 text-gray-700 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                {isCopied ? <Check size={16} className="text-emerald-600" /> : <Copy size={16} />}
                <span>
                  {isCopied
                    ? (currentLang === 'en' ? 'Copied to Clipboard!' : currentLang === 'he' ? 'הועתק ללוח!' : 'تم نسخ المواصفات بنجاح!')
                    : (currentLang === 'en' ? 'Copy Quote Details' : currentLang === 'he' ? 'העתק פרטי הצעה' : 'نسخ تفاصيل الطلب')}
                </span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="text-gray-500 hover:text-gray-800 text-xs py-2 font-bold cursor-pointer"
              >
                {t.backToStore}
              </button>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">{t.quoteNameLabel}</label>
              <input
                required
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full text-xs border border-gray-200 rounded-xl p-3 focus:ring-2 focus:ring-brand-purple outline-none text-gray-800"
                placeholder={currentLang === 'en' ? 'Your name or organization' : currentLang === 'he' ? 'שמך או שם החברה' : 'اسمك أو اسم مؤسستك'}
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">{t.quotePhoneLabel}</label>
              <input
                required
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full text-xs border border-gray-200 rounded-xl p-3 focus:ring-2 focus:ring-brand-purple outline-none font-mono text-gray-800"
                placeholder="059xxxxxxx"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">{t.quoteServiceLabel}</label>
              <input
                type="text"
                value={product}
                onChange={(e) => setProduct(e.target.value)}
                className="w-full text-xs border border-gray-200 rounded-xl p-3 focus:ring-2 focus:ring-brand-purple outline-none text-gray-800"
                placeholder={currentLang === 'en' ? 'e.g. 1000 Business Cards + 2 Rollups' : currentLang === 'he' ? 'למשל: 1000 כרטיסי ביקור + 2 רול אפ' : 'مثال: طباعة 1000 كرت شخصي + 2 رول أب'}
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">{t.quoteDetailsLabel}</label>
              <textarea
                required
                value={details}
                onChange={(e) => setDetails(e.target.value)}
                className="w-full text-xs border border-gray-200 rounded-xl p-3 h-24 focus:ring-2 focus:ring-brand-purple outline-none resize-none text-gray-800"
                placeholder={currentLang === 'en' ? 'Quantities, dimensions, paper weights, turnaround time...' : currentLang === 'he' ? 'כמויות משוערות, מידות, סוגי נייר, מועד אספקה רצוי...' : 'الكميات التقريبية، المقاسات، نوع السلوفان، موعد التسليم المطلوب...'}
              />
            </div>

            <button
              type="submit"
              className="w-full bg-brand-yellow hover:bg-yellow-400 text-brand-purple font-black py-3.5 rounded-xl text-sm transition-all flex items-center justify-center gap-2 shadow-md active:scale-95 cursor-pointer"
            >
              <Send size={16} />
              <span>{t.quoteSubmitBtn}</span>
            </button>
          </form>
        )}

      </div>
    </div>
  );
};

export default QuoteModal;