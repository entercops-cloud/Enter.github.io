import React, { useState } from 'react';
import { Sparkles, Copy, Loader2, Wand2 } from 'lucide-react';
import { generateMarketingCopy } from '../services/geminiService';

interface AICopywriterProps {
  productName: string;
  onSelectText: (text: string) => void;
}

const AICopywriter: React.FC<AICopywriterProps> = ({ productName, onSelectText }) => {
  const [businessInfo, setBusinessInfo] = useState('');
  const [tone, setTone] = useState<'professional' | 'creative' | 'urgent'>('professional');
  const [generatedText, setGeneratedText] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = async () => {
    if (!businessInfo.trim()) return;
    
    setIsLoading(true);
    const text = await generateMarketingCopy(productName, businessInfo, tone);
    setGeneratedText(text);
    setIsLoading(false);
  };

  return (
    <div className="bg-gradient-to-br from-indigo-50 to-purple-50 p-6 rounded-xl border border-indigo-100 shadow-sm mt-6">
      <div className="flex items-center gap-2 mb-4 text-brand-purple">
        <Sparkles size={24} className="animate-pulse" />
        <h3 className="text-lg font-bold">مساعد الكتابة الذكي (AI)</h3>
      </div>
      
      <p className="text-sm text-gray-600 mb-4">
        لا تملك نصاً جاهزاً للطباعة؟ دع الذكاء الاصطناعي يكتب لك نصاً تسويقياً جذاباً لمنتجك "{productName}".
      </p>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            عن ماذا يدور نشاطك التجاري؟
          </label>
          <textarea
            value={businessInfo}
            onChange={(e) => setBusinessInfo(e.target.value)}
            placeholder="مثال: مطعم برجر يقدم وجبات طازجة، أو شركة عقارات في رام الله..."
            className="w-full p-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-brand-purple focus:border-transparent min-h-[80px]"
          />
        </div>

        <div>
           <label className="block text-sm font-medium text-gray-700 mb-2">اختر النبرة:</label>
           <div className="flex flex-wrap gap-2">
             <button 
                onClick={() => setTone('professional')}
                className={`px-3 py-1 rounded-full text-sm border ${tone === 'professional' ? 'bg-brand-purple text-white border-brand-purple' : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'}`}
             >
                رسمي
             </button>
             <button 
                onClick={() => setTone('creative')}
                className={`px-3 py-1 rounded-full text-sm border ${tone === 'creative' ? 'bg-brand-purple text-white border-brand-purple' : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'}`}
             >
                إبداعي
             </button>
             <button 
                onClick={() => setTone('urgent')}
                className={`px-3 py-1 rounded-full text-sm border ${tone === 'urgent' ? 'bg-brand-purple text-white border-brand-purple' : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'}`}
             >
                تسويقي عاجل
             </button>
           </div>
        </div>

        <button
          onClick={handleGenerate}
          disabled={isLoading || !businessInfo.trim()}
          className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-brand-purple to-indigo-600 text-white py-2 rounded-lg font-semibold hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isLoading ? <Loader2 className="animate-spin" size={20} /> : <Wand2 size={20} />}
          <span>توليد المحتوى</span>
        </button>

        {generatedText && (
          <div className="mt-4 bg-white p-4 rounded-lg border border-gray-200 animate-in fade-in slide-in-from-top-4">
            <h4 className="text-xs font-bold text-gray-400 uppercase mb-2">النص المقترح:</h4>
            <p className="text-gray-800 leading-relaxed whitespace-pre-line">{generatedText}</p>
            <button
              onClick={() => onSelectText(generatedText)}
              className="mt-3 flex items-center gap-2 text-sm text-brand-purple font-bold hover:underline"
            >
              <Copy size={16} />
              <span>استخدام هذا النص في التصميم</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default AICopywriter;
