import React from 'react';
import { Phone, Mail, MapPin, MessageCircle, Truck, Lock, Globe } from 'lucide-react';
import { SiteSettings, Language } from '../types';
import { UI_TRANSLATIONS, LANGUAGES } from '../translations';

interface FooterProps {
  settings: SiteSettings;
  onAdminClick: () => void;
  onOpenQuote: () => void;
  onTrackClick: () => void;
  currentLang: Language;
  onLanguageChange?: (lang: Language) => void;
}

export const Footer: React.FC<FooterProps> = ({
  settings,
  onAdminClick,
  onOpenQuote,
  onTrackClick,
  currentLang,
  onLanguageChange,
}) => {
  const t = UI_TRANSLATIONS[currentLang] || UI_TRANSLATIONS.ar;
  const isRtl = LANGUAGES[currentLang]?.dir === 'rtl';

  return (
    <footer id="contact" className="bg-brand-dark text-white pt-16 pb-8 border-t-4 border-brand-yellow font-sans" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-10 mb-12">
          
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center gap-3 mb-4">
              <img
                src={settings.logoUrl}
                alt={settings.companyName}
                className="h-14 w-auto object-contain bg-white/10 rounded-xl p-2"
              />
            </div>
            <p className="text-gray-400 leading-relaxed text-xs sm:text-sm">
              {settings.companyName} - {settings.tagline}. {t.footerAbout}
            </p>
            <div className="pt-2">
              <a
                href={`https://wa.me/${settings.whatsappNumber}?text=${encodeURIComponent('Hello, I would like to inquire about Enter Technology printing services')}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#20ba5a] text-white px-4 py-2 rounded-xl text-xs font-bold transition-transform active:scale-95 shadow-md cursor-pointer"
              >
                <MessageCircle size={16} />
                <span>{t.fabButtonText}</span>
              </a>
            </div>

            {/* Quick Footer Language Switcher */}
            {onLanguageChange && (
              <div className="pt-2 flex items-center gap-2">
                <Globe size={14} className="text-brand-yellow" />
                <div className="flex items-center gap-1.5">
                  {(['ar', 'en', 'he'] as Language[]).map((l) => (
                    <button
                      key={l}
                      onClick={() => onLanguageChange(l)}
                      className={`text-[11px] px-2 py-1 rounded-md transition-colors cursor-pointer ${
                        currentLang === l
                          ? 'bg-brand-yellow text-brand-purple font-black'
                          : 'text-gray-400 hover:text-white bg-white/5'
                      }`}
                    >
                      {LANGUAGES[l].nativeName}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Contact Details */}
          <div className="space-y-4">
            <h4 className="text-lg font-bold text-white mb-4">{t.footerDirectContact}</h4>
            
            <div className="flex items-start gap-3 text-xs sm:text-sm">
              <MapPin className="text-brand-yellow mt-0.5 shrink-0" size={18} />
              <div>
                <span className="block font-semibold text-gray-200">{t.footerHeadquarters}</span>
                <span className="text-gray-400 text-xs">{settings.address}</span>
              </div>
            </div>

            <div className="flex items-start gap-3 text-xs sm:text-sm">
              <Phone className="text-brand-yellow mt-0.5 shrink-0" size={18} />
              <div>
                <span className="block font-semibold text-gray-200">{t.footerPhone}</span>
                <a
                  href={`tel:${settings.displayPhone.replace(/\s+/g, '')}`}
                  className="text-gray-400 hover:text-white transition-colors text-xs font-mono"
                  dir="ltr"
                >
                  {settings.displayPhone}
                </a>
              </div>
            </div>

            <div className="flex items-start gap-3 text-xs sm:text-sm">
              <Mail className="text-brand-yellow mt-0.5 shrink-0" size={18} />
              <div>
                <span className="block font-semibold text-gray-200">{t.footerEmail}</span>
                <a
                  href={`mailto:${settings.email}`}
                  className="text-gray-400 hover:text-white transition-colors text-xs"
                >
                  {settings.email}
                </a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h4 className="text-lg font-bold text-white mb-4">{t.footerQuickLinks}</h4>
            <ul className="space-y-2.5 text-gray-400 text-xs sm:text-sm">
              <li>
                <a href="#products" className="hover:text-brand-yellow transition-colors">
                  {t.footerBrowseProducts}
                </a>
              </li>
              <li>
                <button
                  onClick={onTrackClick}
                  className={`hover:text-brand-yellow transition-colors ${isRtl ? 'text-right' : 'text-left'} flex items-center gap-1.5 font-bold text-brand-yellow cursor-pointer`}
                >
                  <Truck size={14} />
                  <span>{t.footerTrackOrder}</span>
                </button>
              </li>
              <li>
                <button onClick={onOpenQuote} className={`hover:text-brand-yellow transition-colors ${isRtl ? 'text-right' : 'text-left'} cursor-pointer`}>
                  {t.footerRequestQuote}
                </button>
              </li>
              <li>
                <a href="#features" className="hover:text-brand-yellow transition-colors">
                  {t.footerQualityStandards}
                </a>
              </li>
              <li>
                <a href="#contact" className="hover:text-brand-yellow transition-colors">
                  {t.footerHoursAndLocation}
                </a>
              </li>
            </ul>
          </div>

        </div>

        <div className="border-t border-white/10 pt-6 flex flex-col sm:flex-row items-center justify-between text-gray-400 text-xs gap-3">
          <div className="flex items-center gap-2">
            <p>© {new Date().getFullYear()} {settings.companyName}. {t.footerCopyright}</p>
            {/* Discreet portal lock for authorized staff */}
            <button
              onClick={onAdminClick}
              className="text-white/20 hover:text-brand-yellow p-1 transition-colors rounded hover:bg-white/5 cursor-pointer"
              title={`${t.footerStaffPortal} (Ctrl+Shift+A)`}
              aria-label={t.footerStaffPortal}
            >
              <Lock size={12} />
            </button>
          </div>
          <div className="flex items-center gap-4 text-gray-400">
            <span>{currentLang === 'en' ? 'Digital & Offset Printing' : currentLang === 'he' ? 'דפוס דיגיטלי ואופסט' : 'طباعة رقمية وأوفست وهدايا ترويجية'}</span>
            <span>·</span>
            <span className="text-brand-yellow">{currentLang === 'en' ? 'Progressive Bulk Discounts' : currentLang === 'he' ? 'הנחות כמות מדורגות' : 'خصومات تصاعدية للكميات'}</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;