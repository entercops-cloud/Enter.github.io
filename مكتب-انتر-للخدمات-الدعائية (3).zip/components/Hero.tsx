import React from 'react';
import { ArrowLeft, ArrowRight, Sparkles, MessageCircle, FileSpreadsheet, ChevronDown } from 'lucide-react';
import { SiteSettings, Language } from '../types';
import { UI_TRANSLATIONS, LANGUAGES } from '../translations';

interface HeroProps {
  onCtaClick: () => void;
  onRequestQuote: () => void;
  settings: SiteSettings;
  onWhatsAppClick: () => void;
  currentLang: Language;
}

export const Hero: React.FC<HeroProps> = ({
  onCtaClick,
  onRequestQuote,
  settings,
  onWhatsAppClick,
  currentLang,
}) => {
  const t = UI_TRANSLATIONS[currentLang] || UI_TRANSLATIONS.ar;
  const isRtl = LANGUAGES[currentLang]?.dir === 'rtl';

  // Background image URL with high-definition printing agency fallback
  const bgImage =
    settings.heroBackground ||
    'https://images.unsplash.com/photo-1562654501-a0ccc0fc3fb1?auto=format&fit=crop&w=1920&q=80';

  // Purple overlay opacity (0 to 100, converted to 0 to 1)
  const overlayOpacity =
    (settings.heroOverlayOpacity !== undefined ? Math.max(0, Math.min(100, settings.heroOverlayOpacity)) : 60) / 100;

  // Purple overlay base color
  const overlayColor = settings.heroOverlayColor || '#5D2E8E';

  // Whether elements/text are displayed (default true so text is always returned as requested)
  const showContent = settings.heroShowContent !== false;

  // Responsive height determination
  const minHeightClass =
    settings.heroHeight === 'compact'
      ? 'min-h-[320px] sm:min-h-[380px]'
      : settings.heroHeight === 'large'
      ? 'min-h-[560px] sm:min-h-[660px]'
      : 'min-h-[440px] sm:min-h-[520px]';

  return (
    <div
      className={`relative overflow-hidden flex items-center justify-center font-sans ${minHeightClass}`}
      dir={isRtl ? 'rtl' : 'ltr'}
    >
      {/* 1. Underlying Background Image Layer */}
      <div
        className="absolute inset-0 bg-cover bg-center transition-all duration-700 ease-in-out transform scale-100"
        style={{
          backgroundImage: `url(${bgImage})`,
        }}
      />

      {/* 2. Purple Overlay Layer on Top of Image with Controlled Opacity */}
      <div
        className="absolute inset-0 transition-opacity duration-300 pointer-events-none"
        style={{
          backgroundColor: overlayColor,
          opacity: overlayOpacity,
        }}
      />

      {/* 3. Subtle Vignette & Warm Glow for Depth */}
      <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-black/30 pointer-events-none" />
      <div
        className={`absolute top-0 ${isRtl ? 'right-0 -mr-20' : 'left-0 -ml-20'} -mt-20 w-96 h-96 bg-brand-yellow rounded-full opacity-15 blur-3xl pointer-events-none`}
      />

      {/* 4. Text-Only Content Area (Preserving Background & Overlay Design) */}
      {showContent ? (
        <div className="container mx-auto px-4 py-12 sm:py-16 relative z-10 text-center max-w-4xl animate-in fade-in duration-500">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 bg-black/40 text-brand-yellow rounded-full text-xs sm:text-sm font-black border border-brand-yellow/50 shadow-lg mb-5 backdrop-blur-md">
            <Sparkles size={15} className="animate-pulse text-brand-yellow" />
            <span>{currentLang === 'ar' ? (settings.heroBadge || 'شريكك الأول في التميز الإعلاني') : t.heroBadge}</span>
          </div>

          {/* Main Title & Highlighted Text */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white leading-tight sm:leading-tight tracking-tight drop-shadow-[0_4px_12px_rgba(0,0,0,0.7)] mb-5">
            {currentLang === 'ar' ? (settings.heroTitle || 'نحول أفكارك إلى') : t.heroTitle}{' '}
            <span className="text-brand-yellow relative inline-block drop-shadow-[0_4px_16px_rgba(251,225,34,0.45)]">
              {currentLang === 'ar' ? (settings.heroHighlight || 'واقع ملموس') : t.heroHighlight}
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-sm sm:text-lg lg:text-xl text-gray-100 max-w-2xl mx-auto leading-relaxed sm:leading-relaxed drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)] font-medium mb-8">
            {currentLang === 'ar'
              ? (settings.heroSubtitle || 'نقدم حلولاً متكاملة للطباعة الرقمية والأوفست، الهدايا الترويجية واللافتات بأعلى المعايير وأسعار تنافسية.')
              : t.heroSubtitle}
          </p>

          {/* Action CTA Buttons */}
          <div className="flex flex-wrap items-center justify-center gap-3.5 pt-2">
            <button
              onClick={onCtaClick}
              className="group bg-brand-yellow text-brand-purple px-7 py-3.5 rounded-xl font-black text-sm sm:text-base hover:bg-yellow-300 transition-all shadow-xl shadow-yellow-500/30 flex items-center gap-2 active:scale-95 cursor-pointer hover:shadow-yellow-400/50"
            >
              <span>{t.heroCtaOrder || 'استكشف المنتجات واحسب السعر'}</span>
              {isRtl ? (
                <ArrowLeft className="group-hover:-translate-x-1 transition-transform" size={18} />
              ) : (
                <ArrowRight className="group-hover:translate-x-1 transition-transform" size={18} />
              )}
            </button>

            <button
              onClick={onRequestQuote}
              className="px-6 py-3.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-black/40 hover:bg-black/60 border border-white/40 backdrop-blur-md transition-all flex items-center gap-2 cursor-pointer shadow-lg active:scale-95"
            >
              <FileSpreadsheet size={16} />
              <span>{t.heroCtaQuote || 'طلب عرض سعر لمشروع'}</span>
            </button>

            <button
              onClick={onWhatsAppClick}
              className="px-5 py-3.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-[#25D366] hover:bg-[#20ba5a] transition-all flex items-center gap-1.5 cursor-pointer shadow-lg shadow-green-600/30 active:scale-95"
            >
              <MessageCircle size={17} />
              <span>{t.heroCtaWhatsApp || 'استفسار عبر واتساب'}</span>
            </button>
          </div>
        </div>
      ) : (
        /* Fallback Clean Minimalist Scroll Prompt */
        <div className="relative z-10 flex flex-col items-center justify-end h-full pb-6 text-center select-none">
          <button
            onClick={onCtaClick}
            className="group flex flex-col items-center gap-2 text-white/90 hover:text-white transition-all transform hover:scale-105 cursor-pointer bg-black/40 hover:bg-black/60 backdrop-blur-md px-6 py-3 rounded-full border border-white/30 shadow-xl"
          >
            <span className="text-xs sm:text-sm font-black text-brand-yellow flex items-center gap-1.5">
              <Sparkles size={14} />
              <span>{t.viewAndCalculate || 'استكشف المطبوعات واحسب الأسعار'}</span>
            </span>
            <ChevronDown size={18} className="animate-bounce text-brand-yellow" />
          </button>
        </div>
      )}
    </div>
  );
};

export default Hero;