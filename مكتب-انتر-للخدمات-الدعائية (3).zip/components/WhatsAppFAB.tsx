import React, { useState } from 'react';
import { MessageCircle, X, Send, Clock, CheckCheck } from 'lucide-react';
import { Language } from '../types';
import { UI_TRANSLATIONS, LANGUAGES } from '../translations';

interface WhatsAppFABProps {
  phoneNumber?: string; // e.g. "970568204195"
  companyName?: string;
  currentLang?: Language;
}

export const WhatsAppFAB: React.FC<WhatsAppFABProps> = ({
  phoneNumber = '970568204195',
  companyName = 'Enter Technology | إنتر تكنولوجي',
  currentLang = 'ar',
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState('');

  const t = UI_TRANSLATIONS[currentLang] || UI_TRANSLATIONS.ar;
  const isRtl = LANGUAGES[currentLang]?.dir === 'rtl';

  const quickMessages = [
    t.fabPrompt1,
    t.fabPrompt2,
    t.fabPrompt3,
    t.fabPrompt4,
  ];

  const handleSendMessage = (textToSend?: string) => {
    const defaultMsg =
      currentLang === 'en'
        ? 'Hello, I would like to inquire about printing and advertising services.'
        : currentLang === 'he'
        ? 'שלום, ברצוני לברר לגבי שירותי דפוס ומוצרי פרסום.'
        : 'مرحباً، أود التواصل مع خدمة العملاء بخصوص خدمات الطباعة والدعاية.';

    const finalMsg = textToSend || message || defaultMsg;
    const encoded = encodeURIComponent(finalMsg);
    const url = `https://wa.me/${phoneNumber.replace(/[^0-9]/g, '')}?text=${encoded}`;
    window.open(url, '_blank', 'noopener,noreferrer');
    setMessage('');
    setIsOpen(false);
  };

  return (
    <div className={`fixed bottom-6 ${isRtl ? 'left-6 items-start' : 'right-6 items-end'} z-50 flex flex-col font-sans`} dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Expanded Chat Popover */}
      {isOpen && (
        <div className="mb-3 w-80 sm:w-96 bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="bg-[#075E54] text-white p-4 relative">
            <button
              onClick={() => setIsOpen(false)}
              className={`absolute top-3 ${isRtl ? 'left-3' : 'right-3'} text-white/80 hover:text-white p-1 rounded-full hover:bg-white/10 transition-colors cursor-pointer`}
              aria-label={t.fabClose}
            >
              <X size={18} />
            </button>
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-11 h-11 rounded-full bg-white flex items-center justify-center text-[#25D366] shadow">
                  <MessageCircle size={24} />
                </div>
                <span className={`absolute bottom-0 ${isRtl ? 'right-0' : 'left-0'} w-3 h-3 bg-[#25D366] border-2 border-[#075E54] rounded-full`}></span>
              </div>
              <div>
                <h4 className="font-bold text-sm leading-tight">{companyName}</h4>
                <p className="text-xs text-emerald-100 flex items-center gap-1 mt-0.5">
                  <span className="w-1.5 h-1.5 bg-[#25D366] rounded-full inline-block"></span>
                  {t.fabSupportOnline}
                </p>
              </div>
            </div>
          </div>

          {/* Chat Body & Quick Prompts */}
          <div className="p-4 bg-[#E5DDD5]/30 space-y-3 max-h-[360px] overflow-y-auto">
            {/* Auto welcome message balloon */}
            <div className={`flex flex-col ${isRtl ? 'items-start' : 'items-start'} space-y-1`}>
              <div className="bg-white p-3 rounded-2xl rounded-tr-none shadow-xs text-xs text-gray-800 leading-relaxed max-w-[90%] border border-gray-100">
                <p className="font-semibold text-emerald-900 mb-1">
                  {currentLang === 'en' ? 'Welcome to Enter Technology!' : currentLang === 'he' ? 'ברוכים הבאים ל-Enter Technology!' : 'أهلاً بك في إنتر تكنولوجي!'}
                </p>
                <p className="text-gray-600">
                  {currentLang === 'en'
                    ? 'How can we help your business today? Select a common inquiry below or type your message:'
                    : currentLang === 'he'
                    ? 'כיצד נוכל לעזור לעסק שלך היום? בחר שאלה נפוצה מטה או כתוב הודעה:'
                    : 'كيف يمكننا مساعدتك اليوم في أعمال الطباعة والدعاية؟ اختر أحد الأسئلة السريعة أدناه أو اكتب استفسارك مباشرة:'}
                </p>
                <div className={`flex items-center justify-end gap-1 text-[10px] text-gray-400 mt-1.5 ${isRtl ? 'flex-row' : 'flex-row'}`}>
                  <Clock size={10} />
                  <span>{currentLang === 'en' ? 'Just now' : currentLang === 'he' ? 'עכשיו' : 'الآن'}</span>
                  <CheckCheck size={12} className="text-blue-500" />
                </div>
              </div>
            </div>

            {/* Quick action chips */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[11px] font-bold text-gray-500 block px-1">
                {currentLang === 'en' ? 'Frequently Asked Questions:' : currentLang === 'he' ? 'שאלות נפוצות לפתיחת שיחה:' : 'استفسارات شائعة للبدء:'}
              </span>
              {quickMessages.map((msg, i) => (
                <button
                  key={i}
                  onClick={() => handleSendMessage(msg)}
                  className={`w-full ${isRtl ? 'text-right' : 'text-left'} text-xs bg-white hover:bg-emerald-50 text-gray-700 hover:text-emerald-900 p-2.5 rounded-xl border border-gray-200/80 transition-all hover:border-emerald-300 shadow-2xs hover:shadow-xs active:scale-[0.98] block leading-tight cursor-pointer`}
                >
                  💬 {msg}
                </button>
              ))}
            </div>
          </div>

          {/* Input & Send Form */}
          <div className="p-3 bg-white border-t border-gray-100">
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
                placeholder={t.fabInputPlaceholder}
                className="flex-grow text-xs px-3.5 py-2.5 rounded-full border border-gray-200 focus:border-[#25D366] focus:ring-2 focus:ring-[#25D366]/20 outline-none text-gray-800"
              />
              <button
                onClick={() => handleSendMessage()}
                className="w-9 h-9 rounded-full bg-[#25D366] hover:bg-[#20ba5a] text-white flex items-center justify-center shrink-0 shadow-md transition-transform active:scale-95 cursor-pointer"
                title={t.fabSend}
              >
                <Send size={16} className={isRtl ? 'transform rotate-180' : ''} />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Action Circle Button */}
      <div className="relative group">
        {!isOpen && (
          <div className={`absolute bottom-full ${isRtl ? 'left-0' : 'right-0'} mb-2 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap bg-gray-900 text-white text-xs py-1.5 px-3 rounded-lg shadow-lg`}>
            {t.fabTooltip}
          </div>
        )}

        <button
          onClick={() => setIsOpen(!isOpen)}
          className={`flex items-center gap-3 px-4 py-3.5 rounded-full shadow-2xl transition-all duration-300 transform hover:scale-105 active:scale-95 cursor-pointer ${
            isOpen
              ? 'bg-gray-800 text-white ring-4 ring-gray-300'
              : 'bg-[#25D366] hover:bg-[#20ba5a] text-white ring-4 ring-[#25D366]/30 shadow-[#25D366]/40'
          }`}
          aria-label={t.fabButtonText}
        >
          {/* WhatsApp Icon */}
          <div className="relative">
            <svg
              className="w-7 h-7 fill-current"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M17.507 14.307l-.009.075c-.322.846-1.579 1.558-2.193 1.637-.614.079-1.393.111-2.253-.162-.516-.164-1.18-.396-2.029-.77-3.568-1.574-5.892-5.188-6.071-5.43-.178-.242-1.458-1.942-1.458-3.704 0-1.762.92-2.628 1.246-2.985.326-.357.712-.446.95-.446.237 0 .475.002.684.012.222.01.517-.084.808.614.301.72 1.026 2.502 1.116 2.684.09.182.15.394.029.636-.12.242-.18.394-.356.606-.178.212-.375.474-.535.636-.178.18-.363.376-.156.732.207.356.92 1.517 1.975 2.457 1.357 1.209 2.501 1.584 2.857 1.762.356.178.563.15.772-.089.208-.239.89-1.037 1.127-1.393.237-.356.474-.297.801-.178.326.119 2.077.98 2.433 1.158.356.178.593.267.682.416.089.148.089.86-.233 1.706zM12 2C6.477 2 2 6.477 2 12c0 1.938.553 3.747 1.512 5.276L2.25 21.75l4.636-1.215C8.349 21.464 10.117 22 12 22c5.523 0 10-4.477 10-10S17.523 2 12 2z" />
            </svg>
            {/* Active Green Dot */}
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-white"></span>
            </span>
          </div>

          <span className="font-bold text-sm tracking-wide hidden sm:inline">
            {isOpen ? t.fabClose : t.fabButtonText}
          </span>
        </button>
      </div>
    </div>
  );
};

export default WhatsAppFAB;
