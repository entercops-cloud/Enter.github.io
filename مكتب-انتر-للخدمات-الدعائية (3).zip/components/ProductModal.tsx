import React, { useState, useMemo } from 'react';
import { X, Upload, Check, AlertCircle, Sparkles, TrendingDown, Percent, Layers, ShieldCheck, ShoppingCart, Info, Trash2 } from 'lucide-react';
import { Product, DiscountTier, Language } from '../types';
import AICopywriter from './AICopywriter';
import { DEFAULT_DISCOUNT_TIERS, getLocalizedProductName, getLocalizedProductDesc } from '../constants';
import { UI_TRANSLATIONS, LANGUAGES } from '../translations';

interface ProductModalProps {
  product: Product;
  onClose: () => void;
  onAddToCart: (
    product: Product,
    quantity: number,
    customText: string,
    files: File[],
    calculatedPrice: {
      unitPrice: number;
      discountPercent: number;
      savings: number;
      finalTotal: number;
      selectedOptions: Record<string, string>;
    }
  ) => void;
  onBuyNow?: (
    product: Product,
    quantity: number,
    customText: string,
    files: File[],
    calculatedPrice: {
      unitPrice: number;
      discountPercent: number;
      savings: number;
      finalTotal: number;
      selectedOptions: Record<string, string>;
    }
  ) => void;
  onRequestQuote?: (productName: string) => void;
  currentLang?: Language;
}

export const ProductModal: React.FC<ProductModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onBuyNow,
  onRequestQuote,
  currentLang = 'ar',
}) => {
  const [quantity, setQuantity] = useState<number>(product.minQuantity);
  const [customText, setCustomText] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [showAI, setShowAI] = useState(false);

  const t = UI_TRANSLATIONS[currentLang] || UI_TRANSLATIONS.ar;
  const isRtl = LANGUAGES[currentLang]?.dir === 'rtl';

  // Selected options state
  const [selectedOptions, setSelectedOptions] = useState<Record<string, string>>(() => {
    const initial: Record<string, string> = {};
    if (product.options) {
      product.options.forEach((opt) => {
        if (opt.choices.length > 0) {
          initial[opt.name] = opt.choices[0].label;
        }
      });
    }
    return initial;
  });

  // Determine tiers for this product
  const tiers: DiscountTier[] = useMemo(() => {
    if (product.discountTiers && product.discountTiers.length > 0) {
      return product.discountTiers.sort((a, b) => a.minQuantity - b.minQuantity);
    }
    const mq = product.minQuantity;
    if (mq >= 100) {
      return DEFAULT_DISCOUNT_TIERS;
    } else {
      return [
        { minQuantity: mq * 2, discountPercentage: 5, label: '5%' },
        { minQuantity: mq * 4, discountPercentage: 10, label: '10%' },
        { minQuantity: mq * 8, discountPercentage: 15, label: '15%' },
        { minQuantity: mq * 15, discountPercentage: 20, label: '20%' },
      ];
    }
  }, [product]);

  // Unit base price
  const baseUnitPrice = useMemo(() => {
    if (product.unitPrice && product.unitPrice > 0) {
      return product.unitPrice;
    }
    return product.price / Math.max(1, product.minQuantity);
  }, [product]);

  // Additional options price per batch/unit
  const optionsExtra = useMemo(() => {
    let extra = 0;
    if (product.options) {
      product.options.forEach((opt) => {
        const selectedChoiceLabel = selectedOptions[opt.name];
        const choice = opt.choices.find((c) => c.label === selectedChoiceLabel);
        if (choice) {
          extra += choice.priceModifier;
        }
      });
    }
    return extra;
  }, [product.options, selectedOptions]);

  // Dynamic calculations
  const { currentDiscount, nextTier, unitsToNextTier, subtotal, savings, finalTotal, effectiveUnitPrice } =
    useMemo(() => {
      const safeQty = Math.max(1, Number(quantity) || 1);
      const safeUnit = Math.max(0, Number(baseUnitPrice) || 0);
      const safeExtra = Math.max(0, Number(optionsExtra) || 0);

      let currentDiscount = 0;
      let nextTier: DiscountTier | null = null;

      for (let i = 0; i < tiers.length; i++) {
        if (safeQty >= tiers[i].minQuantity) {
          currentDiscount = tiers[i].discountPercentage;
        } else if (!nextTier) {
          nextTier = tiers[i];
        }
      }

      const unitsToNextTier = nextTier ? Math.max(0, nextTier.minQuantity - safeQty) : 0;
      const baseTotal = safeUnit * safeQty + safeExtra;
      const savings = Math.round((baseTotal * (currentDiscount / 100)) * 10) / 10;
      const finalTotal = Math.max(0, Math.round(baseTotal - savings));
      const effectiveUnitPrice = safeQty > 0 ? (finalTotal / safeQty).toFixed(2) : '0';

      return {
        currentDiscount,
        nextTier,
        unitsToNextTier,
        subtotal: Math.round(baseTotal),
        savings,
        finalTotal,
        effectiveUnitPrice,
      };
    }, [quantity, baseUnitPrice, optionsExtra, tiers]);

  // Quick preset buttons based on min quantity
  const presetQuantities = useMemo(() => {
    const mq = product.minQuantity;
    if (mq >= 100) {
      return [mq, 250, 500, 1000, 2500, 5000].filter((q) => q >= mq);
    } else if (mq >= 10) {
      return [mq, 24, 48, 100, 200, 500];
    } else {
      return [1, 2, 5, 10, 20, 50];
    }
  }, [product.minQuantity]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setFiles((prev) => [...prev, ...newFiles]);
    }
  };

  const removeFile = (idx: number) => {
    setFiles((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleSubmit = () => {
    onAddToCart(product, quantity, customText, files, {
      unitPrice: Number(effectiveUnitPrice),
      discountPercent: currentDiscount,
      savings,
      finalTotal,
      selectedOptions,
    });
    onClose();
  };

  const handleBuyNow = () => {
    const calculated = {
      unitPrice: Number(effectiveUnitPrice),
      discountPercent: currentDiscount,
      savings,
      finalTotal,
      selectedOptions,
    };
    if (onBuyNow) {
      onBuyNow(product, quantity, customText, files, calculated);
    } else {
      onAddToCart(product, quantity, customText, files, calculated);
    }
    onClose();
  };

  const localizedName = getLocalizedProductName(product, currentLang);
  const localizedDesc = getLocalizedProductDesc(product, currentLang);

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm overflow-y-auto font-sans"
      dir={isRtl ? 'rtl' : 'ltr'}
    >
      <div className="bg-white rounded-3xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-2xl animate-in zoom-in-95 duration-200 border border-gray-100 flex flex-col md:flex-row">
        
        {/* Left Side: Product Image & Badges */}
        <div className={`w-full md:w-5/12 bg-gray-50 p-6 flex flex-col justify-between border-b md:border-b-0 ${isRtl ? 'md:border-l' : 'md:border-r'} border-gray-200`}>
          <div>
            <div className="relative rounded-2xl overflow-hidden shadow-sm bg-white border border-gray-200 mb-4 aspect-4/3">
              <img
                src={product.image}
                alt={localizedName}
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
              <div className={`absolute top-3 ${isRtl ? 'right-3' : 'left-3'} bg-brand-purple text-white text-xs font-bold px-3 py-1.5 rounded-full shadow-md flex items-center gap-1`}>
                <span>{t.minQuantityLabel}: {product.minQuantity} {t.unitPiece}</span>
              </div>
            </div>

            <h3 className="text-xl font-black text-gray-900 mb-1">{localizedName}</h3>
            <p className="text-gray-600 text-xs leading-relaxed mb-4">{localizedDesc}</p>

            {/* Tiered Discount Overview Card */}
            <div className="bg-white rounded-2xl p-4 border border-brand-purple/15 shadow-xs space-y-2.5">
              <div className="flex items-center justify-between text-xs font-bold text-brand-purple">
                <span className="flex items-center gap-1.5">
                  <TrendingDown size={16} className="text-emerald-600" />
                  {t.volumeDiscountsTitle}
                </span>
                <span className="text-[10px] text-gray-500 font-semibold">{t.productsBadge}</span>
              </div>

              <div className="space-y-1.5">
                {tiers.map((tier, idx) => {
                  const isActive = quantity >= tier.minQuantity;
                  return (
                    <div
                      key={idx}
                      className={`flex items-center justify-between text-xs px-2.5 py-1.5 rounded-lg transition-colors ${
                        isActive
                          ? 'bg-emerald-50 text-emerald-800 font-bold border border-emerald-200'
                          : 'bg-gray-50 text-gray-600'
                      }`}
                    >
                      <span>{tier.minQuantity.toLocaleString()} {t.unitPiece}+</span>
                      <span className="flex items-center gap-1">
                        {isActive && <Check size={14} className="text-emerald-600" />}
                        {tier.discountPercentage}% {currentLang === 'en' ? 'OFF' : currentLang === 'he' ? 'הנחה' : 'خصم'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          <div className="mt-4 pt-4 border-t border-gray-200/80 text-[11px] text-gray-500 space-y-1">
            <div className="flex items-center gap-1.5 text-gray-700">
              <ShieldCheck size={14} className="text-emerald-600" />
              <span>{currentLang === 'en' ? '100% Color fidelity & precision cutting guarantee' : currentLang === 'he' ? 'אחריות מלאה לדיוק צבעים וחיתוך מושלם' : 'ضمان جودة الألوان ودقة القص ومطابقة المعايير'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Info size={14} className="text-brand-purple" />
              <span>{currentLang === 'en' ? 'Free digital proofing prior to machine production' : currentLang === 'he' ? 'בדיקת קבצים והגהה דיגיטלית ללא תשלום' : 'المعاينة والبروفة مجانية قبل بدء عملية الطباعة'}</span>
            </div>
          </div>
        </div>

        {/* Right Side: Interactive Cost Calculator & Options */}
        <div className="w-full md:w-7/12 p-6 sm:p-7 relative flex flex-col justify-between">
          <button
            onClick={onClose}
            className={`absolute top-4 ${isRtl ? 'left-4' : 'right-4'} p-2 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors cursor-pointer`}
            aria-label="Close"
          >
            <X size={20} />
          </button>

          <div className="space-y-6">
            <div>
              <span className="text-xs font-bold text-brand-purple bg-brand-purple/10 px-2.5 py-1 rounded-md">
                {t.calcTitle}
              </span>
              <h2 className="text-2xl font-black text-gray-900 mt-2">
                {currentLang === 'en' ? 'Configure & Calculate Cost' : currentLang === 'he' ? 'הגדרת הזמנה וחישוב עלות' : 'تخصيص الطلب وحساب التكلفة'}
              </h2>
            </div>

            {/* Interactive Quantity Stepper & Slider */}
            <div className="bg-gray-50/80 p-4 rounded-2xl border border-gray-200/80 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-sm font-bold text-gray-900">{t.selectQuantity}</label>
                <div className="text-xs text-gray-500">
                  {t.unitPriceLabel}: <span className="font-bold text-brand-purple">{effectiveUnitPrice} ₪</span>
                </div>
              </div>

              {/* Number Stepper */}
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setQuantity((q) => Math.max(product.minQuantity, q - (product.minQuantity >= 100 ? 50 : 1)))}
                  className="w-10 h-10 rounded-xl bg-white border border-gray-300 font-bold text-gray-700 hover:bg-gray-100 active:scale-95 text-lg flex items-center justify-center transition-all cursor-pointer"
                >
                  -
                </button>
                <input
                  type="number"
                  min={product.minQuantity}
                  value={quantity || ''}
                  onChange={(e) => {
                    const val = parseInt(e.target.value, 10);
                    setQuantity(isNaN(val) ? 0 : val);
                  }}
                  onBlur={() => {
                    if (!quantity || quantity < product.minQuantity) {
                      setQuantity(product.minQuantity);
                    }
                  }}
                  className="w-28 text-center text-lg font-black text-brand-purple border border-gray-300 rounded-xl py-2 outline-none focus:ring-2 focus:ring-brand-purple"
                />
                <button
                  type="button"
                  onClick={() => setQuantity((q) => q + (product.minQuantity >= 100 ? 50 : 1))}
                  className="w-10 h-10 rounded-xl bg-white border border-gray-300 font-bold text-gray-700 hover:bg-gray-100 active:scale-95 text-lg flex items-center justify-center transition-all cursor-pointer"
                >
                  +
                </button>
                <span className="text-xs text-gray-500 font-bold">{t.unitPiece}</span>
              </div>

              {/* Quick Presets */}
              <div className="flex flex-wrap gap-2 pt-1">
                {presetQuantities.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setQuantity(preset)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                      quantity === preset
                        ? 'bg-brand-purple text-white shadow-xs'
                        : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-100'
                    }`}
                  >
                    {preset.toLocaleString()} {t.unitPiece}
                  </button>
                ))}
              </div>

              {/* Progress to next discount alert */}
              {unitsToNextTier > 0 && nextTier && (
                <div className="p-2.5 rounded-xl bg-purple-50 text-brand-purple text-xs flex items-center gap-2 border border-purple-100">
                  <Percent size={14} className="shrink-0" />
                  <span>
                    {currentLang === 'en'
                      ? `Add ${unitsToNextTier} more pcs to unlock ${nextTier.discountPercentage}% discount!`
                      : currentLang === 'he'
                      ? `הוסף עוד ${unitsToNextTier} יח׳ לקבלת ${nextTier.discountPercentage}% הנחה!`
                      : `أضف ${unitsToNextTier} قطعة إضافية للحصول على خصم ${nextTier.discountPercentage}%!`}
                  </span>
                </div>
              )}
            </div>

            {/* Product Options & Finishes */}
            {product.options && product.options.length > 0 && (
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-gray-700 flex items-center gap-1.5">
                  <Layers size={14} className="text-brand-purple" />
                  <span>{t.printOptions}</span>
                </h4>
                <div className="space-y-3">
                  {product.options.map((opt, i) => (
                    <div key={i}>
                      <label className="block text-xs font-semibold text-gray-600 mb-1.5">{opt.name}</label>
                      <div className="grid grid-cols-2 gap-2">
                        {opt.choices.map((choice, ci) => {
                          const isSelected = selectedOptions[opt.name] === choice.label;
                          return (
                            <button
                              key={ci}
                              type="button"
                              onClick={() =>
                                setSelectedOptions((prev) => ({
                                  ...prev,
                                  [opt.name]: choice.label,
                                }))
                              }
                              className={`p-2.5 rounded-xl border text-xs font-medium transition-all text-start flex items-center justify-between cursor-pointer ${
                                isSelected
                                  ? 'bg-brand-purple/5 border-brand-purple text-brand-purple font-bold ring-1 ring-brand-purple/20'
                                  : 'bg-white border-gray-200 hover:bg-gray-50 text-gray-700'
                              }`}
                            >
                              <span>{choice.label}</span>
                              {choice.priceModifier > 0 && (
                                <span className="text-[10px] text-gray-500 font-mono">
                                  +{choice.priceModifier} ₪
                                </span>
                              )}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* File Attachments */}
            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1.5">
                {t.uploadDesignFiles}
              </label>
              <div className="border-2 border-dashed border-gray-300 hover:border-brand-purple rounded-2xl p-4 text-center bg-gray-50/50 transition-colors">
                <input
                  type="file"
                  multiple
                  onChange={handleFileChange}
                  className="hidden"
                  id="modal-file-upload"
                  accept=".pdf,.png,.jpg,.jpeg,.ai,.psd,.zip"
                />
                <label
                  htmlFor="modal-file-upload"
                  className="cursor-pointer flex flex-col items-center justify-center gap-1.5 text-xs text-gray-600"
                >
                  <Upload size={22} className="text-brand-purple" />
                  <span className="font-bold text-brand-purple">{t.chooseFilesBtn}</span>
                  <span className="text-[10px] text-gray-400">PDF, AI, PSD, PNG, JPG (Max 50MB)</span>
                </label>
              </div>

              {files.length > 0 && (
                <div className="mt-2 space-y-1">
                  {files.map((f, i) => (
                    <div key={i} className="flex items-center justify-between text-xs bg-gray-100 p-2 rounded-xl">
                      <span className="truncate max-w-[200px] text-gray-700">{f.name}</span>
                      <button
                        type="button"
                        onClick={() => removeFile(i)}
                        className="text-red-500 hover:text-red-700 p-1 cursor-pointer"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Special Instructions & AI Copywriter */}
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-xs font-bold text-gray-700">
                  {t.specialNotes}
                </label>
                <button
                  type="button"
                  onClick={() => setShowAI(!showAI)}
                  className="text-xs text-brand-purple font-bold hover:underline flex items-center gap-1 cursor-pointer"
                >
                  <Sparkles size={13} />
                  <span>{currentLang === 'en' ? 'AI Copywriter' : currentLang === 'he' ? 'עוזר כתיבה AI' : 'مساعد الكتابة الذكي'}</span>
                </button>
              </div>
              <textarea
                value={customText}
                onChange={(e) => setCustomText(e.target.value)}
                placeholder={t.specialNotesPlaceholder}
                className="w-full text-xs p-3 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-brand-purple h-20 resize-none text-gray-800"
              />

              {showAI && (
                <div className="mt-2">
                  <AICopywriter
                    productName={localizedName}
                    onSelectText={(txt) => {
                      setCustomText(txt);
                      setShowAI(false);
                    }}
                  />
                </div>
              )}
            </div>
          </div>

          {/* Modal Footer with Calculated Total & Buy Now Action */}
          <div className="mt-6 pt-4 border-t border-gray-200/80">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-baseline gap-2">
                  <span className="text-xs text-gray-500">{t.totalCost}</span>
                  <span className="text-3xl font-black text-brand-purple">{finalTotal} ₪</span>
                  {savings > 0 && (
                    <span className="text-xs text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded-md">
                      {t.totalSavings} {savings} ₪ ({currentDiscount}%)
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-gray-400 mt-0.5">
                  ({quantity} {t.unitPiece} × {effectiveUnitPrice} ₪)
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {onRequestQuote && (
                  <button
                    type="button"
                    onClick={() => {
                      onRequestQuote(localizedName);
                      onClose();
                    }}
                    className="px-3.5 py-2.5 rounded-xl text-xs font-bold text-brand-purple border border-brand-purple/30 hover:bg-brand-purple/10 transition-colors whitespace-nowrap cursor-pointer"
                  >
                    {t.requestCustomQuoteBtn}
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleSubmit}
                  className="flex items-center justify-center gap-1.5 bg-white border-2 border-brand-purple text-brand-purple hover:bg-brand-purple/5 px-4 py-2.5 rounded-xl font-bold text-xs transition-all active:scale-95 cursor-pointer"
                >
                  <ShoppingCart size={16} />
                  <span>{t.addToCartBtn}</span>
                </button>
                <button
                  type="button"
                  onClick={handleBuyNow}
                  className="flex items-center justify-center gap-1.5 bg-brand-yellow hover:bg-yellow-400 text-brand-purple px-5 py-2.5 rounded-xl font-black text-xs shadow-md transition-all active:scale-95 cursor-pointer"
                >
                  <Check size={16} />
                  <span>{t.buyDirectBtn}</span>
                </button>
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};

export default ProductModal;
