import React, { useState } from 'react';
import { ShoppingCart, Menu, Phone, ShieldCheck, X, Truck, Globe, ChevronDown } from 'lucide-react';
import { SiteSettings, Language } from '../types';
import { LANGUAGES, UI_TRANSLATIONS } from '../translations';

interface NavbarProps {
  cartCount: number;
  onCartClick: () => void;
  onHomeClick: () => void;
  onAdminClick: () => void;
  onTrackClick: () => void;
  isAdminLoggedIn: boolean;
  settings: SiteSettings;
  onOpenQuote: () => void;
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  onCartClick,
  onHomeClick,
  onAdminClick,
  onTrackClick,
  isAdminLoggedIn,
  settings,
  onOpenQuote,
  currentLang,
  onLanguageChange,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langDropdownOpen, setLangDropdownOpen] = useState(false);

  const t = UI_TRANSLATIONS[currentLang] || UI_TRANSLATIONS.ar;
  const isRtl = LANGUAGES[currentLang]?.dir === 'rtl';

  return (
    <nav className="sticky top-0 z-40 bg-brand-purple text-white shadow-lg border-b border-brand-yellow/30 font-sans" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        
        {/* Brand Zone */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={onHomeClick}>
          <img
            src={settings.logoUrl}
            alt={settings.companyName}
            className="h-11 w-auto object-contain bg-white/10 rounded-lg p-1 hover:scale-105 transition-transform duration-300"
          />
          <div className={`hidden sm:block ${isRtl ? 'border-r pr-3 mr-1' : 'border-l pl-3 ml-1'} border-white/20`}>
            <h1 className="text-base font-black leading-none text-brand-yellow tracking-wide">
              {settings.companyName}
            </h1>
            <p className="text-[10px] text-gray-200 opacity-90 mt-1">
              {settings.tagline}
            </p>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <div className="hidden md:flex items-center gap-5 lg:gap-6 font-bold text-sm">
          <button onClick={onHomeClick} className="hover:text-brand-yellow transition-colors whitespace-nowrap">
            {t.navHome}
          </button>
          <a href="#products" className="hover:text-brand-yellow transition-colors whitespace-nowrap">
            {t.navProducts}
          </a>
          <button
            onClick={onTrackClick}
            className="flex items-center gap-1.5 bg-white/10 hover:bg-brand-yellow hover:text-brand-purple px-3 py-1.5 rounded-xl transition-all whitespace-nowrap text-xs font-bold"
          >
            <Truck size={15} />
            <span>{t.navTrack}</span>
          </button>
          <button onClick={onOpenQuote} className="hover:text-brand-yellow transition-colors whitespace-nowrap">
            {t.navQuote}
          </button>
          <a href="#contact" className="hover:text-brand-yellow transition-colors whitespace-nowrap">
            {t.navContact}
          </a>
        </div>

        {/* Actions Zone */}
        <div className="flex items-center gap-2 sm:gap-2.5">
          {/* Language Switcher Dropdown */}
          <div className="relative">
            <button
              type="button"
              onClick={() => setLangDropdownOpen(!langDropdownOpen)}
              className="flex items-center gap-1.5 bg-white/10 hover:bg-white/20 text-white px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all border border-white/15 cursor-pointer shadow-xs active:scale-95"
              title="تبديل اللغة / Change Language / החלף שפה"
            >
              <Globe size={14} className="text-brand-yellow" />
              <span className="text-xs">{LANGUAGES[currentLang]?.flag}</span>
              <span className="hidden lg:inline text-[11px] font-bold">{LANGUAGES[currentLang]?.nativeName}</span>
              <ChevronDown size={12} className={`transition-transform duration-200 text-gray-300 ${langDropdownOpen ? 'rotate-180' : ''}`} />
            </button>

            {langDropdownOpen && (
              <>
                <div className="fixed inset-0 z-30" onClick={() => setLangDropdownOpen(false)} />
                <div
                  className={`absolute top-full mt-2 ${isRtl ? 'left-0' : 'right-0'} z-40 bg-white text-gray-800 rounded-2xl shadow-2xl border border-gray-100 py-1.5 w-40 overflow-hidden animate-in fade-in zoom-in-95 duration-150`}
                >
                  <div className="px-3 py-1.5 text-[10px] font-bold text-gray-400 border-b border-gray-100 uppercase tracking-wider">
                    {isRtl ? 'اختر اللغة' : 'Select Language'}
                  </div>
                  {(['ar', 'en', 'he'] as Language[]).map((l) => (
                    <button
                      key={l}
                      type="button"
                      onClick={() => {
                        onLanguageChange(l);
                        setLangDropdownOpen(false);
                      }}
                      className={`w-full flex items-center justify-between px-3.5 py-2.5 text-xs font-bold transition-colors cursor-pointer ${
                        currentLang === l
                          ? 'bg-brand-purple/10 text-brand-purple'
                          : 'hover:bg-gray-50 text-gray-700'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        <span className="text-base">{LANGUAGES[l].flag}</span>
                        <span>{LANGUAGES[l].nativeName}</span>
                      </span>
                      {currentLang === l && (
                        <span className="w-2 h-2 rounded-full bg-brand-purple ring-2 ring-brand-purple/30"></span>
                      )}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Direct Call button */}
          <a
            href={`tel:${settings.displayPhone.replace(/\s+/g, '')}`}
            className="hidden xl:flex items-center gap-1.5 bg-white/10 hover:bg-white/20 text-white px-3 py-1.5 rounded-xl font-bold text-xs transition-colors"
          >
            <Phone size={13} className="text-brand-yellow" />
            <span dir="ltr">{settings.displayPhone}</span>
          </a>

          {/* Admin Dashboard Entry Button - Only visible for authenticated admin staff */}
          {isAdminLoggedIn && (
            <button
              onClick={onAdminClick}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30 shadow-sm"
              title={t.navAdmin}
            >
              <ShieldCheck size={15} className="text-emerald-400" />
              <span className="hidden sm:inline">{t.navAdmin}</span>
            </button>
          )}

          {/* Shopping Cart button */}
          <button
            onClick={onCartClick}
            className="relative p-2.5 bg-brand-yellow text-brand-purple hover:bg-yellow-300 rounded-xl font-bold transition-transform active:scale-95 shadow-sm flex items-center gap-1.5 cursor-pointer"
            aria-label={t.navCart}
          >
            <ShoppingCart size={18} />
            {cartCount > 0 && (
              <span className="bg-red-600 text-white text-[11px] font-black min-w-5 h-5 px-1 rounded-full flex items-center justify-center animate-bounce">
                {cartCount}
              </span>
            )}
          </button>

          {/* Mobile hamburger */}
          <button
            className="md:hidden p-2 text-white hover:bg-white/10 rounded-xl cursor-pointer"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            aria-label="Menu"
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#451f6d] border-t border-white/10 px-4 py-4 space-y-3 animate-in slide-in-from-top-2 duration-150">
          {/* Mobile Language Switcher */}
          <div className="pb-3 border-b border-white/10">
            <span className="block text-[11px] font-bold text-brand-yellow mb-2">
              {isRtl ? 'اللغة / Language / שפה' : 'Language / שפה / اللغة'}:
            </span>
            <div className="grid grid-cols-3 gap-1.5">
              {(['ar', 'en', 'he'] as Language[]).map((l) => (
                <button
                  key={l}
                  type="button"
                  onClick={() => {
                    onLanguageChange(l);
                    setMobileMenuOpen(false);
                  }}
                  className={`py-2 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
                    currentLang === l
                      ? 'bg-brand-yellow text-brand-purple shadow-sm font-black'
                      : 'bg-white/10 text-white hover:bg-white/20'
                  }`}
                >
                  <span>{LANGUAGES[l].flag}</span>
                  <span>{LANGUAGES[l].nativeName}</span>
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={() => {
              onHomeClick();
              setMobileMenuOpen(false);
            }}
            className={`block w-full ${isRtl ? 'text-right' : 'text-left'} py-2 text-sm font-bold hover:text-brand-yellow`}
          >
            {t.navHome}
          </button>
          <a
            href="#products"
            onClick={() => setMobileMenuOpen(false)}
            className={`block w-full ${isRtl ? 'text-right' : 'text-left'} py-2 text-sm font-bold hover:text-brand-yellow`}
          >
            {t.navProducts}
          </a>
          <button
            onClick={() => {
              onTrackClick();
              setMobileMenuOpen(false);
            }}
            className={`flex items-center gap-2 w-full ${isRtl ? 'text-right' : 'text-left'} py-2 text-sm font-bold text-brand-yellow`}
          >
            <Truck size={17} />
            <span>{t.navTrack}</span>
          </button>
          <button
            onClick={() => {
              onOpenQuote();
              setMobileMenuOpen(false);
            }}
            className={`block w-full ${isRtl ? 'text-right' : 'text-left'} py-2 text-sm font-bold hover:text-brand-yellow`}
          >
            {t.navQuote}
          </button>
          <a
            href="#contact"
            onClick={() => setMobileMenuOpen(false)}
            className={`block w-full ${isRtl ? 'text-right' : 'text-left'} py-2 text-sm font-bold hover:text-brand-yellow`}
          >
            {t.navContact}
          </a>

          <div className="pt-2 border-t border-white/10 flex items-center justify-between">
            <span className="text-xs text-purple-200">{t.navSalesPhone}: {settings.displayPhone}</span>
            {isAdminLoggedIn && (
              <button
                onClick={() => {
                  onAdminClick();
                  setMobileMenuOpen(false);
                }}
                className="text-xs font-bold text-emerald-300 underline flex items-center gap-1"
              >
                <ShieldCheck size={14} />
                <span>{t.navAdmin}</span>
              </button>
            )}
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;