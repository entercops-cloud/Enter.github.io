import React, { useState, useEffect } from 'react';
import {
  Search,
  CheckCircle2,
  Clock,
  Printer,
  PackageCheck,
  Truck,
  AlertCircle,
  FileText,
  MessageCircle,
  ArrowRight,
  ArrowLeft,
  Sparkles,
  Calendar,
  Layers,
  History,
  UserCheck,
} from 'lucide-react';
import { Order, OrderWorkflowStatus, OrderStatusHistoryItem, Language } from '../types';
import { store } from '../services/store';
import { UI_TRANSLATIONS, LANGUAGES } from '../translations';

interface OrderTrackingProps {
  onBackToHome: () => void;
  whatsappNumber?: string;
  initialOrderId?: string;
  currentLang?: Language;
}

interface StepInfo {
  id: OrderWorkflowStatus;
  titleKey: 'step1Title' | 'step2Title' | 'step3Title' | 'step4Title' | 'step5Title';
  descKey: 'step1Desc' | 'step2Desc' | 'step3Desc' | 'step4Desc' | 'step5Desc';
  icon: React.ElementType;
}

const WORKFLOW_STEP_DEFINITIONS: StepInfo[] = [
  { id: 'new', titleKey: 'step1Title', descKey: 'step1Desc', icon: Clock },
  { id: 'review', titleKey: 'step2Title', descKey: 'step2Desc', icon: FileText },
  { id: 'in_press', titleKey: 'step3Title', descKey: 'step3Desc', icon: Printer },
  { id: 'packaging', titleKey: 'step4Title', descKey: 'step4Desc', icon: Layers },
  { id: 'ready', titleKey: 'step5Title', descKey: 'step5Desc', icon: PackageCheck },
];

const getStatusBadgeConfig = (status: OrderWorkflowStatus, lang?: Language | string) => {
  switch (status) {
    case 'new':
      return {
        label: lang === 'en' ? 'Order Received' : lang === 'he' ? 'קליטת הזמנה' : 'استلام الطلب',
        icon: Clock,
        bg: 'bg-amber-100 text-amber-800 border-amber-200',
      };
    case 'review':
      return {
        label: lang === 'en' ? 'Pre-Press Review' : lang === 'he' ? 'בדיקת קבצים והכנה' : 'قيد التدقيق الفني',
        icon: FileText,
        bg: 'bg-purple-100 text-purple-800 border-purple-200',
      };
    case 'in_press':
    case 'in_progress':
      return {
        label: lang === 'en' ? 'In Press (Printing)' : lang === 'he' ? 'בדפוס בהפקה' : 'في المطبعة قيد التنفيذ',
        icon: Printer,
        bg: 'bg-blue-100 text-blue-800 border-blue-200',
      };
    case 'packaging':
      return {
        label: lang === 'en' ? 'Packaging & Prep' : lang === 'he' ? 'אريזה וגימור' : 'مرحلة التغليف والتجهيز',
        icon: Layers,
        bg: 'bg-orange-100 text-orange-800 border-orange-200',
      };
    case 'ready':
      return {
        label: lang === 'en' ? 'Ready for Pickup / Delivery' : lang === 'he' ? 'מוכן לאיסוף / משלוח' : 'جاهز للاستلام والتوصيل',
        icon: PackageCheck,
        bg: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      };
    case 'completed':
      return {
        label: lang === 'en' ? 'Completed & Delivered' : lang === 'he' ? 'נמסר בהצלחה' : 'تم التسليم بنجاح',
        icon: CheckCircle2,
        bg: 'bg-gray-100 text-gray-800 border-gray-200',
      };
    case 'cancelled':
      return {
        label: lang === 'en' ? 'Cancelled' : lang === 'he' ? 'מבוטל' : 'ملغي',
        icon: AlertCircle,
        bg: 'bg-red-100 text-red-800 border-red-200',
      };
    default:
      return {
        label: status,
        icon: Clock,
        bg: 'bg-gray-100 text-gray-800 border-gray-200',
      };
  }
};

const formatHistoryDateTime = (dateStr: string, lang?: Language | string) => {
  try {
    const d = new Date(dateStr);
    const locale = lang === 'en' ? 'en-US' : lang === 'he' ? 'he-IL' : 'ar-EG';
    return d.toLocaleDateString(locale, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateStr;
  }
};

const getEffectiveHistory = (order: Order, lang?: Language | string): OrderStatusHistoryItem[] => {
  if (order.history && Array.isArray(order.history) && order.history.length > 0) {
    return order.history;
  }

  // Synthesize realistic progressive history for records without logged history
  const initialNote = lang === 'en'
    ? 'Order received and confirmed in system'
    : lang === 'he'
    ? 'ההזמנה נקלטה ואושרה במערכת'
    : 'تم استلام الطلب وتأكيد البيانات في النظام';

  const list: OrderStatusHistoryItem[] = [
    {
      id: `synth-init-${order.id}`,
      status: 'new',
      statusNote: initialNote,
      timestamp: order.createdAt,
      updatedBy: lang === 'en' ? 'System' : lang === 'he' ? 'מערכת' : 'النظام الإلكتروني',
    },
  ];

  if (order.status !== 'new') {
    list.push({
      id: `synth-current-${order.id}`,
      status: order.status,
      statusNote: order.statusNote || (lang === 'en' ? 'Stage in progress' : lang === 'he' ? 'בשלבי ביצוע' : 'جاري متابعة مرحلة التنفيذ بالمطبعة'),
      timestamp: order.updatedAt || order.createdAt,
      updatedBy: lang === 'en' ? 'Press Team' : lang === 'he' ? 'צוות הדפוס' : 'إدارة المطبعة',
    });
  }

  return list;
};

export const OrderTracking: React.FC<OrderTrackingProps> = ({
  onBackToHome,
  whatsappNumber = '970568204195',
  initialOrderId = '',
  currentLang = 'ar',
}) => {
  const [searchQuery, setSearchQuery] = useState(initialOrderId);
  const [order, setOrder] = useState<Order | null>(() => {
    const demoOrders = store.getOrders();
    return demoOrders.length > 0 ? demoOrders[0] : null;
  });
  const [error, setError] = useState('');

  const t = UI_TRANSLATIONS[currentLang] || UI_TRANSLATIONS.ar;
  const isRtl = LANGUAGES[currentLang]?.dir === 'rtl';

  useEffect(() => {
    if (initialOrderId) {
      setSearchQuery(initialOrderId);
      store.getOrderByIdOrPhone(initialOrderId).then((found) => {
        if (found) {
          setOrder(found);
          setError('');
        }
      });
    }
  }, [initialOrderId]);

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchQuery.trim()) {
      setError(currentLang === 'en' ? 'Please enter an Order ID or phone number' : currentLang === 'he' ? 'אנא הזן מספר הזמנה או מספר טלפון' : 'يرجى إدخال رقم الطلب أو رقم الهاتف');
      return;
    }

    const found = await store.getOrderByIdOrPhone(searchQuery);
    if (found) {
      setOrder(found);
      setError('');
    } else {
      setError(
        currentLang === 'en'
          ? `No order found with "${searchQuery}". Please verify the order number (e.g. ORD-1092).`
          : currentLang === 'he'
          ? `לא נמצאה הזמנה עבור "${searchQuery}". אנא ודא את המספר (למשל: ORD-1092).`
          : `لم يتم العثور على أي طلب برقم "${searchQuery}". يرجى التأكد من الرقم (مثال: ORD-1092).`
      );
      setOrder(null);
    }
  };

  const selectDemoOrder = async (id: string) => {
    setSearchQuery(id);
    const found = await store.getOrderByIdOrPhone(id);
    if (found) {
      setOrder(found);
      setError('');
    }
  };

  const getStepIndex = (status: OrderWorkflowStatus): number => {
    switch (status) {
      case 'new':
        return 0;
      case 'review':
        return 1;
      case 'in_progress':
      case 'in_press':
        return 2;
      case 'packaging':
        return 3;
      case 'ready':
      case 'completed':
        return 4;
      case 'cancelled':
        return -1;
      default:
        return 1;
    }
  };

  const currentStepIdx = order ? getStepIndex(order.status) : 0;
  const orderHistory = order ? getEffectiveHistory(order, currentLang) : [];

  return (
    <div className="py-12 bg-gray-50 min-h-screen font-sans" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="container mx-auto px-4 max-w-5xl">
        {/* Navigation Breadcrumb */}
        <div className="mb-6 flex items-center justify-between">
          <button
            onClick={onBackToHome}
            className="flex items-center gap-2 text-xs font-bold text-brand-purple hover:underline bg-white px-3.5 py-2 rounded-xl border border-gray-200 shadow-2xs cursor-pointer"
          >
            {isRtl ? <ArrowRight size={15} /> : <ArrowLeft size={15} />}
            <span>{t.backToStore}</span>
          </button>
        </div>

        {/* Page Header */}
        <div className="text-center mb-10 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 bg-brand-purple/10 text-brand-purple rounded-full text-xs font-black mb-3">
            <Truck size={15} />
            <span>{currentLang === 'en' ? 'Live Workflow Status' : currentLang === 'he' ? 'מעקב ייצור חי' : 'تتبع مراحل الإنتاج والتنفيذ'}</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-brand-dark mb-3">
            {t.trackPageTitle}
          </h1>
          <p className="text-gray-600 text-xs sm:text-sm leading-relaxed">
            {t.trackPageSubtitle}
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-xl mx-auto mb-10">
          <form onSubmit={handleSearch} className="flex gap-2 p-1.5 bg-white rounded-2xl border border-gray-200 shadow-md">
            <div className="relative flex-grow">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder={t.trackInputPlaceholder}
                className={`w-full ${isRtl ? 'pr-10 pl-4' : 'pl-10 pr-4'} py-3 text-xs sm:text-sm rounded-xl outline-none text-gray-800`}
              />
              <Search
                size={18}
                className={`absolute ${isRtl ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 text-gray-400`}
              />
            </div>
            <button
              type="submit"
              className="bg-brand-purple hover:bg-[#4d2377] text-white px-6 py-3 rounded-xl font-bold text-xs sm:text-sm shadow-sm transition-all active:scale-95 shrink-0 cursor-pointer"
            >
              {t.trackSearchBtn}
            </button>
          </form>

          {/* Quick Demo Order Chips */}
          <div className="flex flex-wrap items-center justify-center gap-2 mt-3 text-[11px] text-gray-500">
            <span>{currentLang === 'en' ? 'Demo Orders:' : currentLang === 'he' ? 'הזמנות לדוגמה:' : 'أوامر طباعة تجريبية:'}</span>
            {['ORD-1092', 'ORD-1091', 'ORD-1088'].map((id) => (
              <button
                key={id}
                type="button"
                onClick={() => selectDemoOrder(id)}
                className="bg-white border border-gray-200 hover:border-brand-purple text-brand-purple font-mono px-2 py-0.5 rounded-md text-[11px] font-bold cursor-pointer transition-colors"
              >
                {id}
              </button>
            ))}
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2 mt-3">
              <AlertCircle size={16} className="shrink-0" />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* Order Details & Stepper Card */}
        {order && (
          <div className="bg-white rounded-3xl border border-gray-200/80 shadow-md overflow-hidden animate-in fade-in duration-300">
            {/* Order Summary Strip */}
            <div className="bg-brand-dark text-white p-6 sm:p-7 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b-4 border-brand-yellow">
              <div>
                <div className="flex items-center gap-3">
                  <span className="text-xl sm:text-2xl font-black tracking-wide font-mono text-brand-yellow">
                    {order.id}
                  </span>
                  <span className="text-xs bg-white/10 px-3 py-1 rounded-full font-bold">
                    {t.customerName} {order.customerName}
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-4 text-xs text-gray-300 mt-2">
                  <span className="flex items-center gap-1">
                    <Calendar size={13} className="text-brand-yellow" />
                    {t.orderDate} {new Date(order.createdAt).toLocaleDateString(currentLang === 'en' ? 'en-US' : currentLang === 'he' ? 'he-IL' : 'ar-EG')}
                  </span>
                  {order.estimatedDate && (
                    <span className="flex items-center gap-1 font-semibold text-emerald-300">
                      <Clock size={13} />
                      {t.estimatedDelivery} {order.estimatedDate}
                    </span>
                  )}
                </div>
              </div>

              {/* Direct Support Button */}
              <a
                href={`https://wa.me/${whatsappNumber}?text=${encodeURIComponent(`Hello, I would like to inquire about my order (${order.id}) for ${order.customerName}`)}`}
                target="_blank"
                rel="noreferrer"
                className="flex items-center gap-2 bg-[#25D366] hover:bg-[#20ba5a] text-white px-4 py-2.5 rounded-xl font-bold text-xs shadow-md transition-all self-start sm:self-auto cursor-pointer"
              >
                <MessageCircle size={16} />
                <span>{t.inquiryWhatsApp}</span>
              </a>
            </div>

            {/* Stepper Progress Bar */}
            <div className="p-6 sm:p-8 border-b border-gray-100 bg-gray-50/50">
              <h3 className="text-sm font-black text-gray-900 mb-6 flex items-center gap-2">
                <Sparkles size={17} className="text-brand-purple" />
                <span>{currentLang === 'en' ? 'Live Production Timeline' : currentLang === 'he' ? 'ציר זמן שלבי הדפוס והייצור' : 'مراحل سير عمل المطبوعات والتنفيذ'}</span>
              </h3>

              {order.status === 'cancelled' ? (
                <div className="p-4 bg-red-50 border border-red-200 rounded-2xl text-red-700 text-xs flex items-center gap-3">
                  <AlertCircle size={24} />
                  <div>
                    <h4 className="font-bold text-sm">
                      {currentLang === 'en' ? 'This order was cancelled' : currentLang === 'he' ? 'הזמנה זו בוטלה' : 'تم إلغاء هذا الطلب'}
                    </h4>
                    <p className="mt-0.5">
                      {currentLang === 'en'
                        ? 'Please contact customer support on WhatsApp for reactivation.'
                        : currentLang === 'he'
                        ? 'אנא פנה לשירות הלקוחות בווטסאפ לבירור או הפעלה מחדש.'
                        : 'يرجى التواصل مع الإدارة عبر واتساب لأي استفسار أو إعادة التفعيل.'}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="relative">
                  {/* Progress Line */}
                  <div className="hidden md:block absolute top-1/2 left-0 right-0 h-1 bg-gray-200 -translate-y-1/2 z-0">
                    <div
                      className="h-full bg-brand-purple transition-all duration-500"
                      style={{
                        width: `${(currentStepIdx / (WORKFLOW_STEP_DEFINITIONS.length - 1)) * 100}%`,
                      }}
                    />
                  </div>

                  {/* Steps Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4 relative z-10">
                    {WORKFLOW_STEP_DEFINITIONS.map((step, idx) => {
                      const isCompleted = idx < currentStepIdx;
                      const isCurrent = idx === currentStepIdx;
                      const IconComponent = step.icon;
                      const stepTitle = t[step.titleKey];
                      const stepDesc = t[step.descKey];

                      return (
                        <div
                          key={step.id}
                          className={`p-4 rounded-2xl border transition-all text-center flex flex-col items-center justify-between min-h-[140px] ${
                            isCurrent
                              ? 'bg-white border-brand-purple shadow-lg ring-2 ring-brand-purple/20 scale-105'
                              : isCompleted
                              ? 'bg-emerald-50/80 border-emerald-200 text-emerald-900'
                              : 'bg-white/80 border-gray-200 opacity-60'
                          }`}
                        >
                          <div
                            className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-2 shadow-xs transition-transform ${
                              isCurrent
                                ? 'bg-brand-purple text-white animate-pulse'
                                : isCompleted
                                ? 'bg-emerald-600 text-white'
                                : 'bg-gray-100 text-gray-400'
                            }`}
                          >
                            {isCompleted ? <CheckCircle2 size={24} /> : <IconComponent size={22} />}
                          </div>

                          <div>
                            <h4
                              className={`text-xs font-black mb-1 ${
                                isCurrent
                                  ? 'text-brand-purple'
                                  : isCompleted
                                  ? 'text-emerald-900'
                                  : 'text-gray-700'
                              }`}
                            >
                              {stepTitle}
                            </h4>
                            <p className="text-[10px] text-gray-500 leading-tight">
                              {stepDesc}
                            </p>
                          </div>

                          <div className="mt-2 text-[10px] font-bold">
                            {isCurrent && (
                              <span className="bg-brand-purple/10 text-brand-purple px-2 py-0.5 rounded-full inline-block">
                                {t.currentStatus}
                              </span>
                            )}
                            {isCompleted && (
                              <span className="text-emerald-700">✓ {currentLang === 'en' ? 'Completed' : currentLang === 'he' ? 'הושלם' : 'مكتمل'}</span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Technical Inspection Note */}
            {order.statusNote && (
              <div className="p-4 sm:p-5 bg-amber-50/70 border-b border-amber-100 flex items-start gap-3 text-xs text-amber-900">
                <AlertCircle size={18} className="text-amber-600 shrink-0 mt-0.5" />
                <div>
                  <strong className="block font-bold mb-0.5">{t.technicalNote}</strong>
                  <p className="text-amber-800 leading-relaxed">{order.statusNote}</p>
                </div>
              </div>
            )}

            {/* Historical Progression Timeline Log */}
            <div className="p-6 sm:p-8 border-b border-gray-100 bg-white">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-6">
                <div>
                  <h3 className="text-sm font-black text-gray-950 flex items-center gap-2">
                    <History size={18} className="text-brand-purple" />
                    <span>{t.historyLogTitle}</span>
                  </h3>
                  <p className="text-xs text-gray-500 mt-0.5">
                    {t.historyLogSubtitle}
                  </p>
                </div>

                <span className="self-start sm:self-auto text-[11px] font-bold text-brand-purple bg-purple-50 border border-purple-200/80 px-3 py-1 rounded-full">
                  {orderHistory.length} {currentLang === 'en' ? 'Recorded Milestone(s)' : currentLang === 'he' ? 'שלבים מתועדים' : 'تحديثات ومراحل موثقة'}
                </span>
              </div>

              {orderHistory.length === 0 ? (
                <div className="p-4 bg-gray-50 rounded-2xl text-xs text-gray-500 border border-gray-100 text-center">
                  {t.historyEmpty}
                </div>
              ) : (
                <div className="relative">
                  {/* Vertical continuous timeline line */}
                  <div
                    className={`absolute top-4 bottom-4 w-0.5 bg-gray-200 ${
                      isRtl ? 'right-[19px]' : 'left-[19px]'
                    }`}
                  />

                  <div className="space-y-5 relative">
                    {orderHistory.map((item, index) => {
                      const isLatest = index === orderHistory.length - 1;
                      const badgeConfig = getStatusBadgeConfig(item.status, currentLang);
                      const IconComponent = badgeConfig.icon;

                      return (
                        <div
                          key={item.id || index}
                          className="flex items-start gap-4 transition-all duration-300"
                        >
                          {/* Timeline Step Icon Node */}
                          <div
                            className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 z-10 shadow-xs ring-4 ring-white transition-all ${
                              isLatest
                                ? 'bg-brand-purple text-white shadow-md shadow-purple-500/25 ring-purple-100 scale-105'
                                : 'bg-emerald-600 text-white'
                            }`}
                          >
                            <IconComponent size={18} />
                          </div>

                          {/* Timeline Card */}
                          <div
                            className={`flex-grow p-4 rounded-2xl border transition-all ${
                              isLatest
                                ? 'bg-purple-50/40 border-purple-200/90 shadow-xs'
                                : 'bg-gray-50/70 border-gray-200/70'
                            }`}
                          >
                            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 pb-2 border-b border-gray-200/60">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span
                                  className={`text-xs font-black px-2.5 py-0.5 rounded-full border ${badgeConfig.bg}`}
                                >
                                  {badgeConfig.label}
                                </span>
                                {isLatest && (
                                  <span className="text-[10px] font-bold bg-brand-purple text-white px-2 py-0.5 rounded-full">
                                    {currentLang === 'en'
                                      ? 'Current Stage'
                                      : currentLang === 'he'
                                      ? 'שלב פעיל כעת'
                                      : 'المرحلة النشطة الحالية'}
                                  </span>
                                )}
                                {item.updatedBy && (
                                  <span className="text-[11px] text-gray-500 flex items-center gap-1 font-medium">
                                    <UserCheck size={12} className="text-gray-400" />
                                    <span>{item.updatedBy}</span>
                                  </span>
                                )}
                              </div>

                              <div className="flex items-center gap-1.5 text-[11px] text-gray-500 font-mono">
                                <Clock size={12} className="text-gray-400" />
                                <span>{formatHistoryDateTime(item.timestamp, currentLang)}</span>
                              </div>
                            </div>

                            {item.statusNote && (
                              <div className="mt-2.5 text-xs text-gray-700 leading-relaxed font-medium">
                                {item.statusNote}
                              </div>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Ordered Items Spec Sheet */}
            <div className="p-6 sm:p-8 space-y-4">
              <h3 className="text-sm font-black text-gray-900 flex items-center gap-2">
                <FileText size={16} className="text-brand-purple" />
                <span>{t.itemsInOrder}</span>
              </h3>

              <div className="divide-y divide-gray-100 border border-gray-100 rounded-2xl overflow-hidden">
                {order.items.map((item, idx) => (
                  <div key={idx} className="p-4 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="space-y-1">
                      <h4 className="font-bold text-gray-900 text-sm">{item.productName}</h4>
                      {item.optionsSummary && (
                        <div className="text-gray-500 text-[11px]">
                          {item.optionsSummary}
                        </div>
                      )}
                      {item.customText && (
                        <div className="text-brand-purple text-[11px]">
                          "{item.customText}"
                        </div>
                      )}
                    </div>

                    <div className="flex sm:flex-col items-center sm:items-end justify-between sm:justify-center border-t sm:border-0 pt-2 sm:pt-0">
                      <div className="text-gray-600 font-semibold">
                        {item.quantity} {t.unitPiece} × {item.unitPrice} ₪
                      </div>
                      <div className="font-black text-brand-purple text-sm">
                        {item.totalPrice} ₪
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Order Financials Footer */}
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <div className="text-gray-600">
                  {order.discountTotal > 0 && (
                    <span className="text-emerald-700 font-bold block">
                      {t.cartVolumeSavings} {order.discountTotal} ₪
                    </span>
                  )}
                  {order.customerAddress && (
                    <span className="text-gray-500 block">
                      {t.orderAddress} {order.customerAddress}
                    </span>
                  )}
                </div>

                <div className="text-base font-black text-brand-dark flex items-center gap-2">
                  <span>{t.totalPaid}</span>
                  <span className="text-2xl text-brand-purple">{order.finalTotal} ₪</span>
                </div>
              </div>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default OrderTracking;
