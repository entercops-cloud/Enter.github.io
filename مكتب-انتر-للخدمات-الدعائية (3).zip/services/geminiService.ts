// Secure Client-Side Gemini Service:
// Requests AI marketing copy through the server-side proxy (/api/ai/copywrite)
// protecting the API key from browser inspection and avoiding client-side credential errors.

export const generateMarketingCopy = async (
  productName: string,
  businessInfo: string,
  tone: 'professional' | 'creative' | 'urgent' = 'professional'
): Promise<string> => {
  try {
    const response = await fetch('/api/ai/copywrite', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        productName,
        businessInfo,
        tone,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      if (data && data.text) {
        return data.text;
      }
    }
    throw new Error('Server returned an unexpected response');
  } catch (error) {
    console.warn('AI Copywriter request error, using fallback:', error);
    // Client fallback to ensure user always receives prompt text smoothly
    if (tone === 'urgent') {
      return `عرض خاص ولفترة محدودة! تميّز بأعلى جودة لـ ${productName} (${businessInfo || 'خدمات متميزة'}). تواصل معنا الآن للاستفادة من الخصم المباشر!`;
    } else if (tone === 'creative') {
      return `لأن علامتك تستحق التميز، نقدم لك تصاميم وطباعة فريدة لـ ${productName}. ${businessInfo ? businessInfo + ' - ' : ''}إبداع يترك أثراً لا يُنسى!`;
    }
    return `الجودة والاحترافية عنواننا في تنفيذ ${productName}. ${businessInfo ? businessInfo + ' - ' : ''}نلتزم بأعلى معايير الإتقان والتسليم في الموعد المحدد.`;
  }
};
